**简要描述：** 

- 查询订阅标签

**请求URL：** 
- pc : `{host}/api/my/tag/subscribe/querySubscribeTags`

  
**请求方式：**
- POST   http payload

**参数：** 
``` 
{"pageNo":"1","pageSize":100,"name":"标签"}
```
|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|pageNo|是|int|页码|
|pageSize|是|int|每页数量|
|name|否|string|标签名称|

 **返回示例**

``` 
{
    "code": 200,
    "msg": "接口返回成功",
    "status": true,
    "data": {
        "total": "1",
        "current": "1",
        "hitCount": false,
        "pages": "1",
        "size": "5",
        "optimizeCountSql": true,
        "records": [
            {
                "creator": "4258568619558548534",
                "color": "#5D9CEC",
                "tagId": "887880112207011840",
                "searchType": 0,
                "creators": [
                    "4258568619558548534"
                ],
                "matchType": 0,
                "groupId": "0",
                "businessId": "0",
                "deleteType": 0,
                "type": 0,
                "quoteNum": 0,
                "entityCount": 0,
                "createTime": 1736822915000,
                "childrenNum": 0,
                "name": "123312311",
                "tagIndex": 9999
            }
        ],
        "searchCount": true,
        "orders": []
    },
    "fail": false
}
```

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|code |int   |200成功  |



 **备注** 

- 更多返回错误代码请看首页的错误代码描述
