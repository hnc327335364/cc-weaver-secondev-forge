# 数据库：`ebuilder_page`

> 共 **17** 张表

---

| 数据库表名 | 中文名称 | 所属模块 | 表类型 | 字段明细 |
|-----------|---------|---------|--------|---------|
| [[数据表/e-Builder页面引擎/ebdp_anonymous_white_list|ebdp_anonymous_white_list]] | 匿名白名单 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_code_exec_log|ebdp_code_exec_log]] | eb页面执行记录 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_matrix_right|ebdp_matrix_right]] | 页面矩阵权限表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page|ebdp_page]] | 页面表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page_config|ebdp_page_config]] | 基本信息配置表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page_group|ebdp_page_group]] | 页面分组表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page_permission|ebdp_page_permission]] | 页面权限拓展表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page_permission_group|ebdp_page_permission_group]] | 页面权限组 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page_ph_ebdcomm_view|ebdp_page_ph_ebdcomm_view]] | 页面使用范围 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_page_settings|ebdp_page_settings]] | ebuilder应用页面设置表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_pagelogs|ebdp_pagelogs]] | 页面操作日志表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_pagelogs_detail|ebdp_pagelogs_detail]] | 页面日志详情表 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_secondauth|ebdp_secondauth]] | 页面二次身份验证 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_secondauth_detail|ebdp_secondauth_detail]] | 页面二次身份验证详情 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_secondauthlogs|ebdp_secondauthlogs]] | 二次身份验证日志 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebdp_secondauthlogs_detail|ebdp_secondauthlogs_detail]] | 二次身份验证日志详情 | e-Builder页面引擎 | 普通表 | ✅ |
| [[数据表/e-Builder页面引擎/ebuilder_page_multilangset|ebuilder_page_multilangset]] | ebuilder_page运行自定义菜单多语言标签库 | e-Builder页面引擎 | 普通表 | ✅ |

