---
table_name: portrait_multilineset
cn_name: 多行文本多语言表
module: 组织画像
database: portrait
type: 普通表
owner: 何前锋
creator: 系统管理员
public_config: 0
data_id: 100655700000007089
has_fields: true
tags: [E10, 数据字典]
---

# portrait_multilineset

> 多行文本多语言表

> [!info] 基本信息
> - 数据库表名：`portrait_multilineset`
> - 中文名称：多行文本多语言表
> - 所属模块：组织画像
> - 所属数据库：`portrait`
> - 表类型：普通表
> - 负责人：何前锋
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：实现多行文本多语言
> - 数据ID：`100655700000007089`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | langid | 语言id | 整型 |  |  |  |  |  |  |  |  |
| 8 | langtype | 语言标识 | 字符 | 50 |  |  |  |  |  |  |  |
| 9 | modifier | 修改人id | 长整型 |  |  |  |  |  |  |  |  |
| 10 | tablefield | 表字段标识 | 字符 | 200 |  |  |  |  |  |  |  |
| 11 | fieldvalue | 字段值 | 字符 | 2000 |  |  |  |  |  |  |  |
| 12 | target_id | 关联id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/组织画像]]
- 数据库索引：[[数据库索引/portrait]]
