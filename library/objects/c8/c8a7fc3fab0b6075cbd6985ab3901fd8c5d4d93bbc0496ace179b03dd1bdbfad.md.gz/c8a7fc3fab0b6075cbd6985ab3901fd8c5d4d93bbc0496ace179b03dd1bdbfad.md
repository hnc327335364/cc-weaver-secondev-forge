---
table_name: formdata
cn_name: formdata
module: 表单引擎
database: project
type: SDK表
owner: 江伟
creator: 江伟
public_config: 0
data_id: 100655700000005125
has_fields: true
tags: [E10, 数据字典]
---

# formdata

> formdata

> [!info] 基本信息
> - 数据库表名：`formdata`
> - 中文名称：formdata
> - 所属模块：表单引擎
> - 所属数据库：`project`
> - 表类型：SDK表
> - 负责人：江伟
> - 创建者：江伟
> - 是否公共配置：0
> - 描述：formdata
> - 数据ID：`100655700000005125`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | data_status | DATA_STATUS | 字符 | 50 |  |  |  |  |  |  |  |
| 2 | module |  | 字符 | 255 |  |  |  |  |  |  |  |
| 3 | client | CLIENT | 字符 | 50 |  |  |  |  |  |  |  |
| 4 | version | VERSION | 字符 | 50 |  |  |  |  |  |  |  |
| 5 | spent_time | 时间 | 长整型 |  |  |  |  |  |  |  |  |
| 6 | ip | IP | 长整型 | 50 |  |  |  |  |  |  |  |
| 7 | name | name | 字符 | 800 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/表单引擎]]
- 数据库索引：[[数据库索引/project]]
