# 与我相关

来源快照：`result_data_new_260518.json`

- 来源 ID：`1174652995626352646`
- 模块：协作区
- 目录：前台使用
- space ID：`1172861371551350820`
- 原文链接：未提供
- 产品基线：未提供

## 正文

一、

# 功能背景及价值用途

在参与协作交流的时候，可以针对用户的发言进行回复，被回复对象就可以在“与我相关”中专门查看这些回复的信息。

二、

# 业务流程图/配置过程图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174653506588074000&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

三、

# 功能详细说明

四、

## 查看

点击【与我相关】菜单后显示与我相关页面。

1、此处显示所有可查看的协作中，评论、引用自己内容的协作，可直接在此页面进行内容回复；

2、在相关主题后面后协作的主题名称，可以点击后进入该主题，参与讨论。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174653506680848391&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

五、

全部：展示全部类型的“与我相关信息”。

六、

评论我的：我的交流被其他人评论后，此交流信息即为“评论我的”与我相关。

七、

回复我的：我的评论被其他人回复后，此调评论信息所在的交流，即为“回复我的”与我相关。

八、

引用我的：我的交流被其他人引用发表后，此调交流即为“引用我的”与我相关。

九、

@我的：有交流或评论中@我，此交流即为“@我的”与我相关。

 

十、

## 交互操作

用户可直接在与我相关页面，对交流和评论进行相关操作。

操作效果与协作查看页面相同。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174653511101644800&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

点击“相关主题名称”，可直接打开与我相关交流所在的协作详情查看。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174653511083835399&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
