# 集成登录加密算法配置说明

来源快照：`result_data_new_260518.json`

- 来源 ID：`1175754251019255840`
- 模块：集成中心
- 目录：集成登录 - 后台维护 - 功能点说明
- space ID：`1158011075224911873`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能介绍

**注意：需要购买统一认证****-****集成登录功能。**

本文主要介绍集成登录，系统默认自带加密算法可供客户使用。如果系统默认的加密算法不能满足客户需求，可提交 **_客户需求和建议评估流程_**  定制开发。

# 二、功能概述以及使用说明

## 1、功能权限

需要有集成登录权限

路径：【后台管理中心】-【权限管理中心】-【角色设置】-【角色列表】-【功能权限】-【集成登录】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234817829411110917&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2、功能说明

入口：【后台管理中心】-【集成中心】-【集成登录】-【加密算法设置】

特别注意：当服务属于私有化部署时，自定义加密算法才会展示，云服务不支持此功能。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234820238815666180&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 

**列表说明：**

加密名称| 展示系统级加密算法名称  
---|---  
加密算法类| 展示系统级加密算法类路径  
被引用标识| 展示引用此加密算法的集成登录应用名称  
  
 

**注意：** 加密算法分为三大类：对称算法、非对称算法、摘要算法。目前系统自带的加密算法共有21个，**其中，【****10.0.2507.01****基线版本】开始支持****Hex****、****3DES****、****chacha20****加密算法，以及****AES****和****DES****加密密钥支持****192****位和****256****位；****【10.0.2509.01基线版本】开始支持SM9算法；【10.0.2510.01基线版本】开始支持AES128算法。**

 

① 

对称算法，包含：AES、DES、PBE、SM4、AES_SEED、DES_SEED、BASE64、HEX、3DES

② 

非对称算法，包含：RSA、SM2

③ 

摘要算法，包含：MD5、SHA1、SHA256、SM3、SHA512、HmacMD5、HmacSHA1、HmacSHA256、HmacSHA512、chacha20

** **

###  2.1、集成登录引用说明

新建、编辑集成登录，自定义参数-加密设置进行引用，此时，加密算法设置-被引用标识，列数据会展示对应的集成登录应用名称。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234817932476948487&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234817954060836868&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 2.2、配置示例说明

集成登录，自定义参数加密设置中，若选择3DES加密方式，加密模式CBC，填充ZEROPADDING，加密密钥7f29fcc931cc43f3bd065777af3d523e，加密向量7f29fcc931cc43f3，输出HEX，输出小写，可对参数值（如Aa12345）进行加密，加密结果与在线加密（http://tool.chacuo.net/crypt3des）中保持一致。

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234817975599382530&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234818001340235781&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

# 附件：E9和E10加密算法对应关系

**E9加密算法**| **E10加密算法**| **E10加密算法备注说明**  
---|---|---  
MD5| MD5|    
MD5_Base64| 不支持|    
PBE| PBE|    
PBE_Base64| 不支持|    
DES| DES，加密模式ECB，填充PKCS5PADDING，输出HEX|    
DES_IV| DES，加密模式CBC，填充PKCS5PADDING，输出HEX| DES算法，加密向量长度不限  
DES_IV_Base64| DES，加密模式CBC，填充PKCS5PADDING，输出BASE64  
DES_Base64| DES_SEED，加密模式ECB，输出BASE64| DES_SEED算法，加密模式ECB，密钥长度不限；加密模式CBC，密钥长度不限，加密向量必须8字节  
AES| AES_SEED，加密模式ECB，输出HEX| AES_SEED算法，加密模式ECB，密钥长度不限；加密模式CBC，密钥长度不限，加密向量必须16字节  
AES_IV| AES_SEED，加密模式CBC，输出HEX  
AES_IV_Base64| AES_SEED，加密模式CBC，输出BASE64  
AES_Base64| AES_SEED，加密模式ECB，输出BASE64  
Base64| Base64|    
SHA1| SHA1|    
 | SHA256|    
 | SM2|    
 | SM3|    
 | SM4| 向量必须8字节  
 | SHA512|    
 | HmacMD5|    
 | HmacSHA1|    
 | HmacSHA256|    
 | HmacSHA512|    
 | Hex|    
 | 3DES|    
 | chacha20|    
 | AES| 加密向量长度不限  
 | RSA| 公钥加密，私钥解密  
 | SM9| 10.0.2509.01基线版本开始支持  
  
# 三、常用在线加解密工具

AES加解密工具：[ _http://tool.chacuo.net/cryptaes_](http://tool.chacuo.net/cryptaes)

DES加解密工具：[ _http://tool.chacuo.net/cryptdes_](http://tool.chacuo.net/cryptdes)

3DES加解密工具：[ _http://tool.chacuo.net/crypt3des_](http://tool.chacuo.net/crypt3des)

chacha20加密工具：[ _https://www.ssleye.com/ssltool/chacha20_cipher.html_](https://www.ssleye.com/ssltool/chacha20_cipher.html)

Base64加解密工具：[ _https://www.gseen.com/online_tools/encryption/text_base64_](https://www.gseen.com/online_tools/encryption/text_base64)

散列/哈希加解密工具：[ _https://www.sojson.com/hash.html_](https://www.sojson.com/hash.html)

 

 

**说明：** 在线chacha20加密算法工具，只能对密钥32字节，盐值8字节的明文数据进行加密。
