**简要描述：** 

- 添加标签管理和标签关联关系

**请求URL：** 
- pc : `{host}/api/my/tag/categoryManager/addManagerLink`

  
**请求方式：**
- POST   http payload

**参数：** 
``` 
{"managerId":"123","tagIds":"12,22,22,3"}
```
|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
 |managerId|是|long|分类id|
  |tagIds|是|string|标签id,支持批量用逗号隔开|

 **返回示例**

``` 
 {
    "code": 200,
    "msg": "接口返回成功",
    "status": true,
    "fail": false
}
```

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|code |int   |200成功  |



 **备注** 

- 更多返回错误代码请看首页的错误代码描述
