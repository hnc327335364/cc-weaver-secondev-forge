---
table_name: publishkit_transfer_packing
cn_name: 应用打包记录
module: e-Builder应用建模
database: techdoc
type: 普通表
owner: 程东勇
creator: 梁威（上海）
public_config: 0
data_id: 968063101437108240
has_fields: true
tags: [E10, 数据字典]
---

# publishkit_transfer_packing

> 应用打包记录

> [!info] 基本信息
> - 数据库表名：`publishkit_transfer_packing`
> - 中文名称：应用打包记录
> - 所属模块：e-Builder应用建模
> - 所属数据库：`techdoc`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：梁威（上海）
> - 是否公共配置：0
> - 描述：应用打包记录
> - 数据ID：`968063101437108240`
> - 最后更新：2024-02-22 17:39:15

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | app_id | 应用ID | 长整型 |  |  |  |  |  |  |  |  |
| 8 | app_name | 应用名称 | 字符 | 256 |  |  |  |  |  |  |  |
| 9 | file_id | 文件ID | 长整型 |  |  |  |  |  |  |  |  |
| 10 | app_version | 应用版本 | 字符 | 100 |  |  |  |  |  |  |  |
| 11 | operate_type | 操作类型 | 字符 | 100 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/techdoc]]
