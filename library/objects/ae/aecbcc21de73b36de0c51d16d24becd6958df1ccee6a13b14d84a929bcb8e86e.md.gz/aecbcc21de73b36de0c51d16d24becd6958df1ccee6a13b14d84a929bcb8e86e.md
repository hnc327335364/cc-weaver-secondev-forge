---
title: "4.3 根据关键字查询人员信息（getEmployeeByKeyWords）"
docId: "416420941266944000"
source: "https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/repository/91f5067f-775e-48f4-93a2-ce84ca0b9c2e/doc/416420941266944000"
---
1. 拦截返回信息
  
    - 二开标识： HRM_COM_getEmployeeByKeyWords
    - 入参说明
      
      | 参数 | 类型 | 说明 |
      | --- | --- | --- |
      | userList | List<EMUser> | 内部人员信息 |
      |  |  |  |
      
          - EMUser对象说明
            
            | 参数 | 类型 | 说明 |
            | --- | --- | --- |
            | id | Long | 人员id |
            | name | string | 人员名称 |
            | departmentId | Long | 部门id |
            | subCompany | string | 分部id |
            | mobile | string | 手机 |
            | telephone | string | 电话 |
            | tenantKey | string | 租户 |
            | jobNum | string | 工号 |
    - 示例
      
      ```java
      Map<String, Object> params = request.getParams();
      
              ObjectMapper objectMapper = new ObjectMapper();
              List<Map<String, Object>> userList = objectMapper.convertValue(
                      params.get("userList"), new TypeReference<List<Map<String, Object>>>() {
                      }
              );
              if(CollectionUtils.isEmpty(userList)) return response ;
      
              HrmStreamsUtil.forEach(userList,map->{
                  map.put("mobile","") ;
                  map.put("telephone","") ;
              });
              HashMap<Object, Object> result = new HashMap<>();
              result.put("result", userList);
              response.setResult(result);
              return response;
      ```
