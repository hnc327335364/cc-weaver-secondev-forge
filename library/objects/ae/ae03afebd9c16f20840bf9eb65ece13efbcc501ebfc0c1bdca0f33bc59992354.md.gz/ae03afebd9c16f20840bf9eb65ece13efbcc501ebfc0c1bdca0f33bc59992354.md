---
table_name: mainline_ph_mt_mainline_share
cn_name: 项目模板权限表
module: 项目协作
database: project
type: 普通表
owner: 闫宇
creator: 系统管理员
public_config: 0
data_id: 100655700000006352
has_fields: true
tags: [E10, 数据字典]
---

# mainline_ph_mt_mainline_share

> 项目模板权限表

> [!info] 基本信息
> - 数据库表名：`mainline_ph_mt_mainline_share`
> - 中文名称：项目模板权限表
> - 所属模块：项目协作
> - 所属数据库：`project`
> - 表类型：普通表
> - 负责人：闫宇
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：项目模板权限表
> - 数据ID：`100655700000006352`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | module_id | 模块id | 字符 | 64 |  |  |  |  |  |  |  |
| 2 | source_type | 资源类型 | 整型 |  |  |  |  |  |  |  |  |
| 3 | source_origin_id | 资源标识id | 长整型 |  |  |  |  |  |  |  |  |
| 4 | source_id | 资源id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | source_sub_id | 子资源id | 长整型 |  |  |  |  |  |  |  |  |
| 6 | source_create_time | 资源创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 7 | source_min_sec_level | 资源最小安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 8 | source_max_sec_level | 资源最大安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 9 | source_station_level | 权限 | 整型 |  |  |  |  |  |  |  |  |
| 10 | source_role_level | 资源角色级别 | 整型 |  |  |  |  |  |  |  |  |
| 11 | source_organization_dimension | 资源组织维度 | 整型 |  |  |  |  |  |  |  |  |
| 12 | target_type | 权限对象类型 | 整型 |  |  |  |  |  |  |  |  |
| 13 | target_id | 权限对象id | 长整型 |  |  |  |  |  |  |  |  |
| 14 | target_sub_id | 权限子对象id | 长整型 |  |  |  |  |  |  |  |  |
| 15 | target_min_sec_level | 权限对象最小安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 16 | target_max_sec_level | 权限对象最大安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 17 | target_station_level | 权限 | 整型 |  |  |  |  |  |  |  |  |
| 18 | target_station_bs_id | 权限id | 长整型 |  |  |  |  |  |  |  |  |
| 19 | target_role_level | 权限角色级别 | 整型 |  |  |  |  |  |  |  |  |
| 20 | target_organization_dimension | 权限对象组织维度 | 整型 |  |  |  |  |  |  |  |  |
| 21 | target_subordinate_include | 权限对象是否包含下级 | 整型 |  |  |  |  |  |  |  |  |
| 22 | permission_type | 权限值 | 整型 |  |  |  |  |  |  |  |  |
| 23 | permission_config_id | 权限设置id | 长整型 |  |  |  |  |  |  |  |  |
| 24 | permission_config_source_id | 权限设置资源id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/项目协作]]
- 数据库索引：[[数据库索引/project]]
