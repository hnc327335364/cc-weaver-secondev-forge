---
table_name: t_import_group_info
cn_name: e9群信息导入
module: 聊天消息
database: db_im
type: 普通表
owner: 钱文明
creator: 钱文明
public_config: 0
data_id: 100655700000006010
has_fields: true
tags: [E10, 数据字典]
---

# t_import_group_info

> e9群信息导入

> [!info] 基本信息
> - 数据库表名：`t_import_group_info`
> - 中文名称：e9群信息导入
> - 所属模块：聊天消息
> - 所属数据库：`db_im`
> - 表类型：普通表
> - 负责人：钱文明
> - 创建者：钱文明
> - 是否公共配置：0
> - 描述：e9群信息导入
> - 数据ID：`100655700000006010`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | fcreate_tm | fcreate_tm | 整型 | 11 |  |  |  |  |  |  |  |
| 2 | fupdate_tm | fupdate_tm | 整型 | 11 |  |  |  |  |  |  |  |
| 3 | fcid | fcid | 长整型 | 20 |  |  |  |  |  |  |  |
| 4 | fe9_gid | fe9_gid | 字符 | 64 |  |  |  |  |  |  |  |
| 5 | fgroup_id | fgroup_id | 长整型 | 20 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/聊天消息]]
- 数据库索引：[[数据库索引/db_im]]
