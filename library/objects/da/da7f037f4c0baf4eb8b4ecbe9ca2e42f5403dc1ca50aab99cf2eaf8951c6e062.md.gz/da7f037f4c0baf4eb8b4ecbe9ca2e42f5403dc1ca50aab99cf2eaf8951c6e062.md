# 消息提醒

来源快照：`result_data_new_260518.json`

- 来源 ID：`1190964336404226247`
- 模块：低代码平台e-builder
- 目录：动作流 - 执行组件
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 概述

在消息提醒是系统中确保用户及时获取关键信息、避免遗漏重要操作的核心功能。

 

类型| 组件名称| 描述  
---|---|---  
执行组件| 消息提醒| 用于发送消息  
  
 

# 使用说明

### 消息提醒

#### 功能介绍：

消息组件，主要用于消息的发送，主要包含IM、云桥、邮件、短信等消息渠道

推送渠道：主要包括IM、云桥、邮件、短信等，用于确认需要通过什么方式发送消息。

提醒标题：消息标题

提醒内容：消息内容

推送图片url：消息推送的图片

PC端链接：PC端消息提醒体可跳转的地址

发送人：消息的发送人

操作人：消息的操作人

提醒对象：消息接收人（包括人员、部门、分部、角色、群组、岗位、人员选择范围、外部联系人等）

自定义参数：拓展参数，用于特殊客户的需求

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964392299872267&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

#### 使用案例：

流程归档后，需要提醒对应的人，流程已归档，可执行后续工作内容，应该怎么配置？

##### 操作步骤：

1.

从ESB中心，动作流列表创建动作流

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964392244764685&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、触发类型流程触发，选择对应的流程

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964396485787649&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3、执行组件选择消息提醒

4、推送渠道选择，IM消息推送的方式

（1）PC端推送方式：/sp/workflow/flowpage/view/#{param1}

（2）移动端推送方式：/sp/workflow/adapter/flowpage/view/#{param1}

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964392268963844&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

5、发送人选择小助手 。

6、提醒对象选择人员，映射选择流程的人员选字段字段

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964392384897034&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

7、流程归档后，收到了对应的IM消息：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964392384897038&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

8、消息可支持调转流程，点击消息体即可

9、消息的推送日志可在后端查看推送日志

![](https://weapp.eteams.cn/papi/file/preview?fileId=1190964392268963842&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 常见问答，可查看文档：[https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1263446037087969306&freepass_doc=1&space_id=1157961794811633670](https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1263446037087969306&freepass_doc=1&space_id=1157961794811633670)

1、流程的PC端跳转链接和移动端跳转链接是什么？

答：PC: /sp/workflow/flowpage/view/#{param1}

移动端：/sp/workflow/adapter/flowpage/view/#{param1}

2、业务表单的PC端跳转链接和移动端跳转链接是什么？

答：PC： /sp/formreport/reportDetail/{reportId}?openType=new

移动端： /mobile/formreport/dataDetail/{reportId}

3、ebuilder表单的PC端跳转链接和移动端跳转链接是什么？

答：PC：/sp/ebdfpage/card/0/{objid}/{dataid}

移动端链接：/mobile/ebdfpage/card/0/{objid}/{dataid}

4、配置了推送云桥，为什么没有推送云桥成功

答：需要预先配置好云桥推送模版
