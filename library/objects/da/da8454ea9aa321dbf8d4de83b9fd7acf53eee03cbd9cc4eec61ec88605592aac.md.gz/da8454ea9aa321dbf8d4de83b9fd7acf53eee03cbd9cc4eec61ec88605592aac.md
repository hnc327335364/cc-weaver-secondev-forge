---
table_name: esb_large_data__abandon
cn_name: esb过大数据丢弃表
module: ESB中心
database: esb_setting
type: 普通表
owner: 程新
creator: 陈正
public_config: 0
data_id: 929122299575820292
has_fields: true
tags: [E10, 数据字典]
---

# esb_large_data__abandon

> esb过大数据丢弃表

> [!info] 基本信息
> - 数据库表名：`esb_large_data__abandon`
> - 中文名称：esb过大数据丢弃表
> - 所属模块：ESB中心
> - 所属数据库：`esb_setting`
> - 表类型：普通表
> - 负责人：程新
> - 创建者：陈正
> - 是否公共配置：0
> - 描述：esb过大数据丢弃表
> - 数据ID：`929122299575820292`
> - 最后更新：2023-11-09 19:09:03

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | from_type | 来源类型 | 整型 |  |  |  |  |  |  |  |  |
| 8 | abandon_content | 丢弃内容 | 大字段1 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/ESB中心]]
- 数据库索引：[[数据库索引/esb_setting]]
