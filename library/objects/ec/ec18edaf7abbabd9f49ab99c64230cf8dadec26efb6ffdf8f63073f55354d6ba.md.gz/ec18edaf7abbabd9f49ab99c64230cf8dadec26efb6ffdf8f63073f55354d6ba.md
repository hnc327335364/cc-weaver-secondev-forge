# 普通打印机

来源快照：`result_data_new_260518.json`

- 来源 ID：`1251553818109657130`
- 模块：资产管理
- 目录：标签打印
- space ID：`1183287979989131273`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 1.单资产标签打印

在任何资产卡片的右上角，点击更多按钮，选中“打印”

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554921767976965&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

新打开标签页“表单打印”

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554926061953024&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

点击打印即可使用普通打印机打印

# 2.批量打印

在资产列表右上角批量操作选择批量打印

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554926205083655&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

可批量选择图片进行打印

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554921893339141&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

选择打印模板

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554930369200129&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

点击开始跳转打印

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554934870515718&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 3.标签模版设置

低代码平台e-builder-表单-资产使用-打印设置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554930516828164&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

新建选择网页版

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554934879371270&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

使用组件、已有字段、富文本进行表单设置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554930516828167&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 4\. 一页打印多个标签

在资产列表中选中批量聚合打印

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554926061953029&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

批量选择要打印的数据

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554926065844230&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

选择打印模板，点击开始打印

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554926061953039&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

配置打印参数（这个方法对批量打印也适用）

![](https://weapp.eteams.cn/papi/file/preview?fileId=1251554930465972225&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

预览没问题后开始打印！
