# 2025年9月更新

来源快照：`result_data_new_260518.json`

- 来源 ID：`1189110954923245601`
- 模块：项目管理
- 目录：产品功能更新日志 - 2025年更新
- space ID：`1973261491939008706`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# **一、更新清单（基线版本：20250901）**

1.【通用项目管理】项目甘特图中支持设置显示交付物信息，包括交付物总数和完成情况。

2.【通用项目管理】单项目空间新增开关设置，开启后，会显示【单项目空间】按钮，关闭后，则会隐藏按钮。

3.【通用项目管理】项目类型设置中维护交付物信息，设置后，项目立项时自动生成需要的上传交付物。

4.【科研项目管理】项目申报时，经费预算填报简化，采用经费汇总和明细表的方式填报。

5.【科研项目管理】项目变更流程新增【项目任务变更】和【经费预算变更】。

# **二、功能介绍**

1【通用项目管理】项目甘特图中支持设置显示交付物信息，包括交付物总数和完成情况。

（1）EB甘特图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189111624962424837&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）事井然第三方甘特图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189111685150687234&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.【通用项目管理】单项目空间新增开关设置，开启后，会显示【单项目空间】按钮，关闭后，则会隐藏按钮。

（1）管理员可在基础设置-项目设置-其他设置中，开启或关闭单项目空间。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189111762343796747&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）开启后，在【我的项目】列表和项目卡片右上角会显示【单项目空间】按钮，关闭后，则会隐藏按钮。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189111822618419222&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3\. 【通用项目管理】项目类型设置中维护交付物信息，设置后，项目立项时自动生成需要的上传交付物。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189111904281518100&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

4.【科研项目管理】项目申报时，经费预算填报简化，采用经费汇总和明细表的方式填报。

（1）纵向项目申报

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189111964408586255&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）横向项目立项

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189112015854780433&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

5.【科研项目管理】项目变更流程新增【项目任务变更】和【经费预算变更】。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1189112071792664577&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
