# 支持选择已有业务作为下级并且支持穿透查看

来源快照：`result_data_new_260518.json`

- 来源 ID：`1258579800335903645`
- 模块：端到端业务流
- 目录：功能更新说明 - 2026-03
- space ID：`1966562461856217437`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、**功能背景**

目前下级业务只能是新建或者复制已有的，不能直接选已有的，并且存在下级业务的节点目前没有标记，前台如果要穿透查看的话必须要配置交互动作，后台穿透查看的话必须从左侧树看，这些交互体验不好，本次一并调整支持、

# **二、功能详细说明**

1、选中某个节点，维护下级业务流时，支持从已有的业务流中选择，效果如下图所示；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1258578812635512833&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、选择下级业务之后，节点上会有相应标记，表示这个节点存在下级业务，效果如下图所示；前台查看页面，鼠标移入此标记，也会有小卡片显示对应的下级业务，支持点击穿透查看；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1258579169058471946&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1258579379461537797&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
