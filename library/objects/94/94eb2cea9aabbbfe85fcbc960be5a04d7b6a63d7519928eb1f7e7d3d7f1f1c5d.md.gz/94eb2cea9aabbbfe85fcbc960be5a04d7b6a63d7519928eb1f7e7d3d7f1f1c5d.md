---
table_name: auth_common_risk_policy_type
cn_name: 策略类型表
module: 统一认证公共服务
database: int_unify_auth_common
type: 普通表
owner: 张保
creator: 王杰（上海）
public_config: 0
data_id: 1165799556027506840
has_fields: true
tags: [E10, 数据字典]
---

# auth_common_risk_policy_type

> 策略类型表

> [!info] 基本信息
> - 数据库表名：`auth_common_risk_policy_type`
> - 中文名称：策略类型表
> - 所属模块：统一认证公共服务
> - 所属数据库：`int_unify_auth_common`
> - 表类型：普通表
> - 负责人：张保
> - 创建者：王杰（上海）
> - 是否公共配置：0
> - 描述：统一认证公共服务-风险策略-策略类型表
> - 数据ID：`1165799556027506840`
> - 最后更新：2025-08-08 14:17:41

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | policy_type | 类型标识 | 字符 | 200 |  |  |  |  |  |  |  |
| 8 | policy_name | 类型名称 | 字符 | 200 |  |  |  |  |  |  |  |
| 9 | policy_name_labelid | 类型名称多语言id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/统一认证公共服务]]
- 数据库索引：[[数据库索引/int_unify_auth_common]]
