---
table_name: intunifyauth_ldap_ilogs_detail
cn_name: 统一认证接入域认证源配置操作日志明细表
module: 统一认证接入
database: int_unify_auth_client
type: 普通表
owner: 张保
creator: 吴琦
public_config: 0
data_id: 1234848469843910660
has_fields: true
tags: [E10, 数据字典]
---

# intunifyauth_ldap_ilogs_detail

> 统一认证接入域认证源配置操作日志明细表

> [!info] 基本信息
> - 数据库表名：`intunifyauth_ldap_ilogs_detail`
> - 中文名称：统一认证接入域认证源配置操作日志明细表
> - 所属模块：统一认证接入
> - 所属数据库：`int_unify_auth_client`
> - 表类型：普通表
> - 负责人：张保
> - 创建者：吴琦
> - 是否公共配置：0
> - 描述：统一认证接入域认证源配置操作日志明细表
> - 数据ID：`1234848469843910660`
> - 最后更新：2026-02-10 16:02:44

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | 日志UUID | 字符 | 36 |  |  |  |  |  |  |  |
| 8 | mainid | 主表id | 字符 | 36 |  |  |  |  |  |  |  |
| 9 | dataid | 数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 10 | belongdataid | 主表数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 11 | tablename | 表名 | 字符 | 200 |  |  |  |  |  |  |  |
| 12 | tablenamelabelid | 表名labelid | 字符 | 50 |  |  |  | -1 |  |  |  |
| 13 | tablenamedesc | 对应数据库的表 | 字符 | 50 |  |  |  |  |  |  |  |
| 14 | fieldname | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 15 | fieldnamelabelid | 字段名labelid | 字符 | 50 |  |  |  | -1 |  |  |  |
| 16 | newvalue | 更新后的值 | 大字段1 |  |  |  |  |  |  |  |  |
| 17 | oldvalue | 更新前的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 18 | newrealvalue | 更新后的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 19 | oldrealvalue | 更新前的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 20 | fielddesc | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 21 | showorder | 字段名 | 整型 |  |  |  |  |  |  |  |  |
| 22 | isdetail | 是否明细字段 | 整型 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/统一认证接入]]
- 数据库索引：[[数据库索引/int_unify_auth_client]]
