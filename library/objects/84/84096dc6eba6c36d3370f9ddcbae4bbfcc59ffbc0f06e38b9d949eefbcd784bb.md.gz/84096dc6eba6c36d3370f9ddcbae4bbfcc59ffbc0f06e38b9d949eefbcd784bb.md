---
table_name: ebda_app_folderlogs_detail
cn_name: eb文件夹操作日志详情
module: e-Builder页面引擎
database: ebuilder_app
type: 普通表
owner: 常程
creator: 熊雪兵
public_config: 0
data_id: 1230356127128928369
has_fields: true
tags: [E10, 数据字典]
---

# ebda_app_folderlogs_detail

> eb文件夹操作日志详情

> [!info] 基本信息
> - 数据库表名：`ebda_app_folderlogs_detail`
> - 中文名称：eb文件夹操作日志详情
> - 所属模块：e-Builder页面引擎
> - 所属数据库：`ebuilder_app`
> - 表类型：普通表
> - 负责人：常程
> - 创建者：熊雪兵
> - 是否公共配置：0
> - 描述：eb文件夹操作日志详情
> - 数据ID：`1230356127128928369`
> - 最后更新：2026-01-29 13:30:09

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | 日志UUID | 字符 | 36 |  |  |  |  |  |  |  |
| 8 | mainid | 主表id | 字符 | 36 |  |  |  |  |  |  |  |
| 9 | dataid | 数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 10 | belongdataid | 主表数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 11 | tablename | 表名 | 字符 | 200 |  |  |  |  |  |  |  |
| 12 | tablenamelabelid | 表名labelid | 字符 | 50 |  |  |  | -1 |  |  |  |
| 13 | newvalue | 更新后的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 14 | oldvalue | 更新前的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 15 | newrealvalue | 更新后的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 16 | oldrealvalue | 更新前的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 17 | fielddesc | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 18 | showorder | 字段名 | 整型 | 11 |  |  |  |  |  |  |  |
| 19 | isdetail | 是否明细字段 | 整型 | 11 |  |  |  |  |  |  |  |
| 20 | tablenamedesc | 对应数据库的表 | 字符 | 50 |  |  |  |  |  |  |  |
| 21 | fieldname | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 22 | fieldnamelabelid | 字段名labelid | 字符 | 50 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder页面引擎]]
- 数据库索引：[[数据库索引/ebuilder_app]]
