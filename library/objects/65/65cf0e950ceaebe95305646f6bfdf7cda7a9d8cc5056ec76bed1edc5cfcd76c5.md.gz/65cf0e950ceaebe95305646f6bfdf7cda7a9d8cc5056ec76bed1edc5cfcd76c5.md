---
table_name: formdatareport_fclogs_detail
cn_name: 调查日志详情表
module: 业务表单
database: formreport
type: 普通表
owner: 杨亚飞
creator: 系统管理员
public_config: 0
data_id: 100655700000006381
has_fields: true
tags: [E10, 数据字典]
---

# formdatareport_fclogs_detail

> 调查日志详情表

> [!info] 基本信息
> - 数据库表名：`formdatareport_fclogs_detail`
> - 中文名称：调查日志详情表
> - 所属模块：业务表单
> - 所属数据库：`formreport`
> - 表类型：普通表
> - 负责人：杨亚飞
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：调查日志详情表
> - 数据ID：`100655700000006381`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | uuid | 日志UUID | 字符 | 30 |  |  |  |  |  |  |  |
| 2 | mainid | 主表id | 字符 | 30 |  |  |  |  |  |  |  |
| 3 | dataid | 数据id | 字符 | 30 |  |  |  |  |  |  |  |
| 4 | belongdataid | 主表数据id | 字符 | 30 |  |  |  |  |  |  |  |
| 5 | tablename | 表名 | 字符 | 200 |  |  |  |  |  |  |  |
| 6 | tablenamelabelid | 表名labelid | 字符 | 20 |  |  |  |  |  |  |  |
| 7 | tablenamedesc | 对应数据库的表 | 字符 | 50 |  |  |  |  |  |  |  |
| 8 | fieldname | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 9 | fieldnamelabelid | 字段名labelid | 字符 | 30 |  |  |  |  |  |  |  |
| 10 | newvalue | 更新后的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 11 | oldvalue | 更新前的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 12 | newrealvalue | 更新后的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 13 | oldrealvalue | 更新前的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 14 | fielddesc | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 15 | showorder | 排序 | 整型 |  |  |  |  |  |  |  |  |
| 16 | isdetail | 是否明细字段 | 整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/业务表单]]
- 数据库索引：[[数据库索引/formreport]]
