# 自定义词典

来源快照：`result_data_new_260518.json`

- 来源 ID：`1215177717176320047`
- 模块：全文搜索
- 目录：全文搜索引擎 - 全文搜索管理运维平台 - 词典维护
- space ID：`1167301145407184915`
- 原文链接：未提供
- 产品基线：未提供

## 正文

1.

# 背景

当前全文搜索引擎采用通用分词器，对企业特有的专业名词（如产品代号、内部术语）、行业术语等识别不准确，导致：搜索命中率低：专业词汇被错误拆分，无法精准匹配结果；高亮显示错位：分词错误导致关键词高亮位置偏移，影响用户体验；业务适配性差：无法动态管理新增词汇，依赖技术团队手动更新词库。

1.1.

## 功能描述

租户管理平台-全文搜索管理页面增加词典维护-自定义词典页面，支持手工添加词汇；提供词汇新增、编辑、删除等管理功能；支持批量导入/导出词汇操作。

2.

# 功能说明

## 2.1 功能入口

租户管理平台-全文搜索管理-词典维护-自定义词典

![](https://weapp.eteams.cn/papi/file/preview?fileId=1268230347120312335&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2.2 功能描述

1、词典可视化维护：提供词库列表页面，支持按词语、状态搜索，展示创建人、时间等关键信息，支持手动添加新词，单条删除/编辑。 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1268230454611935247&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、 批量操作支持：支持通过Excel模板批量导入词汇数据，提供批量删除，提升管理效率。 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1215182398747779085&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3、状态精细管理：词汇状态可视化（未提交，已提交，已存在），便于快速识别，所有操作记录日志，满足审计要求。 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1215182553205596166&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1215182656314531850&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2.3 功能说明

权限控制：需具备租户管理平台-全文搜索管理的维护权限。 

多语言支持：界面与词汇内容均支持国际化，适应跨国企业部署。 

技术集成：自定义词汇将实时同步至搜索引擎分词器，即时生效。 

性能保障：通过缓存机制确保词库加载效率，不影响搜索响应速度。
