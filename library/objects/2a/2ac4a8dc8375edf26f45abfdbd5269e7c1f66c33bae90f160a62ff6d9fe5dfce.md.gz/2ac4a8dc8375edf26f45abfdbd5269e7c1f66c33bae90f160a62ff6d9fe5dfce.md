---
table_name: hrsa_archiverulelogs
cn_name: 社保档案规则日志表
module: 薪酬管理
database: hrm_salary
type: 普通表
owner: 蔡志军
creator: 系统管理员
public_config: 0
data_id: 100655700000007079
has_fields: true
tags: [E10, 数据字典]
---

# hrsa_archiverulelogs

> 社保档案规则日志表

> [!info] 基本信息
> - 数据库表名：`hrsa_archiverulelogs`
> - 中文名称：社保档案规则日志表
> - 所属模块：薪酬管理
> - 所属数据库：`hrm_salary`
> - 表类型：普通表
> - 负责人：蔡志军
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：社保档案规则日志表
> - 数据ID：`100655700000007079`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | uuid | 日志UUID | 字符 | 36 |  |  |  |  |  |  |  |
| 2 | log_date | 记录时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | device | 终端信息 | 字符 | 500 |  |  |  |  |  |  |  |
| 4 | log_operator | 操作者 | 长整型 |  |  |  |  |  |  |  |  |
| 5 | operatorname | 操作人姓名 | 字符 | 100 |  |  |  |  |  |  |  |
| 6 | targetid | 操作目标id | 长整型 |  |  |  |  | -1 |  |  |  |
| 7 | targetname | 操作目标名称 | 大字段1 |  |  |  |  |  |  |  |  |
| 8 | modulename | 模块 | 字符 | 100 |  |  |  |  |  |  |  |
| 9 | functionname | 服务（方法） | 字符 | 100 |  |  |  |  |  |  |  |
| 10 | interfacename | 访问接口名 | 字符 | 100 |  |  |  |  |  |  |  |
| 11 | requesturl | 请求全路径 | 字符 | 200 |  |  |  |  |  |  |  |
| 12 | requesturi | 请求地址 | 字符 | 200 |  |  |  |  |  |  |  |
| 13 | operatetype | 操作类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 14 | operatetypename | 操作类型名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 15 | operatedesc | 操作详细说明 | 字符 | 3000 |  |  |  |  |  |  |  |
| 16 | params | 涉及的相关参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 17 | belongmainid | 所属主表uuid | 字符 | 36 |  |  |  |  |  |  |  |
| 18 | clientip | 操作IP | 字符 | 50 |  |  |  |  |  |  |  |
| 19 | groupid | 分组 | 字符 | 50 |  |  |  |  |  |  |  |
| 20 | groupnamelabel | 分组标题 | 字符 | 1000 |  |  |  |  |  |  |  |
| 21 | redoservice | 重做业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 22 | redocontext | 重做参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 23 | cancelservice | 撤销业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 24 | cancelcontext | 撤销参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 25 | totalruntime | 总运行时长 | 长整型 |  |  |  |  | 0 |  |  |  |
| 26 | mainruntime | 主方法运行时长 | 长整型 |  |  |  |  | 0 |  |  |  |
| 27 | log_result | 日志结果 | 字符 | 100 |  |  |  |  |  |  |  |
| 28 | fromterminal | 来自pc web | 字符 | 100 |  |  |  |  |  |  |  |
| 29 | resultdesc | 运行结果描述 | 大字段1 |  |  |  |  |  |  |  |  |
| 30 | old_content | 原先内容 | 字符 | 3000 |  |  |  |  |  |  |  |
| 31 | link_type | 链接类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 32 | link_id | 链接id | 长整型 |  |  |  |  | 0 |  |  |  |
| 33 | old_link_id | 原先链接id | 长整型 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/薪酬管理]]
- 数据库索引：[[数据库索引/hrm_salary]]
