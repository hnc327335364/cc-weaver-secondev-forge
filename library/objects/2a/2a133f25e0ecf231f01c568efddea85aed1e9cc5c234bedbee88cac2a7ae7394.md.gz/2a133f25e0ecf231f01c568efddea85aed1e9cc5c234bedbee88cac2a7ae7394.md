**简要描述：** 

- 获取businessId

**请求URL：** 
- `{host}/api/bs/mc/handle/messageRule/getBusinessId
  
**请求方式：**
- POST   http payload

**参数：** 
``` 
{
}
```
|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |

 **返回示例**

``` 
{"code":200,"data":"578023553463566336","msg":"接口返回成功","status":true}
```

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|code |int   |200成功  |
|data |long   |businessId  |




 **备注** 

- 更多返回错误代码请看首页的错误代码描述
