# 向量知识库

来源快照：`result_data_new_260518.json`

- 来源 ID：`1175088509632987203`
- 模块：AI连接器
- 目录：AI连接器后台配置介绍
- space ID：`1171014986362470480`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景及价值用途

传统数据库依赖关键词匹配，无法理解数据语义，面对文本、图片等非结构化数据时检索精度低，且大模型存在 “知识 cutoff”（知识过时）和 “幻觉” 问题，需要实时、可靠的外部数据补充来提升回答准确性。 向量知识库可以通过整合解析文档、图片、等数据，给出针对性回复，帮助用户快速、精准地获取信息。

# 二、功能概述

向量知识库主要包含新建数据组、检索测试、高级搜索、数据列表、向量知识库菜单权限控制等相关功能。

# 三、功能详细说明

## 1、功能入口

AI连接器-向量知识库，如下图所示：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958084668022795&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2、插件列表数据

### 2.1向量知识库数据列表

向量知识库数据列表相关功能包含：新建数据组、检索测试、高级搜索、列表数据、列表操作

1）

高级搜索：搜索条件包含数据组名称、描述

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958106117693442&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2）

列表数据主要展示：数据组名称、数据组描述、转向量模型、创建人、更新时间

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958093409837056&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3）

列表行操作：选中行可进行查看文件数据、编辑、删除操作

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958089147539461&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 2.2新建数据组

点击【新建数据组】创建数据组

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958106117693446&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1）

转向量模型：默认显示全局设置中的向量模型，可选择其他向量模型

2）

开启权限控制：开启后，搜索数据文件的权限受权限范围设置控制

3）

允许被跨系统访问：启用后通过配置白名单和黑名单，让其他系统智能体可以访问此数据组，入口如下图所示：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958088913543171&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 2.3上传数据文件

通过以下三种方式上传数据文件：上传数据、手动添加、批量新增

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958093409837057&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

#### 2.3.1上传数据

可选择的数据类型包含：文件上传、问答

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958088913543175&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1）

文件上传

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958097521328129&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

上传文件后可通过不同分割类型分割多个数据片段：

①

默认分片策略：先根据/n/n拆 ，拆出的片段如果超过设置的分块大小，再根据/n拆，如果还超出，再根据空格拆

②

自定义切片符：根据自定义分割符来分割，拆出的片段如果超过设置的分块大小，直接根据分块大小再次分割

③

按层级分片：仅MinerU和转Markdown解析方式支持，按照文档层级结构一级标题/二级标题/三级标题/四级标题/五级标题/六级标题进行分段

2）

问答

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958093385744390&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

上传文件后根据标题层级进行分段，将标题作为问题，将片段内容作为答案，不限制片段内容长度。

#### 2.3.2手动添加

1）

数据类型选择：文本片段

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958084786348038&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2）数据类型选择：问答

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958084668022790&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

#### 2.3.3批量新增

1）数据类型选择：文件上传

可上传多个附件和文档

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958097594867716&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2）数据类型选择：问答

可上传多个附件和文档

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958089082388483&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 2.4检索测试

可选择数据组，输入内容后进行检索测试，如下图所示：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958093409837058&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

### 2.5向量知识库数据来源

① 新建数据组

② 智能体内新建的向量知识库（个人向量知识库数据不保存在此处）

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958093232791561&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 3、权限控制

【向量知识库】菜单受功能权限-向量知识库菜单控制，勾选后AI连接器模块显示该菜单，不勾选则AI连接器模块不显示该菜单，系统管理员默认勾选。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1222958097521328137&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 四、使用注意点

无

# 五、更多参考资料

1、向量知识库的单页地址：

/sp/ai/main/setting/vectorConfig
