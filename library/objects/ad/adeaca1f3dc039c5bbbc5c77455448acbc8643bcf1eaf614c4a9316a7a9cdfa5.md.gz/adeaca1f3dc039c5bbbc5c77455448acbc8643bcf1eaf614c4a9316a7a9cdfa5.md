---
table_name: inc_syncclaimlogs
cn_name: 发票归集列表认领记录主表
module: 发票助手
database: weaver_inc
type: 普通表
owner: 温明刚
creator: 袁强强
public_config: 0
data_id: 1110526256302899250
has_fields: true
tags: [E10, 数据字典]
---

# inc_syncclaimlogs

> 发票归集列表认领记录主表

> [!info] 基本信息
> - 数据库表名：`inc_syncclaimlogs`
> - 中文名称：发票归集列表认领记录主表
> - 所属模块：发票助手
> - 所属数据库：`weaver_inc`
> - 表类型：普通表
> - 负责人：温明刚
> - 创建者：袁强强
> - 是否公共配置：0
> - 描述：需要记录发票归集的数据认领的记录信息
> - 数据ID：`1110526256302899250`
> - 最后更新：2025-03-12 15:29:03

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | uuid | 字符 | 36 |  |  |  |  |  |  |  |
| 8 | log_date | 操作时间 | 日期时间 |  |  |  |  | CURRENT_TIMESTAMP |  |  |  |
| 9 | device | 终端信息 | 字符 | 500 |  |  |  |  |  |  |  |
| 10 | log_operator | 操作人 | 长整型 |  |  |  |  |  |  |  |  |
| 11 | operatorname | 操作人姓名 | 字符 | 100 |  |  |  |  |  |  |  |
| 12 | targetid | 操作目标id | 长整型 |  |  |  |  |  |  |  |  |
| 13 | targetname | 操作目标名称 | 字符 | 3000 |  |  |  |  |  |  |  |
| 14 | modulename | 模块 | 字符 | 100 |  |  |  |  |  |  |  |
| 15 | functionname | 服务（方法） | 字符 | 100 |  |  |  |  |  |  |  |
| 16 | requesturl | 请求全路径 | 字符 | 3000 |  |  |  |  |  |  |  |
| 17 | requesturi | 请求地址 | 字符 | 3000 |  |  |  |  |  |  |  |
| 18 | operatetype | 操作类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 19 | operatetypename | 操作类型名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 20 | operatedesc | 操作详细说明 | 字符 | 3000 |  |  |  |  |  |  |  |
| 21 | params | 涉及的相关参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 22 | belongmainid | 所属主表uuid | 字符 | 36 |  |  |  |  |  |  |  |
| 23 | clientip | 操作IP | 字符 | 200 |  |  |  |  |  |  |  |
| 24 | groupid | 分组 | 字符 | 50 |  |  |  |  |  |  |  |
| 25 | groupnamelabel | 分组标题 | 字符 | 1000 |  |  |  |  |  |  |  |
| 26 | redoservice | 重做业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 27 | redocontext | 重做参数 | 大字段3 |  |  |  |  |  |  |  |  |
| 28 | cancelservice | 撤销业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 29 | cancelcontext | 撤销参数 | 大字段3 |  |  |  |  |  |  |  |  |
| 30 | totalruntime | 总运行时长 | 长整型 |  |  |  |  |  |  |  |  |
| 31 | mainruntime | 主方法运行时长 | 长整型 |  |  |  |  |  |  |  |  |
| 32 | interfacename | 访问接口名 | 字符 | 100 |  |  |  |  |  |  |  |
| 33 | log_result | 运行结果标识 | 字符 | 100 |  |  |  |  |  |  |  |
| 34 | fromterminal | 来自pc web | 字符 | 100 |  |  |  |  |  |  |  |
| 35 | resultdesc | 运行结果描述 | 字符 | 3000 |  |  |  |  |  |  |  |
| 36 | old_content | 原先内容 | 字符 | 3000 |  |  |  |  |  |  |  |
| 37 | link_type | 链接类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 38 | link_id | 链接id | 长整型 |  |  |  |  |  |  |  |  |
| 39 | old_link_id | 原先链接id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/发票助手]]
- 数据库索引：[[数据库索引/weaver_inc]]
