---
table_name: t_sysmsg_user_index_37
cn_name: IM系统消息用户索引表
module: 聊天消息
database: db_im
type: 普通表
owner: 钱文明
creator: 周健健
public_config: 0
data_id: 1209545189504647182
has_fields: true
tags: [E10, 数据字典]
---

# t_sysmsg_user_index_37

> IM系统消息用户索引表

> [!info] 基本信息
> - 数据库表名：`t_sysmsg_user_index_37`
> - 中文名称：IM系统消息用户索引表
> - 所属模块：聊天消息
> - 所属数据库：`db_im`
> - 表类型：普通表
> - 负责人：钱文明
> - 创建者：周健健
> - 是否公共配置：0
> - 描述：IM系统消息用户索引表
> - 数据ID：`1209545189504647182`
> - 最后更新：2025-12-04 11:33:05

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 2 | tenant_key | 租户KEY | 字符 | 20 |  |  |  |  |  |  |  |
| 3 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 5 | creator | 创建人id | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 6 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 7 | fcid | fcid | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 8 | fmsgid | fmsgid | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 9 | fuid | fuid | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 10 | fgroup | fgroup | 整型 |  |  |  |  | 0 |  |  |  |
| 11 | ftype | ftype | 整型 |  |  |  |  | 0 |  |  |  |
| 12 | ftask_id | ftask_id | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 13 | fread_status | fread_status | 整型 |  |  |  |  | 0 |  |  |  |
| 14 | fdeal_status | fdeal_status | 整型 |  |  |  |  | 0 |  |  |  |
| 15 | fdel_flag | fdel_flag | 整型 |  |  |  |  | 0 |  |  |  |
| 16 | fread_time | fread_time | 整型 |  |  |  |  | 0 |  |  |  |
| 17 | fsc | fsc | 大字段1 |  |  |  |  |  |  |  |  |
| 18 | fhas_ds | fhas_ds | 整型 |  |  |  |  | 0 |  |  |  |
| 19 | fignore | fignore | 整型 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/聊天消息]]
- 数据库索引：[[数据库索引/db_im]]
