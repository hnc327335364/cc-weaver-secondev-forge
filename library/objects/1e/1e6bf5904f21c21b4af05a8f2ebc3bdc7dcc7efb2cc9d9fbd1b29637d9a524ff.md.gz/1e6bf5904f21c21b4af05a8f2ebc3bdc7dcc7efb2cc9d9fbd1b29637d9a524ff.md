---
table_name: file_info
cn_name: 文件信息
module: 发票助手
database: weaver_inc
type: 普通表
owner: 温明刚
creator: 彭超
public_config: 0
data_id: 952106095551332366
has_fields: true
tags: [E10, 数据字典]
---

# file_info

> 文件信息

> [!info] 基本信息
> - 数据库表名：`file_info`
> - 中文名称：文件信息
> - 所属模块：发票助手
> - 所属数据库：`weaver_inc`
> - 表类型：普通表
> - 负责人：温明刚
> - 创建者：彭超
> - 是否公共配置：0
> - 描述：文件信息
> - 数据ID：`952106095551332366`
> - 最后更新：2024-01-10 17:37:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | file_name | 文件名称 | 字符 | 200 |  |  |  |  |  |  | 文件名称 |
| 8 | file_type | 文件类型 | 字符 | 100 |  |  |  |  |  |  | 文件类型 |
| 9 | file_flag | 文件标识 | 整型 |  |  |  |  |  |  |  | 文件标识 |
| 10 | travel_fid | travel_fid | 长整型 |  |  |  |  |  |  |  |  |
| 11 | file_del | 删除标识 | 整型 |  |  |  |  |  |  |  | 删除标识 |
| 12 | file_ctm | 创建时间 | 长整型 |  |  |  |  |  |  |  | 创建时间 |
| 13 | file_size | 文件大小 | 长整型 |  |  |  |  |  |  |  | 文件大小 |
| 14 | file_img_id | imgId | 字符 | 100 |  |  |  |  |  |  | imgId |
| 15 | file_doc_id | docId | 字符 | 100 |  |  |  |  |  |  | docId |
| 16 | if_id | fid | 长整型 |  |  |  |  |  |  |  |  |
| 17 | ii_id | invoice_info的ID | 长整型 |  |  |  |  |  |  |  |  |
| 18 | file_id | 文件id | 长整型 |  |  |  |  |  |  |  |  |
| 19 | user_cid | user_cid | 长整型 |  |  |  |  |  |  |  |  |
| 20 | user_uid | user_uid | 长整型 |  |  |  |  |  |  |  |  |
| 21 | user_appid | user_appid | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/发票助手]]
- 数据库索引：[[数据库索引/weaver_inc]]
