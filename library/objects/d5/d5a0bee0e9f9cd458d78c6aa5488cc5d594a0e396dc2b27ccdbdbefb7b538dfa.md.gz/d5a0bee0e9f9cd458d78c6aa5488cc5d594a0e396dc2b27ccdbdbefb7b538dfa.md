---
table_name: sender_email_template
cn_name: 
module: 
database: mail
type: 
owner: 
creator: 系统管理员
public_config: 0
data_id: 100655700000002276
has_fields: true
tags: [E10, 数据字典]
---

# sender_email_template

> [!info] 基本信息
> - 数据库表名：`sender_email_template`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`mail`
> - 表类型：—
> - 负责人：—
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000002276`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | height |  | 整型 |  |  |  |  |  |  |  |  |
| 2 | createdate |  | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | code |  | 字符 | 128 |  |  |  |  |  |  |  |
| 4 | default_value |  | 整型 |  |  |  |  | 0 |  |  |  |
| 5 | accound_id | 邮箱账号id | 小数 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/mail]]
