---
table_name: wcw_regularlogs_detail
cn_name: 图标库权限日志
module: 公共业务组件
database: component
type: 普通表
owner: 师源
creator: 系统管理员
public_config: 0
data_id: 100655700000004624
has_fields: true
tags: [E10, 数据字典]
---

# wcw_regularlogs_detail

> 图标库权限日志

> [!info] 基本信息
> - 数据库表名：`wcw_regularlogs_detail`
> - 中文名称：图标库权限日志
> - 所属模块：公共业务组件
> - 所属数据库：`component`
> - 表类型：普通表
> - 负责人：师源
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：图标库权限日志
> - 数据ID：`100655700000004624`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | mainid | 主表id | 字符 | 36 |  |  |  |  |  |  |  |
| 2 | dataid | 数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 3 | belongdataid | 主表数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 4 | tablename | 表名 | 字符 | 200 |  |  |  |  |  |  |  |
| 5 | tablenamelabelid | 表名labelid | 字符 | 50 |  |  |  |  |  |  |  |
| 6 | tablenamedesc | 对应数据库的表 | 字符 | 50 |  |  |  |  |  |  |  |
| 7 | fieldname | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 8 | fieldnamelabelid | 字段名labelid | 字符 | 50 |  |  |  |  |  |  |  |
| 9 | newvalue | 更新后的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 10 | oldvalue | 更新前的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 11 | newrealvalue | 更新后的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 12 | oldrealvalue | 更新前的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 13 | fielddesc | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 14 | showorder | 排序 | 整型 |  |  |  |  |  |  |  |  |
| 15 | isdetail | 是否明细字段 | 整型 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/公共业务组件]]
- 数据库索引：[[数据库索引/component]]
