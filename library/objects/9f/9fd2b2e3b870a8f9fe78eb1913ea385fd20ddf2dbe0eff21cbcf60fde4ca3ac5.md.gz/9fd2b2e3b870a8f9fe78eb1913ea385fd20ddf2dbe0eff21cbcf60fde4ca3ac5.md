---
table_name: esb_rfc_source
cn_name: ESB RFC配置表
module: ESB中心
database: esb_setting
type: 普通表
owner: 程新
creator: 系统管理员
public_config: 0
data_id: 100655700000005697
has_fields: true
tags: [E10, 数据字典]
---

# esb_rfc_source

> ESB RFC配置表

> [!info] 基本信息
> - 数据库表名：`esb_rfc_source`
> - 中文名称：ESB RFC配置表
> - 所属模块：ESB中心
> - 所属数据库：`esb_setting`
> - 表类型：普通表
> - 负责人：程新
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：ESB RFC配置表
> - 数据ID：`100655700000005697`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | host_name | 主机IP地址 | 字符 | 255 |  |  |  |  |  |  |  |
| 2 | username | 用户名 | 字符 | 255 |  |  |  |  |  |  |  |
| 3 | user_password | 密码 | 字符 | 255 |  |  |  |  |  |  |  |
| 4 | client_id | 客户端 | 字符 | 255 |  |  |  |  |  |  |  |
| 5 | system_num | 系统编号 | 字符 | 255 |  |  |  |  |  |  |  |
| 6 | sap_router | 系统SAP router字符串 | 字符 | 255 |  |  |  |  |  |  |  |
| 7 | sys_language | 语言 | 字符 | 32 |  |  |  |  |  |  |  |
| 8 | open_cluster | 是否开启集群 | 整型 |  |  |  |  |  |  |  |  |
| 9 | mshost | 消息服务器 | 字符 | 255 |  |  |  |  |  |  |  |
| 10 | r3name | 集群系统标识 | 字符 | 255 |  |  |  |  |  |  |  |
| 11 | sap_group | SAP集群组 | 字符 | 255 |  |  |  |  |  |  |  |
| 12 | ms_server | 消息服务器端口号 | 字符 | 32 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/ESB中心]]
- 数据库索引：[[数据库索引/esb_setting]]
