---
table_name: iut_sys_remind_param
cn_name: 自定义提醒参数表
module: 统一待办中心
database: int_unify_todo_server
type: 普通表
owner: 王嘉男
creator: 系统管理员
public_config: 0
data_id: 100655700000004239
has_fields: true
tags: [E10, 数据字典]
---

# iut_sys_remind_param

> 自定义提醒参数表

> [!info] 基本信息
> - 数据库表名：`iut_sys_remind_param`
> - 中文名称：自定义提醒参数表
> - 所属模块：统一待办中心
> - 所属数据库：`int_unify_todo_server`
> - 表类型：普通表
> - 负责人：王嘉男
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：注册中心自定义提醒参数表
> - 数据ID：`100655700000004239`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | sys_info_id | 异构系统信息表Id | 长整型 |  |  |  |  |  |  |  | 异构系统信息表Id |
| 8 | param_name | 参数名称 | 字符 | 100 |  |  |  |  |  |  | 参数名称 |
| 9 | param_value | 参数值 | 字符 | 1000 |  |  |  |  |  |  | 参数值 |
| 10 | remind_class | 提醒类 | 字符 | 1000 |  |  |  |  |  |  | 提醒类 |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/统一待办中心]]
- 数据库索引：[[数据库索引/int_unify_todo_server]]
