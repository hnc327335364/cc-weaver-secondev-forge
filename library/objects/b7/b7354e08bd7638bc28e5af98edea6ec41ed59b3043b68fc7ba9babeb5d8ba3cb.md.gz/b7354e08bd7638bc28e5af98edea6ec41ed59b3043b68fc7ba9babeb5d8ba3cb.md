---
table_name: edc_multi_report_setting
cn_name: 多级填报任务设置
module: OpenAPI开放平台
database: edcappdev
type: 普通表
owner: 林文韬
creator: 系统管理员
public_config: 0
data_id: 100655700000004660
has_fields: true
tags: [E10, 数据字典]
---

# edc_multi_report_setting

> 多级填报任务设置

> [!info] 基本信息
> - 数据库表名：`edc_multi_report_setting`
> - 中文名称：多级填报任务设置
> - 所属模块：OpenAPI开放平台
> - 所属数据库：`edcappdev`
> - 表类型：普通表
> - 负责人：林文韬
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：多级填报任务设置表
> - 数据ID：`100655700000004660`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | report_id | 多级填报ID | 长整型 |  |  |  |  |  |  |  |  |
| 8 | task_schedule_enabled | 周期下发启用 | 小整数 |  |  |  |  | 0 |  |  |  |
| 9 | root_node_enabled | 发起时指定根节点操作者启用 | 小整数 |  |  |  |  | 0 |  |  |  |
| 10 | only_show_parent_child_enabled | 任务路径仅展示上下级节点启用 | 小整数 |  |  |  |  | 0 |  |  |  |
| 11 | task_id | 定时任务ID | 长整型 |  |  |  |  |  |  |  |  |
| 12 | task_name | 任务名称 | 字符 | 128 |  |  |  |  |  |  |  |
| 13 | cron | 调度配置 - cron | 字符 | 128 |  |  |  |  |  |  |  |
| 14 | launch_modify_path_enabled | 发起任务时修改路径启用 | 小整数 |  |  |  |  | 0 |  |  |  |
| 15 | fix_rate | 调度配置 - 循环(分钟) | 整型 |  |  |  |  |  |  |  |  |
| 16 | timer_config | 简单定时器设置JSON串 | 大字段1 |  |  |  |  |  |  |  |  |
| 17 | relation_query_enabled | 节点填报数据联查启用 | 小整数 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/OpenAPI开放平台]]
- 数据库索引：[[数据库索引/edcappdev]]
