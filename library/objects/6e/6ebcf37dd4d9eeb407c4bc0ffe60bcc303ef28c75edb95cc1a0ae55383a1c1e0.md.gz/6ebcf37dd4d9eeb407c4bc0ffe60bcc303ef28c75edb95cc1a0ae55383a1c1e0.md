# 查找外部供应商

来源快照：`result_data_new_260518.json`

- 来源 ID：`1184764199074668734`
- 模块：采购管理
- 目录：采购发版内容介绍 - 202511版
- space ID：`1157959398195183695`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景及价值用途

在采购系统中，增加外部资源，支持按行业、产品、地区等条件搜索企业，再将符合条件的企业推入采购系统中，作为后续采购的供应商资源池。打破企业现有供应商资源的封闭性和局限性，优化采购寻源和供应链管理，引入更多供应商减少供应风险并能使供应商之间的竞争更加充分。

# 二、功能使用说明

①寻找供应商，点击采购管理供应商资源池中的“寻找供应商”

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184767398664953871&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

②跳转到启信宝的“客商搜索”页面，可以根据条件进行搜索，比如根据行业、地址、产品等条件

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184768846266646531&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184771027995238411&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

③启信宝根据搜索条件，查出对应企业，用户根据需要，勾选企业推送至采购管理系统中

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184771251348807688&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184771307057553409&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

④推送成功后，可在采购管理供应商资源池进行查看。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184771921264549892&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

⑤支持对供应商资源池中的企业“设为潜在供应商”，支持单个供应商行操作，也支持勾选多个供应商批量设为“潜在供应商”。已“设为潜在供应商”的企业，隐藏“设为潜在供应商”按钮，不支持多次推送。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1184772277895184388&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
