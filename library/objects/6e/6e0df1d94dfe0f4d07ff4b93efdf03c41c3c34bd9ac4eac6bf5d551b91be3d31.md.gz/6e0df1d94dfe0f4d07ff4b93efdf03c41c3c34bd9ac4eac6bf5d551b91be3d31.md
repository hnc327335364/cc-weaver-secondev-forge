---
table_name: t_sysmsg_msgid_user_index_08
cn_name: IM系统消息id用户索引表
module: 聊天消息
database: db_im
type: 普通表
owner: 钱文明
creator: 周健健
public_config: 0
data_id: 1209228766624383012
has_fields: true
tags: [E10, 数据字典]
---

# t_sysmsg_msgid_user_index_08

> IM系统消息id用户索引表

> [!info] 基本信息
> - 数据库表名：`t_sysmsg_msgid_user_index_08`
> - 中文名称：IM系统消息id用户索引表
> - 所属模块：聊天消息
> - 所属数据库：`db_im`
> - 表类型：普通表
> - 负责人：钱文明
> - 创建者：周健健
> - 是否公共配置：0
> - 描述：IM系统消息id用户索引表
> - 数据ID：`1209228766624383012`
> - 最后更新：2025-12-03 15:05:12

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 | 20 |  |  |  |  |  |  |  |
| 2 | tenant_key | 租户KEY | 字符 | 20 |  |  |  |  |  |  |  |
| 3 | fcid | fcid | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 4 | fuid | fuid | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 5 | fmsgid | fmsgid | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 6 | fdel_flag | fdel_flag | 整型 |  |  |  |  | 0 |  |  |  |
| 7 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 8 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 9 | creator | 创建人id | 长整型 | 20 |  |  |  | 0 |  |  |  |
| 10 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/聊天消息]]
- 数据库索引：[[数据库索引/db_im]]
