<!-- source: https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/repository/b7c818b1-9132-46a7-bfaf-78fc6747791a/doc/955409548165775361 -->

## 获取当前登录人有权限的日程

**请求URL：**

- [https://api.eteams.cn/api/calendar/openapi/v1/querySearchAgenda](https://api.eteams.cn/api/calendar/openapi/v1/querySearchAgenda)

**请求方式：**

- POST
- Content-Type：application/json

| 参数名 | 必选 | 类型 | 说明 |  |
| --- | --- | --- | --- | --- |
| access\_token | 是 | String | 调用接口凭证 获取accessToken信息（内部文档跳转：840673319280451584） |  |
| userId | 是 | Long | 用户id 获取用户ID（内部文档跳转：840674921396404224） |  |
| tenantKey | 是 | String | 租户key |  |
| name | 否 | String | 日程名称 |  |
| beginDate | 否 | Long | 开始日期，时间戳 |  |
| endDate | 否 | Long | 结束日期，时间戳 |  |
| calendarStatus | 否 | String | 日程状态：todo进行中,finished已完结 |  |
| page | 否 | Integer | 页码，不填默认为1 |  |
| pageSize | 否 | Integer | 页大小，不填默认为10 |  |

**返回示例：**

```json
{
	"data": {
		"pageNo": 1,
		"pageSize": 2,
		"result": [{
			"id": "1737299839559031322",
			"deleteType": 0,
			"name": "77777",
			"creator": {
				"id": "1554922514848987402",
				"username": "lzlz",
				"loginCount": 0,
				"fansCount": 0,
				"followCount": 0,
				"blogCount": 0,
				"onlySuperior": 0,
				"secLevel": 0,
				"hasInvUser": false,
				"birthdayFlag": false,
				"classifyAdmin": false,
				"setting": false,
				"permanentlyDelete": false,
				"type": "inside",
				"extra": false,
				"markread": false,
				"containRels": false,
				"name": "lzlz",
				"employeeId": "1554922514848987402",
				"moduleAdmin": false,
				"followAndSub": false,
				"sysAdmin": false
			},
			"createTime": 1672998396000,
			"lastUpdateTime": 1672998396000,
			"commentCount": 0,
			"watched": false,
			"unread": false,
			"finished": false,
			"manager": {
				"id": "1554922514848987402",
				"username": "lzlz",
				"loginCount": 0,
				"fansCount": 0,
				"followCount": 0,
				"blogCount": 0,
				"onlySuperior": 0,
				"secLevel": 0,
				"hasInvUser": false,
				"birthdayFlag": false,
				"classifyAdmin": false,
				"setting": false,
				"permanentlyDelete": false,
				"type": "inside",
				"extra": false,
				"markread": false,
				"containRels": false,
				"name": "lzlz",
				"employeeId": "1554922514848987402",
				"moduleAdmin": false,
				"followAndSub": false,
				"sysAdmin": false
			},
			"content": "",
			"startDate": 1672997400000,
			"endDate": 1672999200000,
			"allDay": false,
			"repeat": false,
			"calendarStatus": "todo"
		}],
		"totalCount": "207",
		"hasNext": true,
		"first": 1,
		"totalPages": "104",
		"prePage": 1,
		"hasPre": false,
		"nextPage": 2
	},
	"message": {
		"errcode": "0",
		"errmsg": "success"
	}
}
```

**返回参数说明：**

| 参数名 | 类型 | 说明 |
| --- | --- | --- |
| data | Object | 业务数据 |
| pageNo | Integer | 分页：当前页 |
| pageSize | Integer | 分页：页大小 |
| totalCount | Integer | 分页：总数 |
| hasNext | Boolean | 分页：是否有下一页 |
| totalPages | Integer | 分页：总页数 |
| nextPage | Integer | 分页：下一页页码 |
| hasPre | Boolean | 分页：是否有上一页 |
| prePage | Integer | 分页：上一页页码 |
| first | Integer | 分页：首页页码 |
| result | Array | 分页：返回数据 |
| id | String | 日程id |
| deleteType | Integer | 是否删除：0、否 1、是 |
| updateTime | Long | 最近更新时间 |
| name | String | 日程名称 |
| creator | Object | 创建人 |
| createTime | Long | 日程创建时间 |
| commentCount | Integer | 日程评论条数 |
| watched | Boolean | 是否关注 |
| unread | Boolean | 是否未读 |
| finished | Boolean | 师傅结束 |
| manager | Object | 负责人 |
| content | String | 日程描述 |
| startDate | Long | 日程开始时间 |
| endDate | Long | 日程结束时间 |
| allDay | Boolean | 是否全天 |
| repeat | Boolean | 是否重复日程 |
| calendarStatus | String | 日程状态：todo进行中,finished已完结 |
| errmsg | String | 错误描述 |
| errcode | String | 错误代码 |
