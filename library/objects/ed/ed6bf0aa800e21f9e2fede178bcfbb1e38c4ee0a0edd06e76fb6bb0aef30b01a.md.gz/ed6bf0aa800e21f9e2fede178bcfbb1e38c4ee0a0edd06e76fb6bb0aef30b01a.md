---
table_name: ebdf_permission_tpa_config
cn_name: 第三方企业应用权限配置表
module: e-Builder应用建模
database: ebuilder_form
type: 普通表
owner: 程东勇
creator: 熊雪兵
public_config: 0
data_id: 100655700000007438
has_fields: true
tags: [E10, 数据字典]
---

# ebdf_permission_tpa_config

> 第三方企业应用权限配置表

> [!info] 基本信息
> - 数据库表名：`ebdf_permission_tpa_config`
> - 中文名称：第三方企业应用权限配置表
> - 所属模块：e-Builder应用建模
> - 所属数据库：`ebuilder_form`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：熊雪兵
> - 是否公共配置：0
> - 描述：用于存放第三方应用的权限启用配置
> - 数据ID：`100655700000007438`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | opened | 开启标识 | 整型 |  |  |  |  | 1 |  |  | 0关闭，1开启 |
| 8 | belong_id | 所属模块标识 | 长整型 |  |  |  |  |  |  |  | 对应permission表中的belong_id |
| 9 | belong_type | 所属模块类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 10 | obj_id | 表单id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/ebuilder_form]]
