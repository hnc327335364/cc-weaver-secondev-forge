---
table_name: ebdf_button_action
cn_name: 按钮动作表
module: e-Builder应用建模
database: ebuilder_form
type: 普通表
owner: 程东勇
creator: 熊雪兵
public_config: 0
data_id: 100655700000003714
has_fields: true
tags: [E10, 数据字典]
---

# ebdf_button_action

> 按钮动作表

> [!info] 基本信息
> - 数据库表名：`ebdf_button_action`
> - 中文名称：按钮动作表
> - 所属模块：e-Builder应用建模
> - 所属数据库：`ebuilder_form`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：熊雪兵
> - 是否公共配置：0
> - 描述：按钮动作表
> - 数据ID：`100655700000003714`
> - 最后更新：2025-04-09 11:47:21

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | params | 参数 | 字符 | 200 |  |  |  |  |  |  | 评论参数中使用 |
| 2 | show_reply_num | 是否显示评论总数 | 小整数 |  |  |  |  | 0 |  |  | 0 不显示 1 显示 |
| 3 | url_type | 链接地址类型 | 整型 |  |  |  |  |  |  |  |  |
| 4 | url_field_id | 链接字段id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | confirm_title | 确认框标题 | 字符 | 200 |  |  |  |  |  |  |  |
| 6 | confirm_content | 确认框文本内容 | 字符 | 500 |  |  |  |  |  |  |  |
| 7 | confirm_true | 确认框“是”按钮文本 | 字符 | 100 |  |  |  |  |  |  |  |
| 8 | confirm_false | 确认框“否”按钮文本 | 字符 | 100 |  |  |  |  |  |  |  |
| 9 | ecod_id | ecode组件的ecodeID | 长整型 | 20 |  |  |  |  |  |  |  |
| 10 | ecode | 自定义JS代码块内容 | 大字段1 |  |  |  |  |  |  |  |  |
| 11 | field_edit_type | 编辑方式 | 字符 | 20 |  |  |  |  |  |  |  |
| 12 | field_edit_config | 编辑字段信息 | 大字段1 |  |  |  |  |  |  |  |  |
| 13 | parse_type | 解析方式 | 小整数 | 1 |  |  |  | 2 |  |  | 是否使用新的解析逻辑 |
| 14 | url_app_id | url对应的appId | 长整型 |  |  |  |  |  |  |  |  |
| 15 | modal_width | 窗口宽度 | 字符 | 200 |  |  |  |  |  |  |  |
| 16 | modal_height | 窗口高度 | 字符 | 200 |  |  |  |  |  |  |  |
| 17 | is_bottom_btn_tiled | 按钮位置底部平铺显示 | 字符 | 10 |  |  |  |  |  |  | 0:不平铺，1：平铺显示 |
| 18 | flat_to_bottom | 按钮位置底部平铺显示 | 字符 | 10 |  |  |  |  |  |  | 0:不平铺，1：平铺显示 |
| 19 | combine_data_fields | 数据合并页标题列 | 长整型 |  |  |  |  |  |  |  |  |
| 20 | third_party_flag | 第三方标识 | 整型 |  |  |  |  |  |  |  | 0：系统数据，1:第三方数据 |
| 21 | source_config_id | 原数据id | 长整型 |  |  |  |  |  |  |  |  |
| 22 | export_type | 卡片导出类型配置 | 字符 | 100 |  |  |  |  |  |  | 卡片导出配置用 |
| 23 | data_log_show_type | 日志展示模式 | 字符 | 10 |  |  |  |  |  |  | single：单个展示 agg： 聚合展示 |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/ebuilder_form]]
