---
table_name: attend_insert_children_flow
cn_name: 考勤新增子女的流程
module: 出勤
database: attend
type: 普通表
owner: 平振亚
creator: 潘飞
public_config: 0
data_id: 934195901380493319
has_fields: true
tags: [E10, 数据字典]
---

# attend_insert_children_flow

> 考勤新增子女的流程

> [!info] 基本信息
> - 数据库表名：`attend_insert_children_flow`
> - 中文名称：考勤新增子女的流程
> - 所属模块：出勤
> - 所属数据库：`attend`
> - 表类型：普通表
> - 负责人：平振亚
> - 创建者：潘飞
> - 是否公共配置：0
> - 描述：考勤新增子女的流程
> - 数据ID：`934195901380493319`
> - 最后更新：2023-11-23 11:17:13

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | employee | 人员id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | member_id | 子女id | 长整型 |  |  |  |  |  |  |  |  |
| 9 | flow_id | 流程id | 字符 | 50 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/出勤]]
- 数据库索引：[[数据库索引/attend]]
