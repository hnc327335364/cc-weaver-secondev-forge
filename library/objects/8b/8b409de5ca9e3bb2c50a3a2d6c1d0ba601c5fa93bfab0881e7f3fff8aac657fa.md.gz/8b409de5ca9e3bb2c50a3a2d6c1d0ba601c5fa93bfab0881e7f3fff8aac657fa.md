# 拟签意见显示内容增加操作人分部、监控支持修改拟签意见以及意见字段支持删除

来源快照：`result_data_new_260518.json`

- 来源 ID：`1971947008117935379`
- 模块：工作流程
- 目录：功能更新说明 - 2024-06
- space ID：`1157949872166969347`
- 原文链接：未提供
- 产品基线：未提供

## 正文

1、拟签意见显示内容设置中增加操作人分部，设置入口如下图所示

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157204755307192377&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、此前有修改表单内容权限的监控人，可以修改拟签意见字段，但仅支持填写意见、抄清代录、以及修改自己的意见，不能修改其余人的意见，本次支持可修改其余人的拟签意见；

3、此前拟签意见字段在未产生数据的情况下也不能删除，不合理，本次工作流拟签意见字段设置支持删除字段，如下图所示：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157204755471802566&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
