# 猎头管理

来源快照：`result_data_new_260518.json`

- 来源 ID：`1178056864599629945`
- 模块：招聘管理
- 目录：前台使用
- space ID：`1174763165815685268`
- 原文链接：未提供
- 产品基线：未提供

## 正文

一、

# 功能背景及价值

在招聘业务中，存在猎头推荐简历的场景，增加猎头相关功能，满足客户这类场景需求。

二、

# 业务流程图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056959122620426&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

三、

# 功能详细说明

## 1.猎头管理

### 猎头公司

在猎头管理菜单可以维护猎头公司的信息，包括可设置猎头保护期，标记标签属性等，还可设置猎头公司下对应的猎头账号信息。

猎头公司新建完成默认是启用状态，可以手动操作禁用，禁用会关联禁用公司下的猎头账号，猎头账号无法登录系统。再次启用猎头公司后，对应的猎头账号需要手动再次去启用才可正常登录。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056959015862277&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 猎头账号

新建猎头账号需要填写手机和邮箱，并且会校验系统中是否存在其他的猎头账号已使用相同的手机或者邮箱，若校验不通过，则不可新建账号。

猎头账号可以操作禁用或者启用，禁用状态或者未激活状态都无法登录系统。

猎头账号未激活状态可以操作删除，激活后不可操作删除；

猎头账号未激活状态可以修改账号的全部信息，激活后只可修改角色信息；                          

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056963436658693&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)                            

猎头账号新建完成后，默认是启用但未激活状态，可通过发送邀请/批量发送邀请，把账号信息通过邮件或者短信的方式发送给对应的猎头邮箱，发送完成猎头账号会变成启用且激活状态。

猎头通过访问通知中的链接和账号，即可登录系统。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056967620280326&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)                                                        

## 2.猎头设置

简历有效期设置：简历有效期为当前简历归属企业的时间范围，有效期内的简历无法再次被猎头推荐；

有效期计算规则：最后一次投递时间+有效期时长；

 

猎头保护期设置：简历保护期为简历属于猎头公司的时间，保护期内的简历无法被猎头再次推荐，

开启后猎头信息处设置的猎头保护期将生效，简历推荐成功后，人才卡片上增加保护期展示，鼠标悬浮展示保护期到期时间；

 

允许重复推荐简历：

开启后，猎头允许推荐在有效期和保护期之外的重复简历；

关闭后，猎头不允许推荐任何重复简历；

 

允许猎头查看重复简历：

开启后，若简历查重显示重复，猎头可以查看重复简历的姓名、历史投递职位、历史投递时间；

关闭后，若简历查重显示重复，猎头只可以看到重复提醒，看不到重复简历投递记录；

 

猎头账号激活邀请通知设置：邮件  短信；

设置后，猎头账号激活邀请将通过以上方式发送；

 

允许猎头公司自行维护本企业内的猎头账号：

开启后，猎头公司的猎头管理员可自行维护本企业内猎头账号：添加猎头账号，邀请激活等所有操作；

关闭后，猎头管理员默认可以禁用账号、设置猎头管理员；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056959015862272&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 3.职位发布增加猎头渠道

发布职位页面增加猎头渠道，可选择已启用的猎头公司以及猎头账号，发布完成后的职位信息显示到猎头端的职位菜单里面。

发布时：若只选择了猎头公司，未选择账号，则该猎头下的所有启用账号都能看到这个职位；若选择了猎头公司，且选择了猎头账号，则只有当前选择的账号和猎头公司的管理员角色可以看到这个职位信息。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056967714848779&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)  ![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056963191095298&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 4.猎头账号登录系统

根据邮件/短信通知里面的链接和账号信息登录oa猎头端。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056959066726416&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 职位

猎头角色：展示招聘中且发布到此猎头账号的职位，点击职位名称可以查看职位详情；

猎头管理员角色：展示招聘中且发布到此猎头公司的所有职位，点击职位名称可以查看职位详情；

推荐简历：打开推荐页面，自动带出选择的职位

推荐理由：多文本框编辑

上传原始简历附件：如果有集成千里聆，则上传完附件自解析附件内容填充下面的人才基本信息，如果没有集成千里聆，则需要手动填写人才基本信息

简历查重：根据姓名+手机号对比人才库中的数据进行查重，根据猎头设置规则进行比对

提交：简历查重通过才可操作提交

提交成功的简历需要hr在猎头推荐简历菜单中处理

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056967620280321&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D) 

### 推荐记录

猎头管理员角色：显示本猎头公司所有猎头的推荐记录

猎头角色：显示自己的所有推荐记录

推荐状态：

待处理-简历提交后，默认为待处理状态，需要hr在猎头推荐简历菜单中处理

已接受-hr操作接受的简历

已拒绝-hr操作拒绝的简历

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056963191095306&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 账户中心

维护自己的账号密码信息

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056963445579789&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 账号管理

猎头角色：无权限操作此页面

猎头管理员：维护当前猎头公司下的所有的猎头账号

猎头设置-允许猎头公司自行维护本企业内的猎头账号开关控制：

启用后：猎头管理员操作权限同hr，可以添加猎头账号、邀请激活、编辑、启用、禁用、删除等；

禁用后：猎头管理员在账号管理只可以禁用账号、设置猎头角色；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056963436658696&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 5.猎头推荐简历

菜单权限：招聘hr角色，招聘-管理员角色

列表展示职位负责人/协助人职位的推荐简历记录，根据处理状态分tab显示，默认显示待处理tab

姓名：查看简历的基本信息，推荐猎头，推荐理由以及操作日志等

接受：查重校验通过才可操作，接受后状态变为已接受，应聘者进入人才库，并开始应聘阶段的流转

拒绝：可填写拒绝理由，拒绝后状态变为已拒绝，

重新接受：展示已拒绝状态的记录，查重校验通过才可以操作重新接受，接受后，应聘者进入人才库，并开始应聘阶段的流转

以上的操作都记录日志，可在操作日志tab查看。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056967657160718&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)                       

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056959122620430&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)  

## 6.工作台增加待处理猎头简历

工作台菜单增加“待处理猎头简历”统计，点击打开待处理的推荐记录，操作同“猎头推荐简历”菜单。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178056967657160707&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)  

四、

# 上下游关联功能点

需要先在【职位管理】菜单，操作发布至猎头渠道，猎头端列表才可显示职位信息。

[https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1177700652804726789&freepass_doc=1&space_id=1174763165815685268](https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1177700652804726789&freepass_doc=1&space_id=1174763165815685268)
