---
title: "Ecology后端开发环境搭建"
aliases:
  - "Ecology后端开发环境搭建"
  - "ecology后端开发环境搭建"
domain: "weaver-knowledge"
category: "e9-reference"
note_type: "reference-note"
status: "active"
language: "zh-CN"
summary: "Ecology 后端开发环境搭建说明，涵盖本地环境、开发工具与基础配置准备。"
source_path: "02-Weaver-Knowledge 泛微知识库/01-E9 E9资料/Ecology后端开发环境搭建.md"
tags:
  - "vault/CcLLMWiki"
  - "domain/weaver"
  - "type/reference"
  - "platform/e9"
  - "topic/后端"
  - "folder/02-weaver-knowledge-泛微知识库-01-e9-e9资料"
product_line: "E9"
tech_scene:
  - "后端"
capability_module:
  - "环境搭建"
artifact_type: "环境搭建"
retrieval_terms:
  - "后端环境搭建"
  - "开发环境"
  - "Ecology后端开发环境搭建"
source_type: "在线文档整理"
confidence: "high"
---
# Ecology后端开发环境搭建

## 适用范围

> **适用基线**：待现场确认。本页未提供可核实的版本或补丁区间；使用前以客户现场版本、接口合同和官方资料为准。

## 文档说明

- 资料定位：Ecology 后端开发环境搭建说明，涵盖本地环境、开发工具与基础配置准备。
- 原始来源：https://e-cloudstore.com/doc.html?appId=c6a9ae6e47b74d4da04c935ed51d177a&maxImgWidth=800
- 抓取时间：`2026-05-20`
- 原始标题：`ecology后端开发环境搭建`
- 整理说明：保留原始正文，统一修正标题、摘要与基础格式。

## 原始正文

> 
> @Date：2020.5.29
>
> @Version：1.0

## 一、安装idea和ecode
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)

- 1、本地pc环境安装idea请根据JetBrains官方说明操作，本文不提供此步骤说明
- 2、ecology环境安装eocde最新版，请按照[此说明操作](https://e-cloudstore.com/doc.html#%E5%A6%82%E4%BD%95%E5%AE%89%E8%A3%85)

## 二、创建项目
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)

- 1、新建项目：File->New->Project
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590742344000.png)

- 2、选择java项目
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590742274000.png)

- 3、下一步：Next
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590743066000.png)

- 4、继续下一步：Next，并输入项目名字之后点击Finish
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590743142000.png)

## 三、配置javaSDK
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)

- 1、进入项目设置File-Project Structure
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590743443000.png)

- 2、点击SDKs->+，添加jdk1.8（e9依赖的版本）
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590744883000.png)

- 3、点击project，分别选择Project SDK为1.8、、Project language level为SDK default 8
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590744997000.png)

## 四、配置项目依赖
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)

- 1、进入项目设置：File->Project Structure
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590743443000.png)

- 2、添加依赖库：Libaries->+->java
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590744481000.png)

- 3、找到要调试的ecology demo环境，分别引入以下路径的包
```
ecology/classbean
ecology/web-inf/lib
resin4/lib
```
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590744647000.png)

- 4、添加完之后点击Apply
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590744772000.png)

## 五、编写测试代码
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)

- 1、点击src右键->new->Package
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590745681000.png)

- 2、右键点击包名->new->Java，注意包名带有impl层级，才可支持[无侵入注解解析](https://e-cloudstore.com/doc.html?appId=84e77d7890a14c439590b37707251859#2%E3%80%81Jersey%E6%8E%A5%E5%8F%A3%E6%97%A0%E4%BE%B5%E5%85%A5%E5%BC%80%E5%8F%91)
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590745858000.png)

- 3、测试代码如下：

```java
package com.api.cs.test20200529.service.impl;

import com.weaverboot.frame.ioc.anno.classAnno.WeaIocReplaceComponent;
import com.weaverboot.frame.ioc.anno.methodAnno.WeaReplaceAfter;
import com.weaverboot.frame.ioc.anno.methodAnno.WeaReplaceBefore;
import com.weaverboot.frame.ioc.handler.replace.weaReplaceParam.impl.WeaAfterReplaceParam;
import com.weaverboot.frame.ioc.handler.replace.weaReplaceParam.impl.WeaBeforeReplaceParam;
import com.weaverboot.tools.logTools.LogTools;

@WeaIocReplaceComponent
public class Test {

    @WeaReplaceBefore(value = "/api/workflow/reqlist/splitPageKey",order = 1,description = "测试拦截前置")
    public void beforeTest(WeaBeforeReplaceParam weaBeforeReplaceParam){
        //一顿操作
        LogTools.info("before:/api/workflow/reqlist/splitPageKey");

    }

    @WeaReplaceAfter(value = "/api/workflow/reqlist/splitPageKey",order = 1,description = "测试拦截后置")
    public String after(WeaAfterReplaceParam weaAfterReplaceParam){
        String data = weaAfterReplaceParam.getData();//这个就是接口执行完的报文
        LogTools.info("after:/api/workflow/reqlist/splitPageKey");
//        LogTools.info(data);
        return data;
    }
}

```

## 六、配置编译
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)

- 1、进入项目设置：File->Project Structure
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590743443000.png)

- 2、进入Artifacts->+->JAR->Empty
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590759176000.png)

- 3、修改Name，这里要注意的是如果要支持无侵入注解解析，jar包名称必须包含下划线前缀，类似示例的写法
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590759246000.png)

- 4、修改jar包输出目录（output directory）到以下目录
```
ecology/web-inf/lib
```
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590759388000.png)

- 5、添加src输出内容到jar包，点击Apply
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590759988000.png)

- 6、选择build->Build Artifacts
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760064000.png)

- 7、点击build，即可完成编译
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760094000.png)

- 8、到系统中查看编译结果
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760125000.png)

## 七、resin远程debug配置
> ecology开发推荐使用idea，idea版权归属：[JetBrains](https://www.jetbrains.com/)
> 特别提示：调试模式禁止使用到生产系统，必须是开发环境

- 1、进入resin配置文件：resin4/config/resin.properties 修改jvm_args
```
jvm_args  : -Xdebug -Xrunjdwp:transport=dt_socket,address=9081,server=y,suspend=n -Dcom.sun.management.jmxremote -Xloggc:/var/log/gc.log -Xmx1550m -Xms1550m -XX:ParallelGCThreads=20 -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:+DisableExplicitGC
jvm_mode  : -server
```
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760411000.png)

- 2、添加中间件连接
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760484000.png)

- 3、添加+->Resin->Remote远程服务，分别输入ec服务地址URL、远程Resin调试端口Port
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760697000.png)

- 4、选择configure，选择resin home
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760773000.png)

- 5、添加jar包
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760820000.png)

- 6、选择之前定义的Artifacts，点击Apply保存
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760874000.png)

- 7、如果是同一个系统内，选择
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590761110000.png)

- 8、切换Startup/Connection，修改Debug->port为resin的远程调试端口
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590761394000.png)

- 9、services中启动debug
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590760947000.png)

- 10、到指定页面刷新（本示例是待办页面），成功进入断点，debug配置成功
![](https://e-cloudstore.com/files/ecode/demo/c6a9ae6e47b74d4da04c935ed51d177a/99a0fddbedaa4c09bd6744c981251dfb/image/file_1590761554000.png)
