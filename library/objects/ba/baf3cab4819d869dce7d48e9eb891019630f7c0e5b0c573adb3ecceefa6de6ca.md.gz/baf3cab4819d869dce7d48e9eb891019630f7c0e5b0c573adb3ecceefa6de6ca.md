---
table_name: iaauthserver_pubacclogs_detail
cn_name: 公共账号管理日志详情表
module: 统一认证中心
database: int_unify_auth_server
type: 普通表
owner: 张保
creator: 王杰（上海）
public_config: 0
data_id: 1149838701771276289
has_fields: true
tags: [E10, 数据字典]
---

# iaauthserver_pubacclogs_detail

> 公共账号管理日志详情表

> [!info] 基本信息
> - 数据库表名：`iaauthserver_pubacclogs_detail`
> - 中文名称：公共账号管理日志详情表
> - 所属模块：统一认证中心
> - 所属数据库：`int_unify_auth_server`
> - 表类型：普通表
> - 负责人：张保
> - 创建者：王杰（上海）
> - 是否公共配置：0
> - 描述：公共账号管理日志详情表
> - 数据ID：`1149838701771276289`
> - 最后更新：2025-06-26 14:29:20

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/统一认证中心]]
- 数据库索引：[[数据库索引/int_unify_auth_server]]
