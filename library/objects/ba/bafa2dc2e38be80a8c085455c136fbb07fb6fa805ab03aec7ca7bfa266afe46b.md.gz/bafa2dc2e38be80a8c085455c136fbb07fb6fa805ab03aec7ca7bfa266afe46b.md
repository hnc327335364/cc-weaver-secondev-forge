---
table_name: security_host
cn_name: Host白名单配置表
module: 系统安全
database: securityframework
type: 普通表
owner: 柳炉
creator: 系统管理员
public_config: 0
data_id: 100655700000003398
has_fields: true
tags: [E10, 数据字典]
---

# security_host

> Host白名单配置表

> [!info] 基本信息
> - 数据库表名：`security_host`
> - 中文名称：Host白名单配置表
> - 所属模块：系统安全
> - 所属数据库：`securityframework`
> - 表类型：普通表
> - 负责人：柳炉
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：Host白名单配置信息，配合host防护规则使用。
> - 数据ID：`100655700000003398`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | host_addr | host信息 | 字符 | 512 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/系统安全]]
- 数据库索引：[[数据库索引/securityframework]]
