# 提醒设置

来源快照：`result_data_new_260518.json`

- 来源 ID：`1175467931168440412`
- 模块：档案管理
- 目录：设置 - 系统设置
- space ID：`1157340686672379917`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能概述及使用说明

![](https://weapp.eteams.cn/papi/file/preview?fileId=1178123548139520001&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

借阅到期提醒天数：可填写正整数，配置完成后，系统将在借阅到期前，提前此天数发出“到期提醒”。

开启借阅到期提醒：开启后，将发送借阅到期提醒
