---
table_name: attend_clock_remind_range
cn_name: 打卡提醒适用范围
module: 出勤
database: attend
type: 普通表
owner: 平振亚
creator: 姜坤友
public_config: 0
data_id: 1100879905586143279
has_fields: true
tags: [E10, 数据字典]
---

# attend_clock_remind_range

> 打卡提醒适用范围

> [!info] 基本信息
> - 数据库表名：`attend_clock_remind_range`
> - 中文名称：打卡提醒适用范围
> - 所属模块：出勤
> - 所属数据库：`attend`
> - 表类型：普通表
> - 负责人：平振亚
> - 创建者：姜坤友
> - 是否公共配置：0
> - 描述：打卡提醒适用范围
> - 数据ID：`1100879905586143279`
> - 最后更新：2025-02-14 15:36:17

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | clock_remind_id | 打卡提醒设置ID | 长整型 |  |  |  |  |  |  |  |  |
| 8 | rule_id | 规则id | 长整型 |  |  |  |  |  |  |  |  |
| 9 | rule_type | 规则类型 | 字符 | 255 |  |  |  |  |  |  |  |
| 10 | clock_remind_type | 提醒类型 | 字符 | 255 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/出勤]]
- 数据库索引：[[数据库索引/attend]]
