---
table_name: tenant_operation_admin_manager
cn_name: 运行系统管理员表
module: 租户
database: tenantoperation
type: 普通表
owner: 向锟
creator: 系统管理员
public_config: 0
data_id: 100655700000007783
has_fields: true
tags: [E10, 数据字典]
---

# tenant_operation_admin_manager

> 运行系统管理员表

> [!info] 基本信息
> - 数据库表名：`tenant_operation_admin_manager`
> - 中文名称：运行系统管理员表
> - 所属模块：租户
> - 所属数据库：`tenantoperation`
> - 表类型：普通表
> - 负责人：向锟
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：运行系统管理员表
> - 数据ID：`100655700000007783`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | admin_manager_enum | 管理员类型 | 固定长度 | 50 |  |  |  |  |  |  |  |
| 2 | manager_object | 条件变更说明 | 固定长度 | 255 |  |  |  |  |  |  |  |
| 3 | update_user | 修改人 | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/租户]]
- 数据库索引：[[数据库索引/tenantoperation]]
