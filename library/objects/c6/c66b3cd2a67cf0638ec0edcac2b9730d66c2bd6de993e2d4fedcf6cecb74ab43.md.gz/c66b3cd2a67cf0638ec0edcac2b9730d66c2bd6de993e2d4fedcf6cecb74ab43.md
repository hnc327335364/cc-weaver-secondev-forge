# 门户导航栏

来源快照：`result_data_new_260518.json`

- 来源 ID：`1183649955688865877`
- 模块：集成中心
- 目录：邮箱集成 - 管理员操作指南
- space ID：`1158011075224911873`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景

用户需要一个门户导航栏菜单，可以快捷查看未读邮件数量及快捷单点登录至企业邮箱入口。

# 二、功能价值

提升邮件触达效率，实现一键直达邮箱。

# 三、功能说明

功能设置入口：后台管理中心-界面配置中心-PC网页版导航或者PC客户端导航，根据实际邮箱启用对应工具栏

![](https://weapp.eteams.cn/papi/file/preview?fileId=1207337877120204802&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

功能使用入口：前台-右上角工具栏

功能说明：点击可单点登录至邮箱，图标右上角显示未读邮件的数量

![](https://weapp.eteams.cn/papi/file/preview?fileId=1183651510316777474&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
