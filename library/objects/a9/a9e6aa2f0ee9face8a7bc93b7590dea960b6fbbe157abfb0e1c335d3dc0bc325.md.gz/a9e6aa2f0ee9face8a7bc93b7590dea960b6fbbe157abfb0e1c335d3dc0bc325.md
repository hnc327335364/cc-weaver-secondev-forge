---
table_name: basic_common_eb_statistics
cn_name: 整体基础eb数据源通用统计表
module: 整体基础
database: eteams
type: 普通表
owner: 向锟
creator: 系统管理员
public_config: 0
data_id: 100655700000007243
has_fields: true
tags: [E10, 数据字典]
---

# basic_common_eb_statistics

> 整体基础eb数据源通用统计表

> [!info] 基本信息
> - 数据库表名：`basic_common_eb_statistics`
> - 中文名称：整体基础eb数据源通用统计表
> - 所属模块：整体基础
> - 所属数据库：`eteams`
> - 表类型：普通表
> - 负责人：向锟
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：整体基础eb数据源通用统计表
> - 数据ID：`100655700000007243`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | statistics_type | 统计类型 | 字符 | 25 |  |  |  |  |  |  |  |
| 2 | statistics_count | 统计数量 | 整型 |  |  |  |  |  |  |  |  |
| 3 | statistics_status | 统计状态 | 字符 | 25 |  |  |  |  |  |  |  |
| 4 | statistics_year | 统计时间-年 | 字符 | 25 |  |  |  |  |  |  |  |
| 5 | statistics_month | 统计时间-月 | 字符 | 25 |  |  |  |  |  |  |  |
| 6 | statistics_day | 统计时间-日 | 字符 | 25 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/整体基础]]
- 数据库索引：[[数据库索引/eteams]]
