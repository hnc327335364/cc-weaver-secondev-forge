---
table_name: t_cus_app_menu_ph_ebdcomm_view
cn_name: 权限表
module: 菜单管理
database: weaver_cusapp
type: 
owner: 熊雪兵
creator: 系统管理员
public_config: 0
data_id: 100655700000003895
has_fields: true
tags: [E10, 数据字典]
---

# t_cus_app_menu_ph_ebdcomm_view

> 权限表

> [!info] 基本信息
> - 数据库表名：`t_cus_app_menu_ph_ebdcomm_view`
> - 中文名称：权限表
> - 所属模块：菜单管理
> - 所属数据库：`weaver_cusapp`
> - 表类型：—
> - 负责人：熊雪兵
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：权限表
> - 数据ID：`100655700000003895`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | source_id | source_id | 长整型 | 20 |  |  |  |  |  |  |  |
| 2 | target_type | target_type | 整型 | 11 |  |  |  |  |  |  |  |
| 3 | target_id | target_id | 长整型 | 20 |  |  |  |  |  |  |  |
| 4 | permission_type | permission_type | 整型 | 11 |  |  |  |  |  |  |  |
| 5 | target_subordinate_include | target_subordinate_include | 整型 | 11 |  |  |  |  |  |  |  |
| 6 | module_id | module_id | 固定长度 | 24 |  |  |  |  |  |  |  |
| 7 | source_type | source_type | 整型 | 11 |  |  |  |  |  |  |  |
| 8 | source_sub_id | source_sub_id | 长整型 | 11 |  |  |  |  |  |  |  |
| 9 | source_create_time | source_create_time | 日期时间 |  |  |  |  |  |  |  |  |
| 10 | source_min_sec_level | source_min_sec_level | 整型 | 11 |  |  |  |  |  |  |  |
| 11 | source_max_sec_level | source_max_sec_level | 整型 | 11 |  |  |  |  |  |  |  |
| 12 | source_station_level | source_station_level | 整型 | 11 |  |  |  |  |  |  |  |
| 13 | source_role_level | source_role_level | 整型 | 11 |  |  |  |  |  |  |  |
| 14 | source_organization_dimension | source_organization_dimension | 整型 | 11 |  |  |  |  |  |  |  |
| 15 | target_sub_id | target_sub_id | 长整型 | 11 |  |  |  |  |  |  |  |
| 16 | target_min_sec_level | target_min_sec_level | 整型 | 11 |  |  |  |  |  |  |  |
| 17 | target_max_sec_level | target_max_sec_level | 整型 | 11 |  |  |  |  |  |  |  |
| 18 | target_station_level | target_station_level | 整型 | 11 |  |  |  |  |  |  |  |
| 19 | target_station_bs_id | target_station_bs_id | 长整型 | 20 |  |  |  |  |  |  |  |
| 20 | target_role_level | target_role_level | 整型 | 11 |  |  |  |  |  |  |  |
| 21 | target_organization_dimension | target_organization_dimension | 整型 | 11 |  |  |  |  |  |  |  |
| 22 | permission_config_id | permission_config_id | 长整型 | 11 |  |  |  |  |  |  |  |
| 23 | source_origin_id | source_origin_id | 长整型 | 11 |  |  |  |  |  |  |  |
| 24 | permission_config_source_id | permission_config_source_id | 长整型 | 11 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/菜单管理]]
- 数据库索引：[[数据库索引/weaver_cusapp]]
