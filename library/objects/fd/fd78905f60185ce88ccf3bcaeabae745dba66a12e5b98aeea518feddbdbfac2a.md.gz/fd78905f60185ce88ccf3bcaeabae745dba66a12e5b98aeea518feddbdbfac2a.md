---
title: "E10表单元数据布局与模块字段接入实践"
aliases: ["FormRest元数据与布局", "BusinessRest模块字段接入"]
domain: "weaver-knowledge"
category: "e10-backend"
note_type: "topic-note"
status: "active"
language: "zh-CN"
summary: "整理表单引擎基础模型和6类RPC，明确字段/布局/版本/业务标识、布局覆盖副作用、模块字段接入与来源签名冲突。"
source_path: "02-Weaver-Knowledge 泛微知识库/02-E10 E10资料/E10表单元数据布局与模块字段接入实践.md"
source_docs:
  - "01-AI-Resources AI资料整理/04-Agents Agent规则/99-SourceFiles 原始资料/e-code智能化开发工具包/1.3.4/skills/e10-local-knowledge/modules/e10-form-backend-api-docs/references/docs"
tags: ["vault/CcLLMWiki", "domain/weaver", "platform/e10", "scene/backend", "type/topic"]
retrieval_terms: ["FormRestFactory", "FormRest", "FormFieldRest", "FormLayoutRest", "FormSecondServiceRest", "BusinessRest", "BusinessService", "updateCompsType", "reserveEcode", "mappingId"]
product_line: "E10"
tech_scene: ["元数据查询", "布局扩展", "模块接入"]
capability_module: ["表单引擎", "业务字段", "RPC"]
artifact_type: "知识专题"
source_type: "工具包本地表单后端正文核读"
confidence: "medium"
reviewed_at: "2026-10-23"
---

# E10表单元数据布局与模块字段接入实践

表单引擎RPC不是EB业务RPC的同名替代。先确认调用模块已开放接口，再用`FormRestFactory`按`module`获取对应服务；涉及模块业务的新建，来源明确建议优先调用该模块接口，避免绕过权限和业务控制。

本页依据表单后端资料中的基础实体、RPC说明和模块字段正文整理；逐文件指纹与行段见 [完整来源核对](E10表单后端续补来源核对-20261023.json)。原文含历史示例与多处类型冲突，没有统一最低基线；未编译客户依赖或实际调用。数据写入既有风险见 [[E10表单后端调用与数据操作契约补充]]，本页重点补元数据和布局。

## 一、先建立标识关系，再选择接口

| 标识/模型 | 用途 | 常见混淆 |
|---|---|---|
| `Form.id` / `formId` | 表单定义 | 不是某条业务数据ID；多个参数表把它误写为字段ID |
| `FormField.id` / `fieldId` | 字段定义 | `dataKey`是编码，`columnName`是数据库列，不能随意互换 |
| `SubForm.id` / `subFormId` | 明细表定义 | `rowId`是明细行，`dataIndex`是行下标，不能互代 |
| 多布局ID、布局版本ID | 当前布局与其版本 | `layoutId`在不同DTO中的描述不同，须按所属类确认 |
| `refId` / `refType` | 模块关联对象和关联类型 | 查询或复制模块布局时需维持真实关联，不能复用另一模块示例值 |
| `dataId` / `formDataId` / `objectId` | 数据及模块事项关联 | 不能仅凭数值相同推定可替换；附件、公共关联尤其要核实事项ID |
| `BusinessField.valueKey` | 模块业务字段标识 | 通常为类型/枚举编码，不必是数字字段ID |

`SimpleEmployee`至少需要来源规定的人员ID与`tenantKey`；这只是入参合同，不证明调用者已获授权。原件的示例用户、租户与ID不作为接收方配置。

基础模型也不能盲目生成DDL：`Form`和`FormData`的`isDelete`列写`boolean`，描述却列0/1/2三个状态；应检查目标类和持久化映射。字段读写权限、布局只读属性、表单授权属于不同层次，不因某一个布尔值成立就放行全部操作。

## 二、元数据查询入口

| 接口类 | 来源入口 | 实用边界 |
|---|---|---|
| `FormRest` | `checkNewForm`、`getSimpleFormById`、`queryFormByIds` | 新旧表单检查接受表单/布局/字段三种ID之一；批量查询说明限定非云、非删除表单，不是完整历史目录 |
| `FormFieldRest` | `listAllFormFieldByFormId`、`getSimpleFormFieldById`、`getSubFormListbyStatus` | `isDelete/isDel=null`可查全部，包括删除项；不要把空值当只查有效字段 |
| `FormFieldRest` | `listFormFieldFilterByLayoutMultiple`、`listFieldGroups` | 按多布局过滤字段与查询全部字段不同；字段分组不等于明细表分组 |
| `FormLayoutRest` | `listSimpleFormLayoutMultipleByEntity`、`getSimpleRefFormLayoutMultiple` | 查多布局与查模块关联布局不同；后者来源要求`formId`和`refId` |
| `FormLayoutRest` | `buildFormFieldDetailMap` | 返回字段ID到布局JSON字符串的Map；`containLayout=true`才包含布局控件；旧表单的`layoutDetail`有额外要求 |
| `FormSecondServiceRest` | `getFormData`、`listSubFormByOrder`、`listFormFieldOptions`、`queryRunAttachConfig`、`getOptionInfoByParam` | 依赖模块主动开放，不是任何模块通用可调用入口；字段/选项/附件配置各自成层 |

布局查询的`layoutIds`未传时，基础实体页说明查当前表单所有布局；`isDelete=null`也会扩展删除状态范围。`filterPrint`默认过滤打印布局，但指定`layoutIds/copyLayoutIds`时可能不过滤。`mappingId`表示实际运行采用的映射布局，不能只查看设计器入口的原ID。

`FormSecondServiceRest#getFormData`需显式考虑`containsDataDetails`；来源说明不传`true`可能只有对象而没有字段内容。`needSimpleFormData=true`读取主表/明细分开的结构，否则为`DataDetail`格式；物理表信息只支持相应物理表形态。名称反查返回`count`和重名候选，不自动取第一条；附件目录查询的流程`refId`不能省略后再猜默认目录。

## 三、布局写入、复制和XML迁移

`FormRest`提供`createFormByInitDto`、`copyFormByEntity`、`xmlExport`、`xmlImport`线索；`FormLayoutRest`提供追加/覆盖组件、初始化和复制关联布局。它们是会改变结构的能力，不属于“查一下资料”可以顺带执行的动作。

| 参数或操作 | 来源明确的行为 | 实施要求 |
|---|---|---|
| `updateCompsType=0/1` | 追加到最后 / 覆盖当前布局 | 不把“加字段”实现成覆盖；明确组件列表、目标版本和保留项 |
| `reserveEcode` | 初始化时默认不保留Ecode | 重建布局前确认定制代码保存方案；不能只验字段还在 |
| `preview` | 来源写预览数据不入库保存 | 单独确认实际调用与模式，不能将所有初始化接口视作只读 |
| `groupFieldIds`为空 | 在指定初始化模式下默认不过滤 | 空集合可能扩大范围，必须核对期望分组 |
| `ignoreECodeCheck` | 保存布局可跳过Ecode权限校验 | 不作为处理权限报错的默认开关 |
| `replaceIds`等映射 | 涉及表单、字段、布局、选项、明细dataKey、标签ID | 复制成功不等于全部跨模块引用已替换，按关联逐项验收 |
| `sourceVersionIdList`等内部参数 | 原文明确外部模块不允许传递 | 不因DTO含字段就开放给外部调用者 |

XML导出返回文件ID与布局信息，XML导入返回表单和扩展数据，不等于业务数据、权限和定制代码全部完成迁移。`fileId`也不是下载URL或文档ID。来源参数表与示例有省略项，不能用最短示例推导必填项可省略。

## 四、模块字段的接入与消费应分开

提供方实现`com.weaver.common.form.api.rest.biz.BusinessRest`，按模块注册服务与Dubbo分组；消费方`BusinessService`使用含`module`的参数定位模块。两者`updateBusinessData`等方法的参数数量不同，不能互换签名。

字段需明确`valueKey`、`valueType`、`viewType`和适用`scenarios`，必要时限定事件、浏览类型与钻取匹配字段；不应为方便直接暴露所有场景。`BusinessData`中业务`dataId`与表单`formDataId`分别存在，`valueMap`以业务字段标识取值。

`BusinessValue#getValue()`保留具体类型；`getSimpleValue()`全部转成字符串，日期是时间戳字符串，对象/列表为ID及逗号拼接值。后者适合特定展示或转换，不应回灌为所有字段的标准持久化格式。事件通知`eventEmitField`用于前端变更联动，不证明后端已保存。

标准RPC开放页要求继承`formapi.impl`下的实现而不是`def`包；同页的本地`@FormBizScan`接口注册段已标废弃，并提到重复AOP，不能再推广成新项目标准方式。

## 五、必须保留的来源冲突

- 字段国际化段声明与普通查询相同的方法和`SimpleFormFieldDto`签名，返回表/示例却是`FormFieldI18nDto`；需查现场真实方法，不能强制转换解决。
- `listFieldGroups`签名接收`Long formId`，示例传入未定义`entity`；选项查询签名为`Map<Long,List<FieldOption>>`，返回表却为`Map<String,List<FieldOptionDto>>`。
- `FormDataRest`页所属类误写`FormLayoutRest`，两个批量写入标题/注释相反；已有契约页详细保留，不再据名称推断新增与更新。
- `FormSecondServiceRest#getOptionInfoByParam`的示例调用另一个未声明服务；`dataIds`表格必填与单ID示例、明细查询的二选一说明与参数表也不一致。
- `BusinessRest`示例与接口声明的签名不同，批量返回类型、重复局部变量、共享字段赋值目标均有问题；说明中的枚举清单也未覆盖示例`OBJECT`。不可直接作为可编译工程。
- 运行时/设计器store的说明名称与示例大小写或属性名不同，`employeeId`还被误描述为租户ID；按实际SDK和依赖核实，不修补原件后宣称冲突消失。

建议先用只读查询验证真实标识和返回，再在获准测试表单上验证布局追加、覆盖、Ecode保留、字段权限、负向权限及迁移映射。没有客户依赖和环境时，交付的是实施方案与待确认合同，而不是“已可上线”的代码。
