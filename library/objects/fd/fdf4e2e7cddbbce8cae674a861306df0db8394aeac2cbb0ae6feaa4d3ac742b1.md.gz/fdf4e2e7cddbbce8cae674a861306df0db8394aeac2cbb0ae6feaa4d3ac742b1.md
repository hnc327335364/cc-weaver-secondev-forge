# 经费到账

来源快照：`result_data_new_260518.json`

- 来源 ID：`1211865880697282771`
- 模块：项目管理
- 目录：科研项目管理 - 前台使用 - 经费管理
- space ID：`1973261491939008706`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# **一、** 功能背景和价值

经费到账和经费认领是连接外部资金流入与内部科研项目执行的关键桥梁。其核心价值在于变被动为主动、化模糊为清晰、从粗放到精细，解决了科研经费管理中的信息孤岛、责任不明、账目不清、预算失控等痛点，为科研经费的合规、高效、透明使用提供了基础保障，有力地支撑了科研活动的顺利开展和科技创新目标的实现。

# **二、业务流程图**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1211897431557087234&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# **三、功能介绍**

## 1\. 经费到账列表

显示当前系统已有的经费到账数据列表，支持按相关条件搜索。也支持批量删除及导入导出。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1211898552591220742&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2\. 新建经费到账

点击新建导致则可以创建经费到账条目，需要填写发票号码、发票金额、经办人等相关信息。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1211866164134830086&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 3\. 到账认领

点击到账认领，可以针对还未认领的经费进行认领操作。单选相应的经费信息之后，会依据相应的经费信息创建经费认领。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1211866280148238339&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1211894395080695811&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 四、与该功能相关联上下游的功能点

## 1\. 经费认领

经过到账认领之后，会生成相应的经费认领数据。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1211897195289280516&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
