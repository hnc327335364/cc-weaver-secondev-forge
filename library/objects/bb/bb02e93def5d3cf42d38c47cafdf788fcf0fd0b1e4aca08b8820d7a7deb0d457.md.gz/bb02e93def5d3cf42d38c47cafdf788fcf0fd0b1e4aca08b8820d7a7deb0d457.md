---
table_name: ebdd_component_category
cn_name: 设计器组件分类表
module: e-Builder页面引擎
database: ebuilder_designer
type: SDK表
owner: 常程
creator: 熊雪兵
public_config: 0
data_id: 100655700000005044
has_fields: true
tags: [E10, 数据字典]
---

# ebdd_component_category

> 设计器组件分类表

> [!info] 基本信息
> - 数据库表名：`ebdd_component_category`
> - 中文名称：设计器组件分类表
> - 所属模块：e-Builder页面引擎
> - 所属数据库：`ebuilder_designer`
> - 表类型：SDK表
> - 负责人：常程
> - 创建者：熊雪兵
> - 是否公共配置：0
> - 描述：设计器组件分类表
> - 数据ID：`100655700000005044`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | name | 分类名称 | 字符 | 200 |  |  |  |  |  |  |  |
| 3 | show_order | 显示顺序 | 整型 |  |  |  |  |  |  |  |  |
| 4 | pid | 父分类id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | tenant_key | 租户id | 字符 | 10 |  |  |  |  |  |  |  |
| 6 | labelid | 标签id | 字符 | 20 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder页面引擎]]
- 数据库索引：[[数据库索引/ebuilder_designer]]
