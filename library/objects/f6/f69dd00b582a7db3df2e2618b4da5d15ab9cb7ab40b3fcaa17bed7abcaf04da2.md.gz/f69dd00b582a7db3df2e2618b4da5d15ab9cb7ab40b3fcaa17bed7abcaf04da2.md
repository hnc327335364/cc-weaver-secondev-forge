---
table_name: hrsa_si_policy_detail
cn_name: 各地社保公积金政策详情
module: 薪酬管理
database: hrm_salary
type: 普通表
owner: 蔡志军
creator: 程立明
public_config: 0
data_id: 1029638626142421056
has_fields: true
tags: [E10, 数据字典]
---

# hrsa_si_policy_detail

> 各地社保公积金政策详情

> [!info] 基本信息
> - 数据库表名：`hrsa_si_policy_detail`
> - 中文名称：各地社保公积金政策详情
> - 所属模块：薪酬管理
> - 所属数据库：`hrm_salary`
> - 表类型：普通表
> - 负责人：蔡志军
> - 创建者：程立明
> - 是否公共配置：0
> - 描述：各地社保公积金政策详情
> - 数据ID：`1029638626142421056`
> - 最后更新：2024-08-06 16:03:44

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | insurance_id | 险种id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | insurance_name | 险种名称 | 字符 | 255 |  |  |  |  |  |  |  |
| 9 | city_policy_id | 政策id | 长整型 |  |  |  |  |  |  |  |  |
| 10 | city_policy_code | 政策编码 | 字符 | 255 |  |  |  |  |  |  |  |
| 11 | city_code | 城市编码 | 字符 | 255 |  |  |  |  |  |  |  |
| 12 | company_base_down | 公司基数范围下限 | 字符 | 255 |  |  |  |  |  |  |  |
| 13 | company_base_up | 公司基数范围上限 | 字符 | 255 |  |  |  |  |  |  |  |
| 14 | company_ratio | 公司比例 | 字符 | 255 |  |  |  |  |  |  |  |
| 15 | company_fixed_money | 公司固定金额 | 字符 | 255 |  |  |  |  |  |  |  |
| 16 | person_base_down | 个人基数范围下限 | 字符 | 255 |  |  |  |  |  |  |  |
| 17 | person_base_up | 个人基数范围上限 | 字符 | 255 |  |  |  |  |  |  |  |
| 18 | person_ratio | 个人比例 | 字符 | 255 |  |  |  |  |  |  |  |
| 19 | person_fixed_money | 个人固定金额 | 字符 | 255 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/薪酬管理]]
- 数据库索引：[[数据库索引/hrm_salary]]
