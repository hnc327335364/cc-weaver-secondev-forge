# 能否限制流程表单中的关联事项范围

来源快照：`result_data_new_260518.json`

- 来源 ID：`1970255376216657539`
- 模块：低代码平台e-builder
- 目录：常见问答 - 流程引擎
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

### 问题描述

表单上的事项关联，能否关掉，或者只显示指定的几个关联事项？  


![](https://weapp.eteams.cn/papi/file/preview?fileId=1157717664611303430&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 问题答案

1. 全局设置：设置->基础设置->详情页关联事项默认设置 页面中可设置全局详情是否显示事项关联以及可关联范围

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157717664637354003&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2\. 设置指定工作流：基础信息->详情页关联事项设置 页面中可设置当前工作流详情是否显示事项关联以及可关联范围，开启后不读取全局

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157717669072101407&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
