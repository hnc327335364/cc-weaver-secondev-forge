# 动作流明细表支持接收变量并解构赋值

来源快照：`result_data_new_260518.json`

- 来源 ID：`1219377168731168869`
- 模块：前端逻辑编排
- 目录：功能更新说明 - 2025-12
- space ID：`1182582763689992228`
- 原文链接：未提供
- 产品基线：未提供

## 正文

### **1、功能背景与价值**

动作流明细表现在不支持获取所有数据，只能获取第一条数据。

### **2、功能说明**

2.1 动作流明细表支持接收变量并解构赋值。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1219377817220136963&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
