# 加审和加签有什么区别

来源快照：`result_data_new_260518.json`

- 来源 ID：`1970071757139218947`
- 模块：低代码平台e-builder
- 目录：常见问答 - 流程引擎
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

### 问题描述  


加审和加签之间的区别是什么？  


### 问题答案

**加审是在当前节点增加节点操作者** ，不发生流程流转；哪些人员可以加审取决于工作流-高级设置-加审管理中的设置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157719571577667591&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

**加签是增加一个新的节点及操作者** ，新增的节点位置不一定在当前节点之后，具体取决于对于加签节点的配置；默认为当前节点操作者可以加签

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157719571674767378&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
