# 【私有化】手机号码更换操作指南v4.1

来源快照：`result_data_new_260518.json`

- 来源 ID：`1197835644291211281`
- 模块：契约锁私有云操作手册合集
- 目录：V4.1契约锁操作手册 - V4.1个人信息变更
- space ID：`1190280869610831887`
- 原文链接：未提供
- 产品基线：未提供

## 正文

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836236961177604&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)**                                                           **【私有云】个人手机号码更换操作手册

* * *

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836236941746179&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D) 

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836236961177604&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D) 

 

 

 

 

**【私有云】个人手机号码更换操作手册**

 

 

上海亘岩网络科技有限公司

更新日期 2023-6-7

 

 

**版本记录**  
---  
版本号| 内容| 修改时间| 编辑人  
V4.1及以上| 1、介绍了个人手机号码更换的操作方法| 2023.6.7| 李金鸽  
  
** **

**目录**

一、4.3.0以下版本

1、账号登录

2、更换手机号

二、4.3.0及以上版本

1、账号登录

2、更换手机号

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

本文档主要介绍个人用户注册账号后如何针对已绑定的手机号进行变更。

# 一、4.3.0以下版本

## 1、账号登录

1、登录电子签平台 ，进入首页后点击右上角小人-【个人中心】。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836245414240260&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2、更换手机号

1、点击【安全中心】-手机号码这一栏【更换】。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836245510709251&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、输入需要更换的新号码，注意该号码必须是自己本人身份证办理的且未在电子签平台注册过的手机号才可以更换成功。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241119272960&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3、输入需要更换的手机号后点击获取验证码，填写收到的验证码后点击【确认修改】就更换完成了，系统会提示修改成功。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836245374124033&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836245510709249&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 __注：__ __4.3.0__ __以下版本，个人用户更换手机号时新手机号必须与当前账号实名信息一致，若更换时三要素校验失败，则无法更换，建议用户在公司下添加新手机号，然后做权限交接处理。__

 __权限交接处理方法：__

#  二、4.3.0及以上版本

## 1、账号登录

1、登录电子签平台 ，进入首页后点击右上角小人-【个人中心】。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241272922117&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2、更换手机号

1、点击【安全中心】-手机号码这一栏【更换】。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241272922116&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.

若新的手机号是当前账号本人身份证号实名办理的，则输入需要更换的新号码后点击获取验证码，填写收到的验证码后点击【确认修改】进行三要素校验，直接换绑成功。

 __注：此方法适用于私有云所有版本__

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241119272961&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3.

若新的手机号不是当前账号认证人本人身份证办理，在换绑时获取到验证码三要素校验无法通过，此时会进行降级处理：

 __注：该功能在私有云__ __4.3.0__ __及以上版本实现__

①使用旧手机号或邮箱验证码验证通过，完成换绑。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836236941746181&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836236954329090&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

②选择人脸识别方式校验通过，点击【无法获取验证码？使用人脸识别方式确认】后扫描二维码进行人脸识别校验，完成换绑

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241282850817&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836237019070465&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241095933957&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1197836241119272962&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)上海亘岩网络科技有限公司        契约锁电子合同平台www.qiyuesuo.com

上海市闵行区联航路1188号浦江智谷33号楼
