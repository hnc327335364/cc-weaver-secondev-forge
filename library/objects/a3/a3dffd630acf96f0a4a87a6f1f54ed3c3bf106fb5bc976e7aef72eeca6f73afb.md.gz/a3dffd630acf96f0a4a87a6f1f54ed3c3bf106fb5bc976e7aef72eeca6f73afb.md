---
table_name: dbsp_attend_machine_user_number
cn_name: 
module: 
database: eteams
type: 
owner: 
creator: 系统管理员
public_config: 0
data_id: 100655700000001089
has_fields: true
tags: [E10, 数据字典]
---

# dbsp_attend_machine_user_number

> [!info] 基本信息
> - 数据库表名：`dbsp_attend_machine_user_number`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`eteams`
> - 表类型：—
> - 负责人：—
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000001089`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | user_number | 工号 | 字符 | 24 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/eteams]]
