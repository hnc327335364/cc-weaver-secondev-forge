---
table_name: ebdf_export_field_template
cn_name: Excel导出字段模版表
module: e-Builder应用建模
database: ebuilder_form
type: 普通表
owner: 程东勇
creator: 魏邦平
public_config: 0
data_id: 1211849993680969785
has_fields: true
tags: [E10, 数据字典]
---

# ebdf_export_field_template

> Excel导出字段模版表

> [!info] 基本信息
> - 数据库表名：`ebdf_export_field_template`
> - 中文名称：Excel导出字段模版表
> - 所属模块：e-Builder应用建模
> - 所属数据库：`ebuilder_form`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：魏邦平
> - 是否公共配置：0
> - 描述：Excel导出字段模版表
> - 数据ID：`1211849993680969785`
> - 最后更新：2025-12-10 16:36:54

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | obj_id | 表单id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | list_id | 列表id | 长整型 |  |  |  |  |  |  |  |  |
| 9 | template_name | 模版名称 | 字符 | 500 |  |  |  |  |  |  |  |
| 10 | template_name_labelid | 模版名称多语言id | 长整型 |  |  |  |  |  |  |  |  |
| 11 | template_fields | 模版字段 | 大字段3 |  |  |  |  |  |  |  |  |
| 12 | is_public | 是否公告模版 | 小整数 | 1 |  |  |  | 0 |  |  | 0 关闭 1 开启 |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/ebuilder_form]]
