---
table_name: pr_unitedata_project_6
cn_name: pr_unitedata_project_6
module: 组织画像
database: portrait
type: 普通表
owner: 何前锋
creator: 系统管理员
public_config: 0
data_id: 100655700000007145
has_fields: true
tags: [E10, 数据字典]
---

# pr_unitedata_project_6

> pr_unitedata_project_6

> [!info] 基本信息
> - 数据库表名：`pr_unitedata_project_6`
> - 中文名称：pr_unitedata_project_6
> - 所属模块：组织画像
> - 所属数据库：`portrait`
> - 表类型：普通表
> - 负责人：何前锋
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：pr_unitedata_project_6
> - 数据ID：`100655700000007145`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | userid | 人员id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | item_id | 指标id | 长整型 |  |  |  |  |  |  |  |  |
| 9 | item_date | 统计日期 | 日期 |  |  |  |  |  |  |  |  |
| 10 | amount | 实际值 | 字符 | 1000 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/组织画像]]
- 数据库索引：[[数据库索引/portrait]]
