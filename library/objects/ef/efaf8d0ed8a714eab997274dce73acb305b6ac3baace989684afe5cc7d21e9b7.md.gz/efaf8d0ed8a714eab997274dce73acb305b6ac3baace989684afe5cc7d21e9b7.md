---
table_name: agenda_sign_config
cn_name: 
module: 
database: eteams
type: 
owner: 
creator: 闫宇
public_config: 0
data_id: 100655700000001011
has_fields: true
tags: [E10, 数据字典]
---

# agenda_sign_config

> [!info] 基本信息
> - 数据库表名：`agenda_sign_config`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`eteams`
> - 表类型：—
> - 负责人：—
> - 创建者：闫宇
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000001011`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | sign_range | 签到范围（米） | 小数 |  |  |  |  |  |  |  |  |
| 2 | qr_code_permission | 二维码可见权限 | 字符 | 25 |  |  |  |  |  |  |  |
| 3 | client_limit | 定位签到平台限制 | 字符 | 30 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/eteams]]
