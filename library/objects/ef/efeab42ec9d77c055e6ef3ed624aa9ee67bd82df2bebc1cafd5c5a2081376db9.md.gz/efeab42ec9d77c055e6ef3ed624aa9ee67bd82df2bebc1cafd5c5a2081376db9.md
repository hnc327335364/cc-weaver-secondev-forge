---
table_name: mail_sender_relation_md5
cn_name: 邮件联系人crm同步记录表（原ETsender_email_relation_md5）
module: 邮件
database: mail
type: 普通表
owner: 李伟（上海）
creator: 系统管理员
public_config: 0
data_id: 100655700000003045
has_fields: true
tags: [E10, 数据字典]
---

# mail_sender_relation_md5

> 邮件联系人crm同步记录表（原ETsender_email_relation_md5）

> [!info] 基本信息
> - 数据库表名：`mail_sender_relation_md5`
> - 中文名称：邮件联系人crm同步记录表（原ETsender_email_relation_md5）
> - 所属模块：邮件
> - 所属数据库：`mail`
> - 表类型：普通表
> - 负责人：李伟（上海）
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：对应原ET sender_email_relation_md5
> - 数据ID：`100655700000003045`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | user_id | 用户id | 长整型 |  |  |  |  |  |  |  |  |
| 2 | content_md5 | md5唯一标识 | 字符 | 255 |  |  |  |  |  |  |  |
| 3 | target_id | crm对象id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/邮件]]
- 数据库索引：[[数据库索引/mail]]
