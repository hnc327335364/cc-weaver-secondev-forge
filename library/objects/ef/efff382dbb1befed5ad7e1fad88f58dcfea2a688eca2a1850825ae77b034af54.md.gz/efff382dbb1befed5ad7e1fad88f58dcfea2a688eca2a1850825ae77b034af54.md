---
table_name: wrgm_monitor_set
cn_name: 目标监控表
module: OKR
database: wr-goal
type: 
owner: 何前锋
creator: 系统管理员
public_config: 0
data_id: 100655700000005597
has_fields: true
tags: [E10, 数据字典]
---

# wrgm_monitor_set

> 目标监控表

> [!info] 基本信息
> - 数据库表名：`wrgm_monitor_set`
> - 中文名称：目标监控表
> - 所属模块：OKR
> - 所属数据库：`wr-goal`
> - 表类型：—
> - 负责人：何前锋
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：目标监控表
> - 数据ID：`100655700000005597`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | wms_name | 监控名称 | 字符 | 200 |  |  |  |  |  |  |  |
| 2 | wms_person_type | 监控人类型 | 整型 |  |  |  |  |  |  |  |  |
| 3 | wms_person_id | 监控人id | 大字段1 |  |  |  |  |  |  |  |  |
| 4 | wms_monitor_type | 监控目标类型 | 长整型 |  |  |  |  |  |  |  |  |
| 5 | wms_monitor_range | 监控范围 | 整型 |  |  |  |  |  |  |  |  |
| 6 | wms_opt_auth | 操作权限 | 字符 | 50 |  |  |  |  |  |  |  |
| 7 | wms_extern | 扩展字段 | 大字段1 |  |  |  |  |  |  |  |  |
| 8 | wms_monitor_level | 监控目标级别 | 整型 |  |  |  |  |  |  |  |  |
| 9 | wms_monitor_range_id | 监控范围id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/OKR]]
- 数据库索引：[[数据库索引/wr-goal]]
