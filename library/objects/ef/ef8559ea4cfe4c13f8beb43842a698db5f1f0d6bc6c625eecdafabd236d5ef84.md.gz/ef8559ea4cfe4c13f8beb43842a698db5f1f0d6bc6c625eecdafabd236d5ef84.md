---
table_name: template_step_electronicsign
cn_name: 
module: 
database: ebuilder_form
type: 
owner: 
creator: 柳直阳
public_config: 0
data_id: 100655700000000980
has_fields: true
tags: [E10, 数据字典]
---

# template_step_electronicsign

> [!info] 基本信息
> - 数据库表名：`template_step_electronicsign`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`ebuilder_form`
> - 表类型：—
> - 负责人：—
> - 创建者：柳直阳
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000000980`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | step_id |  | 小数 |  |  |  |  |  |  |  |  |
| 2 | file_id |  | 小数 |  |  |  |  |  |  |  |  |
| 3 | file_name |  | 字符 | 200 |  |  |  |  |  |  |  |
| 4 | business_cate_id |  | 小数 |  |  |  |  |  |  |  |  |
| 5 | bsuiness_cate_name |  | 字符 | 200 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/ebuilder_form]]
