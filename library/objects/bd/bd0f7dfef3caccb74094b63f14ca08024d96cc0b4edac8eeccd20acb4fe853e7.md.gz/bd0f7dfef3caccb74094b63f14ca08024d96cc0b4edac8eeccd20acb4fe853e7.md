---
table_name: fileobj_microsoft365_callback
cn_name: microsoft365回调记录表
module: 文件服务
database: files
type: 普通表
owner: 陈鑫(SH)
creator: 刘琦（采知连）
public_config: 0
data_id: 1013725424332587057
has_fields: true
tags: [E10, 数据字典]
---

# fileobj_microsoft365_callback

> microsoft365回调记录表

> [!info] 基本信息
> - 数据库表名：`fileobj_microsoft365_callback`
> - 中文名称：microsoft365回调记录表
> - 所属模块：文件服务
> - 所属数据库：`files`
> - 表类型：普通表
> - 负责人：陈鑫(SH)
> - 创建者：刘琦（采知连）
> - 是否公共配置：0
> - 描述：microsoft365回调记录表
> - 数据ID：`1013725424332587057`
> - 最后更新：2024-06-24 18:52:23

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | tenant_id | 365插件tenant | 字符 | 255 |  |  |  |  |  |  |  |
| 8 | delta_link | token链接地址 | 字符 | 255 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/文件服务]]
- 数据库索引：[[数据库索引/files]]
