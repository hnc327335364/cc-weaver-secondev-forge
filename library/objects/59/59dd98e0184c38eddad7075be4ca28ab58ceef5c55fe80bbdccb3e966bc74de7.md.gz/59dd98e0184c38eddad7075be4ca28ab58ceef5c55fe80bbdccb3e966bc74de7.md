---
table_name: batch_operatelogs
cn_name: 批处理操作日志表
module: 导入导出服务
database: ebatch
type: 普通表
owner: 汤海军
creator: 董明（JS）
public_config: 0
data_id: 1230041005576429647
has_fields: true
tags: [E10, 数据字典]
---

# batch_operatelogs

> 批处理操作日志表

> [!info] 基本信息
> - 数据库表名：`batch_operatelogs`
> - 中文名称：批处理操作日志表
> - 所属模块：导入导出服务
> - 所属数据库：`ebatch`
> - 表类型：普通表
> - 负责人：汤海军
> - 创建者：董明（JS）
> - 是否公共配置：0
> - 描述：批处理操作日志表
> - 数据ID：`1230041005576429647`
> - 最后更新：2026-01-28 17:07:19

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | uuid | 字符 | 36 |  |  |  |  |  |  | uuid |
| 8 | date1 | 日志时间 | 日期 |  |  |  |  |  |  |  | 日志时间 |
| 9 | device | 设备 | 字符 | 500 |  |  |  |  |  |  | 设备 |
| 10 | operator1 | 操作人 | 长整型 | 20 |  |  |  |  |  |  | 操作人 |
| 11 | operatorname | 操作人名称 | 字符 | 100 |  |  |  |  |  |  | 操作人名称 |
| 12 | targetid | 导出ID | 字符 | 255 |  |  |  |  |  |  | 导出ID |
| 13 | targetname | 导出名称 | 大字段1 |  |  |  |  |  |  |  | 导出名称 |
| 14 | modulename | 模块名 | 字符 | 100 |  |  |  |  |  |  | 模块名 |
| 15 | functionname | 方法名 | 字符 | 100 |  |  |  |  |  |  | 方法名 |
| 16 | interfacename | 接口名 | 字符 | 100 |  |  |  |  |  |  | 接口名 |
| 17 | requesturl | 请求url | 字符 | 200 |  |  |  |  |  |  | 请求url |
| 18 | requesturi | 请求url | 字符 | 200 |  |  |  |  |  |  | 请求url |
| 19 | operatetype | 操作类型 | 字符 | 50 |  |  |  |  |  |  | 操作类型 |
| 20 | operatetypename | 操作名 | 字符 | 100 |  |  |  |  |  |  | 操作名 |
| 21 | operatedesc | 操作描述 | 字符 | 3000 |  |  |  |  |  |  | 操作描述 |
| 22 | params | 参数 | 大字段1 |  |  |  |  |  |  |  | 参数 |
| 23 | belongmainid | belongmainid | 字符 | 36 |  |  |  |  |  |  | belongmainid |
| 24 | clientip | 客户端ip | 字符 | 50 |  |  |  |  |  |  | 客户端ip |
| 25 | groupid | 分组id | 字符 | 50 |  |  |  |  |  |  | 分组id |
| 26 | groupnamelabel | 分组名称 | 字符 | 1000 |  |  |  |  |  |  | 分组名称 |
| 27 | redoservice | 服务 | 字符 | 200 |  |  |  |  |  |  | 服务 |
| 28 | redocontext | redocontext | 大字段1 |  |  |  |  |  |  |  | redocontext |
| 29 | cancelservice | cancelservice | 字符 | 200 |  |  |  |  |  |  | cancelservice |
| 30 | cancelcontext | cancelcontext | 大字段1 |  |  |  |  |  |  |  | cancelcontext |
| 31 | totalruntime | totalruntime | 长整型 | 20 |  |  |  | 0 |  |  | totalruntime |
| 32 | mainruntime | mainruntime | 长整型 | 20 |  |  |  | 0 |  |  | mainruntime |
| 33 | result1 | log_result | 字符 | 100 |  |  |  |  |  |  | log_result |
| 34 | fromterminal | fromterminal | 字符 | 100 |  |  |  |  |  |  | fromterminal |
| 35 | resultdesc | resultdesc | 大字段1 |  |  |  |  |  |  |  | resultdesc |
| 36 | old_content | old_content | 字符 | 3000 |  |  |  |  |  |  | old_content |
| 37 | link_type | link_type | 字符 | 20 |  |  |  |  |  |  | link_type |
| 38 | link_id | link_id | 长整型 | 20 |  |  |  |  |  |  | link_id |
| 39 | old_link_id | old_link_id | 长整型 | 20 |  |  |  |  |  |  | old_link_id |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/导入导出服务]]
- 数据库索引：[[数据库索引/ebatch]]
