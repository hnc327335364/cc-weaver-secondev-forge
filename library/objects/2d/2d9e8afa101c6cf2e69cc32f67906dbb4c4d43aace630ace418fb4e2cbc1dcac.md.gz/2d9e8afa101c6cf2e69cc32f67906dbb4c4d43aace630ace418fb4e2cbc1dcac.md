---
table_name: attend_configuration
cn_name: 出勤模块全局基础配置表
module: 出勤
database: attend
type: 普通表
owner: 平振亚
creator: 姜坤友
public_config: 0
data_id: 935782393761390603
has_fields: true
tags: [E10, 数据字典]
---

# attend_configuration

> 出勤模块全局基础配置表

> [!info] 基本信息
> - 数据库表名：`attend_configuration`
> - 中文名称：出勤模块全局基础配置表
> - 所属模块：出勤
> - 所属数据库：`attend`
> - 表类型：普通表
> - 负责人：平振亚
> - 创建者：姜坤友
> - 是否公共配置：0
> - 描述：出勤模块全局基础配置表
> - 数据ID：`935782393761390603`
> - 最后更新：2023-11-27 17:53:37

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | config_name | 配置名称 | 字符 | 255 |  |  |  |  |  |  |  |
| 8 | config_key | config_key | 字符 | 255 |  |  |  |  |  |  |  |
| 9 | config_value | config_value | 字符 | 2000 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/出勤]]
- 数据库索引：[[数据库索引/attend]]
