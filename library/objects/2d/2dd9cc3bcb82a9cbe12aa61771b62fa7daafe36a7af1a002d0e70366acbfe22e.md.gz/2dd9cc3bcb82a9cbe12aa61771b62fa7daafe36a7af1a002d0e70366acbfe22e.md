# 市场活动分析

来源快照：`result_data_new_260518.json`

- 来源 ID：`1192822597094072728`
- 模块：营销管理
- 目录：报表
- space ID：`1191803907993100290`
- 原文链接：未提供
- 产品基线：未提供

## 正文

1．

# 功能背景及价值

背景：

目前系统缺少报表分析，企业缺乏对海量数据的深度分析能力，难以从分散的数据中提取有价值的信息支持业务决策

数据展现困难，管理层在进行业务决策时，需要将多套系统的数据在统一页面进行可视化、图像化的展现

价值：

1.提升数据整合能力，统计报表能够整合分散在不同系统中的数据，建立统一的管理平台，优化数据从采集到分析的全流程管理

2.通过深度分析数据，生成多种统计报表和可视化图表，为企业管理层提供直观的业务洞察，支持科学决策

3.提供可视化工具 统计报表能够以图表形式直观展示数据，帮助管理层快速理解业务状况，提升数据的可读性和决策的准确性

2．

# 功能概述

该功能用于统计通过市场活动产生的线索，以及线索最终转为客户户和商机的转化率

3．

# 功能详细说明

# 3.1 数据统计

总时长投入：默认统计当前人员以及下属今年负责主导的市场活动（注：活动需要结束，并且费用需要报销才可统计）

产生价值： 默认统计当前人员以及下属今年负责主导的市场活动产生的有效线索所转化的赢单商机金额

转化有效线索： 默认统计当前人员以及下属今年负责主导的市场活动所产生的有效线索数量

综合ROI：默认统计当前人员以及下属今年负责主导的市场活动的支出费用以及市场活动产生线索转化为价值的整体投资回报率

![](https://weapp.eteams.cn/papi/file/preview?fileId=1192822652810862597&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

# 3.2 市场线索转化分析

默认统计当前人员及下属今年负责主导的市场活动费用和产生的线索数量

![](https://weapp.eteams.cn/papi/file/preview?fileId=1192822652808216581&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

鼠标移动至统计项上可显示具体的统计数据项

![](https://weapp.eteams.cn/papi/file/preview?fileId=1192822648655855637&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

# 3.3 市场商机转化分析

默认统计当前人员及下属今年负责主导的市场活动费用和产生线索转化为商机的数量

![](https://weapp.eteams.cn/papi/file/preview?fileId=1192822648566226951&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

鼠标移动至统计图上即可显示出对应的数据项

![](https://weapp.eteams.cn/papi/file/preview?fileId=1192822652868075523&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

# 四．上下游关联功能点

**无**
