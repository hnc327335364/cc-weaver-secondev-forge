# 绩效结果分析

来源快照：`result_data_new_260518.json`

- 来源 ID：`1183918541472145462`
- 模块：低代码平台e-builder
- 目录：页面引擎 - 页面设计器 - 页面组件 - 模块组件 - 模块组件_绩效考核
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 绩效结果分析

一、

## 功能背景

随着用户场景的搭建，绩效结果分析组件旨在帮助用户可以快速搭建出目标场景，方便用户进行绩效成果的快捷查看。

二、

## 功能概述

可按照周期、分制来查看各人员下各分数段的个数；并可点击查看对应考核数据。

三、

## 功能详细操作

该组件配置包括标题、图标、启用标题，皆为通用属性，不展开说明，都是统一的逻辑

![](https://weapp.eteams.cn/papi/file/preview?fileId=1202096715518795787&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

以下为绩效考核模块有数据时，绩效考核结果相关分析时展示内容与样式。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1202096913185300482&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

点击个数右侧展示对应的考核数据，可点击考核数据查看考核详情，也可对考核数据进行筛选等操作

![](https://weapp.eteams.cn/papi/file/preview?fileId=1202097033404268551&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

四、

## 上下游关联功能点

五、

组件样式

六、

组件事件动作

七、

组件权限
