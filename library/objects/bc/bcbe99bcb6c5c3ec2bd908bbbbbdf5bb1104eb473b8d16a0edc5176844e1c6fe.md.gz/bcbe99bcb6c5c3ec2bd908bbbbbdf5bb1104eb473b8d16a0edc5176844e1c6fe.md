---
table_name: hrsa_salary_sob_item
cn_name: 薪资账套薪资项目
module: 薪酬管理
database: hrm_salary
type: 普通表
owner: 蔡志军
creator: 系统管理员
public_config: 0
data_id: 100655700000004754
has_fields: true
tags: [E10, 数据字典]
---

# hrsa_salary_sob_item

> 薪资账套薪资项目

> [!info] 基本信息
> - 数据库表名：`hrsa_salary_sob_item`
> - 中文名称：薪资账套薪资项目
> - 所属模块：薪酬管理
> - 所属数据库：`hrm_salary`
> - 表类型：普通表
> - 负责人：蔡志军
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：薪资账套薪资项目
> - 数据ID：`100655700000004754`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | salary_sob_id | 薪资账套的id | 长整型 |  |  |  |  | 0 |  |  |  |
| 2 | salary_item_id | 薪资项目的id | 长整型 |  |  |  |  | 0 |  |  |  |
| 3 | salary_sob_item_group_id | 薪资账套薪资项目分组id | 长整型 |  |  |  |  | 0 |  |  |  |
| 4 | formula_id | 公式 | 长整型 |  |  |  |  | 0 |  |  |  |
| 5 | sorted_index | 排序字段 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | description_ | 备注 | 字符 | 1000 |  |  |  |  |  |  |  |
| 7 | can_delete | 是否可以删除 | 整型 |  |  |  |  | 1 |  |  |  |
| 8 | income_category | 薪资类型 | 字符 | 100 |  |  |  | 1 |  |  |  |
| 9 | salary_item_code | 薪资项目编号 | 字符 | 100 |  |  |  |  |  |  |  |
| 10 | data_type | 字段类型 | 字符 | 100 |  |  |  | string |  |  |  |
| 11 | rounding_mode | 舍入规则 | 整型 |  |  |  |  | 2 |  |  |  |
| 12 | pattern | 小数位数 | 整型 |  |  |  |  | 2 |  |  |  |
| 13 | value_type | 取值方式 | 整型 |  |  |  |  | 1 |  |  |  |
| 14 | can_edit | 是否可以编辑 | 整型 |  |  |  |  | 1 |  |  |  |
| 15 | use_in_employee_salary | 是否来自于薪资档案 | 整型 |  |  |  |  |  |  |  |  |
| 16 | hide_switch | 核算时隐藏 | 整型 |  |  |  |  |  |  |  |  |
| 17 | sum_switch | 核算值合计 | 整型 |  |  |  |  |  |  |  |  |
| 18 | readonly_switch | 核算值不可编辑 | 整型 |  |  |  |  |  |  |  |  |
| 19 | item_name | 项目名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 20 | datasource | 数据源 | 大字段1 |  |  |  |  |  |  |  |  |
| 21 | datasource_field | 数据源字段 | 大字段1 |  |  |  |  |  |  |  |  |
| 22 | datasource_count_type | 数据源统计方式 | 字符 | 100 |  |  |  |  |  |  |  |
| 23 | datasource_condition | 数据源条件 | 大字段1 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/薪酬管理]]
- 数据库索引：[[数据库索引/hrm_salary]]
