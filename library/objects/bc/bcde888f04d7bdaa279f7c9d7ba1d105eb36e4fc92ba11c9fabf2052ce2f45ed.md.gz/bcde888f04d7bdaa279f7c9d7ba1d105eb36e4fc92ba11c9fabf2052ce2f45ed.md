---
table_name: inc_titles_ph_inc_tax_no
cn_name: 税号权限范围表
module: 发票助手
database: weaver_inc
type: 普通表
owner: 温明刚
creator: 张润楠
public_config: 0
data_id: 1123502241366745103
has_fields: true
tags: [E10, 数据字典]
---

# inc_titles_ph_inc_tax_no

> 税号权限范围表

> [!info] 基本信息
> - 数据库表名：`inc_titles_ph_inc_tax_no`
> - 中文名称：税号权限范围表
> - 所属模块：发票助手
> - 所属数据库：`weaver_inc`
> - 表类型：普通表
> - 负责人：温明刚
> - 创建者：张润楠
> - 是否公共配置：0
> - 描述：税号权限范围表
> - 数据ID：`1123502241366745103`
> - 最后更新：2025-04-16 14:42:30

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | module_id | 模块标识 | 字符 | 64 |  |  |  |  |  |  |  |
| 8 | source_type | 资源类型 | 整型 |  |  |  |  |  |  |  |  |
| 9 | source_origin_id | 资源原始id | 长整型 |  |  |  |  |  |  |  |  |
| 10 | source_id | 资源id | 长整型 |  |  |  |  |  |  |  |  |
| 11 | source_sub_id | 资源id | 长整型 |  |  |  |  |  |  |  |  |
| 12 | source_create_time | 资源创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 13 | source_min_sec_level | 资源选择安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 14 | source_max_sec_level | 资源选择安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 15 | source_station_level | 资源岗位级别 | 整型 |  |  |  |  |  |  |  |  |
| 16 | source_role_level | 资源角色级别 | 整型 |  |  |  |  |  |  |  |  |
| 17 | source_organization_dimension | 资源组织维度 | 整型 |  |  |  |  |  |  |  |  |
| 18 | target_id | 共享目标的ID | 长整型 |  |  |  |  |  |  |  |  |
| 19 | target_sub_id | 共享目标的ID | 长整型 |  |  |  |  |  |  |  |  |
| 20 | target_min_sec_level | 共享目标的最小安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 21 | target_max_sec_level | 共享目标的最大安全级别 | 整型 |  |  |  |  |  |  |  |  |
| 22 | target_station_level | 岗位级别 | 整型 |  |  |  |  |  |  |  |  |
| 23 | target_station_bs_id | 指定部门/指定分部 | 长整型 |  |  |  |  |  |  |  |  |
| 24 | target_role_level | 角色级别 | 整型 |  |  |  |  |  |  |  |  |
| 25 | target_organization_dimension | 组织维度 | 整型 |  |  |  |  |  |  |  |  |
| 26 | target_subordinate_include | 包含所有下级 | 整型 |  |  |  |  |  |  |  |  |
| 27 | permission_type | 权限类型 | 整型 |  |  |  |  |  |  |  |  |
| 28 | permission_config_id | 默认共享配置ID | 长整型 |  |  |  |  |  |  |  |  |
| 29 | permission_config_source_id | 默认共享配置资源ID | 长整型 |  |  |  |  |  |  |  |  |
| 30 | download | download | 整型 |  |  |  |  |  |  |  |  |
| 31 | permission_external_id | permission_external_id | 长整型 |  |  |  |  |  |  |  |  |
| 32 | target_organization_id | 组织维度id | 长整型 |  |  |  |  |  |  |  |  |
| 33 | target_type | 共享目标类型 | 整型 |  |  |  |  |  |  |  |  |
| 34 | target_supordinate_include | 包含所有上级 | 整型 |  |  |  |  |  |  |  |  |
| 35 | target_name | 共享目标名称 | 字符 | 200 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/发票助手]]
- 数据库索引：[[数据库索引/weaver_inc]]
