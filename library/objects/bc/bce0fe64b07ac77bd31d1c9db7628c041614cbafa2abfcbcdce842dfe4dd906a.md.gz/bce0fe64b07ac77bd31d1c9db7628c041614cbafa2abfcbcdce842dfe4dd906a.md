---
table_name: ecode_monitorlogs
cn_name: ecode服务monitor操作日志表
module: e-code开发平台
database: ecode
type: 普通表
owner: 马宏伟
creator: 李玉逸
public_config: 0
data_id: 1120596571575844969
has_fields: true
tags: [E10, 数据字典]
---

# ecode_monitorlogs

> ecode服务monitor操作日志表

> [!info] 基本信息
> - 数据库表名：`ecode_monitorlogs`
> - 中文名称：ecode服务monitor操作日志表
> - 所属模块：e-code开发平台
> - 所属数据库：`ecode`
> - 表类型：普通表
> - 负责人：马宏伟
> - 创建者：李玉逸
> - 是否公共配置：0
> - 描述：ecode服务monitor操作日志表
> - 数据ID：`1120596571575844969`
> - 最后更新：2025-04-08 18:47:01

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  | CURRENT_TIMESTAMP |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  | CURRENT_TIMESTAMP |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | uuid | 字符 | 40 |  |  |  |  |  |  |  |
| 8 | log_date | 操作时间 | 日期时间 |  |  |  |  | CURRENT_TIMESTAMP |  |  |  |
| 9 | device | 终端信息 | 字符 | 500 |  |  |  |  |  |  |  |
| 10 | log_operator | 操作人 | 长整型 |  |  |  |  |  |  |  |  |
| 11 | operatorname | 操作人姓名 | 字符 | 100 |  |  |  |  |  |  |  |
| 12 | targetid | 操作目标id | 长整型 |  |  |  |  |  |  |  |  |
| 13 | targetname | 操作目标名称 | 字符 | 3000 |  |  |  |  |  |  |  |
| 14 | modulename | 模块 | 字符 | 100 |  |  |  |  |  |  |  |
| 15 | functionname | 服务(方法) | 字符 | 100 |  |  |  |  |  |  |  |
| 16 | interfacename | 访问接口名 | 字符 | 100 |  |  |  |  |  |  |  |
| 17 | requesturl | 请求全路径 | 大字段3 |  |  |  |  |  |  |  |  |
| 18 | requesturi | 请求地址 | 大字段3 |  |  |  |  |  |  |  |  |
| 19 | operatetype | 操作类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 20 | operatetypename | 操作类型名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 21 | operatedesc | 操作类型详细说明 | 字符 | 3000 |  |  |  |  |  |  |  |
| 22 | params | 涉及相关参数 | 大字段3 |  |  |  |  |  |  |  |  |
| 23 | belongmainid | 所属主表uuid | 字符 | 40 |  |  |  |  |  |  |  |
| 24 | clientip | 操作ip | 字符 | 200 |  |  |  |  |  |  |  |
| 25 | groupid | 分组 | 字符 | 50 |  |  |  |  |  |  |  |
| 26 | groupnamelabel | 分组标题 | 字符 | 1000 |  |  |  |  |  |  |  |
| 27 | redoservice | 重做业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 28 | redocontext | 重做参数 | 大字段3 |  |  |  |  |  |  |  |  |
| 29 | cancelservice | 撤销业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 30 | cancelcontext | 撤销参数 | 大字段3 |  |  |  |  |  |  |  |  |
| 31 | totalruntime | 总运行时长 | 长整型 |  |  |  |  |  |  |  |  |
| 32 | mainruntime | 主方法运行时长 | 长整型 |  |  |  |  |  |  |  |  |
| 33 | log_result | 运行结果标识 | 字符 | 100 |  |  |  |  |  |  |  |
| 34 | fromterminal | 来子pc web | 字符 | 100 |  |  |  |  |  |  |  |
| 35 | resultdesc | 运行结果描述 | 大字段3 |  |  |  |  |  |  |  |  |
| 36 | old_content | 原先内容 | 大字段3 |  |  |  |  |  |  |  |  |
| 37 | link_type | 链接类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 38 | link_id | 链接id | 长整型 |  |  |  |  |  |  |  |  |
| 39 | old_link_id | 原先链接id | 长整型 |  |  |  |  |  |  |  |  |
| 40 | operate_tenant_key | 操作租户 | 字符 | 10 |  |  |  |  |  |  |  |
| 41 | business_type | 操作应用类型 | 字符 | 40 |  |  |  |  |  |  |  |
| 42 | targetinfo | 操作对象信息 | 大字段3 |  |  |  |  |  |  |  |  |
| 43 | root_folder_id | 应用id | 长整型 |  |  |  |  |  |  |  |  |
| 44 | targetinfolabels | 操作对象信息 | 大字段3 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-code开发平台]]
- 数据库索引：[[数据库索引/ecode]]
