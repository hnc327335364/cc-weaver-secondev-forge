---
table_name: attend_scheduling_report
cn_name: 出勤排班报表
module: 出勤
database: attend
type: 普通表
owner: 平振亚
creator: 姜坤友
public_config: 0
data_id: 1011805887353110537
has_fields: true
tags: [E10, 数据字典]
---

# attend_scheduling_report

> 出勤排班报表

> [!info] 基本信息
> - 数据库表名：`attend_scheduling_report`
> - 中文名称：出勤排班报表
> - 所属模块：出勤
> - 所属数据库：`attend`
> - 表类型：普通表
> - 负责人：平振亚
> - 创建者：姜坤友
> - 是否公共配置：0
> - 描述：排班报表数据
> - 数据ID：`1011805887353110537`
> - 最后更新：2024-06-19 14:43:36

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | employee_id | 员工 | 长整型 |  |  |  |  |  |  |  |  |
| 8 | attend_date | 出勤日 | 日期 |  |  |  |  |  |  |  |  |
| 9 | day_type | 日期类型 | 字符 | 255 |  |  |  |  |  |  |  |
| 10 | attend_config_id | 考勤规则ID | 长整型 |  |  |  |  |  |  |  |  |
| 11 | attend_shift_id | 班次ID | 长整型 |  |  |  |  |  |  |  |  |
| 12 | dept_id | 部门ID | 长整型 |  |  |  |  |  |  |  |  |
| 13 | subcompany_id | 分部ID | 长整型 |  |  |  |  |  |  |  |  |
| 14 | position_id | 岗位ID | 长整型 |  |  |  |  |  |  |  |  |
| 15 | create_source | 来源 | 字符 | 255 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/出勤]]
- 数据库索引：[[数据库索引/attend]]
