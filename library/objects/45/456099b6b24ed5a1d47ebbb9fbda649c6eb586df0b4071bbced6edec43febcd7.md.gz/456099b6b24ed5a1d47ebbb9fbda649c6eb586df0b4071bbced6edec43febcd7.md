# 网页水印增加刷新频率设置

来源快照：`result_data_new_260518.json`

- 来源 ID：`1185024671577415693`
- 模块：通用设置
- 目录：功能更新说明 - 2025-09
- space ID：`1159151861511495737`
- 原文链接：未提供
- 产品基线：未提供

## 正文

一、

# 功能背景和价值用途

目前，网页水印采用主框架缓存机制进行刷取，导致网页刷新后，水印所记录的时间仍为刷新前的旧时间，无法实时更新。为解决这一问题，亟需优化水印的刷新机制。

二、

# 功能说明

## 1 功能配置

入口：通用设置-水印设置-网页水印，PC&移动端均适用。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1185026256351305740&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

说明：

1、默认选中【刷新页面时更新】，即刷新页面时更新水印。

2、可选择【动态刷新】，动态刷新需配置刷新时间，如图2所示，筛选“刷新时间”为必填，默认10分钟，最低1分钟：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1185026260669931523&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

## 2 工作消息水印

工作消息水印设置【系统默认水印、自定义水印】均走系统水印设置刷新频率：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1185026252131835910&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 3 流程水印

流程水印设置【系统默认水印、自定义水印】均走系统水印设置刷新频率：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1185026260605296647&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 4 文件/附件水印

确认下来，文件加水印的实现逻辑，是调用三方的能力生成一个带水印的文件，如果要更新水印，就需要重新再生成一个带水印的文件，去替换用户正在预览的文件，所以动态更新水印的功能暂且不做。
