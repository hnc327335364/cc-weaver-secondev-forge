# AI对话组件

来源快照：`result_data_new_260518.json`

- 来源 ID：`1183972443143938050`
- 模块：低代码平台e-builder
- 目录：页面引擎 - 页面设计器 - 页面组件 - 模块组件 - 模块组件-AI连接器
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# AI对话组件

一、

## 功能背景

功能场景需要用AI助手，比如表单上、页面上增加某个智能体的功能，将AI对话组件组件组成EB组件，拖拽式拖入，减少代码开发。

二、

## 功能概述及使用说明

### 2.1 功能入口

1、表单设计器和页面设计器增加组件【AI对话组件】，如下图：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328292223893512&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328292223893518&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、【AI应用】：支持选择系统内已配置的AI应用，有【AI连接器】权限用户支持快捷新建引用以及快速进入智能化后台

### 2.2、属性说明

【打开方式】：AI对话组件支持弹出窗口、嵌入当前页面、新窗口三种打开方式，

【弹窗位置】：AI对话窗口支持居中、右下角、右侧滑出、右侧推出四种弹出位置；

【默认打开】：仅打开方式设置为弹出窗口时支持此设置，设置项默认关闭，用户点击对话组件后按照设置的弹窗位置显示对话窗口，开启后表单或门户页面加载时自动打开对话窗口；

【窗口宽度】、【窗口高度】：打开方式设置为弹出窗口或嵌入当前页面时支持设置对话窗口高度、宽度，支持百分比模式及指定具体的高度（px）值；

【窗口自定义属性】:结合开发 给对话窗口增加自定义样式使用；

【入口展现方式】：打开方式为弹出窗口及新窗口时支持设置入口展示方式，支持链接及悬浮图标两种设置；使用链接效果时支持将对话图标放在布局不同位置显示，使用悬浮图标效果时根据设置的偏移量显示在表单或门户布局上；

 

【按钮内容】：对话组件入口展示方式设置为悬浮图标时支持设置按钮内容，按钮内容可设置为仅显示图标、仅显示文字以及图标+文字效果；

1、图标：可自定义上传或选择合适的图标。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328292158988303&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、文字：可自定义输入不同的按钮名称，设置文字大小，文字换行显示，文字对齐方式。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328296336515084&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D) 

 

3、图标+文字：可设置图标大小，按钮名称等文字相关设置，图标与文字相对位置、图标文字间距等。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328296479948815&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D) 

【显示位置】：可选择在页面不同方位显示，如底部、右侧等，适应不同布局需求。

【偏移量算法】：可切换设置不同的算法，像素/百分比；像素算法根据按钮对应边角定位，百分比算法根据悬浮按钮中心位置定位。

【距下偏移/距右偏移】：以像素为单位，设置按钮距离页面底部、右侧的距离，微调显示位置。以百分比为单位，设置按钮中心位置在整个屏幕中的比例。

【按钮宽度/按钮高度】：以像素为单位，设定按钮自身的宽和高，调整按钮大小。

【按钮圆角】：以百分比形式，设置按钮边角的圆润程度，改变外观样式。

【侧边收起】：开启后，悬浮按钮会根据当前位置自动向同高度的左侧边或右侧边收起，节省空间，需要时可展开。效果如下图：

1、若悬浮按钮距离左侧区域近，则向左侧边收起;

2、若悬浮按钮距离右侧区域近，则向右侧边收起;

3、侧边收起与回到顶顶/底部功暂不支持同时启用。

    ![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328296305885212&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

【允许拖动】：开启后，用户能在页面内拖动按钮，调整其位置。

【移入提示】：配置提示内容后，输入经过对话组件悬浮按钮显示提示文字；

【提示内容】:文本提示可直接在文本中输入对应信息

【提示位置】:可配置固定位置和自适应位置：

1、自适应位置：会根据悬浮按钮的位置自动调整提示文字的位置，显示在悬浮按钮的左侧或右侧；

2、固定位置：提示文字的位置会固定在是浮按钮旁，若存在固定位置显示不下的情况，系统会自适应调整位置。

 

### 2.3前台效果

三、

打开方式弹出窗口 弹窗位置为右侧弹出，入口展示为悬浮图标效果如下：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328300626018307&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

四、

嵌入当前页面效果

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328300626018312&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

五、

配置为链接效果

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163328300632309771&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
