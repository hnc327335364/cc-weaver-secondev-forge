# 公文助手

来源快照：`result_data_new_260518.json`

- 来源 ID：`1181424483926089860`
- 模块：公文管理
- 目录：管理员操作指南 - 公文设置 - 智能助手
- space ID：`1963763057932358932`
- 原文链接：未提供
- 产品基线：未提供

## 正文

一、

# 功能背景及价值用途

公文拟稿时经常需要花费大量的时间来进行，不同种类的公文也存在不同的格式差异，拟稿人员对于相关素材的整理，公文的格式、用语规范的处理等也耗时耗力，导致工作效率不高。

因此增加公文助手功能，帮助用户快速写作，对语句进行改写润色，自动检测公文中存在的错误，既提高相关人员的工作效率，也提高公文的质量。

二、

# 功能概述

公文助手共分为五部分：写作（根据关键信息生成、根据大纲生成）、改写润色、智能核稿、智能推荐、智能排版

三、

# 功能详细说明

1.

## 公文助手功能所需服务配置

### 1.1 公文助手写作、改写润色、AI助手服务配置

(1)

#### **模型鉴权设置**

入口：后台管理-AI连接器-模型鉴权设置中配置好对应模型。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052847254642691&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

AI连接器已对接封装好各种主流大模型，仅需要配置鉴权key即可使用。

智能小e： 支持小e问答、小e智能体、小e客户问答 三种方式接入。

公有云厂商： 支持 智谱、讯飞、腾讯、百度、阿里、miniMax、百川、字节跳动、商汤、月之暗面、零一万物、deepseek、openAI 等主流厂商大模型

私有化模型部署对接： 支持Qwen,Chatglm,baichuan等各种开源模型部署和对接

支持自定义模型对接： 只需要模型提供方接口兼容openai模式，即可配置化接入

(2)

#### **写作、改写润色功能智能体配置**

入口：后台设置-后台管理-AI连接器-智能体构建-**智能公文**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052872939053063&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

智能体调整：根据实际模型鉴权设置中配置的模型做调整

①

模型设置-选择模型中选择已配置且可用的模型

②

右上角参数设置中打开是否流式（stream）开关

③

设置好后页面会自动保存（最好刷新页面后再次打开确认是否保存上），再通过右侧预览与调试中对话进行模型测试，若对话内容正常可输出表示模型配置正常，若未正常输出请检查步骤 _1.1模型鉴权设置_ 中模型配置是否正常。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052860115345421&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

(3)

#### **AI助手功能智能体配置**

入口：后台设置-后台管理-AI连接器-智能体构建-**公文AI助手**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052868535033875&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

智能体调整：根据实际模型鉴权设置中配置的模型做调整

①

模型设置-选择模型中选择已配置且可用的模型

②

设置好后页面会自动保存（最好刷新页面后再次打开确认是否保存上），再通过右侧预览与调试中对话进行模型测试，若对话内容正常可输出表示模型配置正常，若未正常输出请检查步骤 _1.1模型鉴权设置_ 中模型配置是否正常。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052872939053077&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.

## 智能核稿校对服务配置（目前集成金山黑马、千里聆校对、大模型校对，支持私有化部署）

### 2.1 金山黑马校对

金山黑马校对配置文件修改

配置文件：weaver-odoc-service.properties中配置黑马校对相关地址、账密

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052873005023240&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 2.2 千里聆校对

千里聆校对配置：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052855759183891&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 2.3 大模型校对

(1)

#### **模型鉴权配置**

 _配置同步骤1.1_

(2)

#### **智能体配置**

入口：后台设置-后台管理-AI连接器-智能体构建-**公文智能校对**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052855770046475&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

智能体调整：根据实际模型鉴权设置中配置的模型做调整

①

模型设置-选择模型中选择已配置且可用的模型

②

设置好后页面会自动保存（最好刷新页面后再次打开确认是否保存上），再通过右侧预览与调试中对话进行模型测试，若对话内容正常可输出表示模型配置正常，若未正常输出请检查步骤 _1.1模型鉴权设置_ 中模型配置是否正常。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052881414021127&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

(3)

#### **配置文件修改**

weaver.odoc.ai.proofread.proofreadServerType=prompt

### 2.4 智能推荐服务配置

(1)

#### **模型鉴权配置**

 _配置同步骤1.1_

(2)

#### **重排序模型配置**

智能推荐功能相对于其他公文智能化功能额外还需配置重排序模型。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052838460735494&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

(3)

#### **智能体配置**

入口：后台设置-后台管理-AI连接器-智能体构建-**公文智能摘要**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052851480993796&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

智能体调整：根据实际模型鉴权设置中配置的模型做调整

①

模型设置-选择模型中选择已配置且可用的模型

②

设置好后页面会自动保存（最好刷新页面后再次打开确认是否保存上），再通过右侧预览与调试中对话进行模型测试，若对话内容正常可输出表示模型配置正常，若未正常输出请检查步骤 _1.1模型鉴权设置_ 中模型配置是否正常。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052864265232386&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3.

## 公文助手功能介绍

当有编辑正文的权限的节点，会显示“公文助手”。公文助手共分为三部分：写作、改写润色、智能核稿。

### 3.1 功能入口

入口：公文管理应用后台-公文工作流-公文设置-智能助手

注：开关联动显示；如果未配置公文助手、AI助手大模型应用（ _1.1中相关配置_ ），公文设置中不会显示对应开关

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052842889920525&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 3.2 写作

写作共有三种方式：根据关键信息生成（默认选中）、根据大纲生成、AI助手生成（公文助手中是否显示AI助手生成受后台智能助手设置开关控制）。

**根据关键信息生成说明**

（1）我是：说明当前拟稿人的身份（一般不同身份拟稿的内容会存在很大区别），默认根据拟稿人员创建流程时使用的身份展示；如：拟稿人员信息：部门A、岗位B，则自动填充信息为：部门A的岗位B。

注意：若当前拟稿人员存在多个身份，系统默认根据流程发起时使用的身份代入

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052894397112325&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）公文种类：下拉框中显示后台【公文种类】菜单下维护的类型

（3）公文标题：必填项；默认代入后台公文设置-正文标题设置中对应得字段值

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052842889920527&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（4）主题词：本次拟稿公文内容的主题，关键信息等。若输入多个主题词时，使用中文逗号（，）隔开；

（5）内容篇幅：单选（短篇、中篇、长篇，默认选中篇），智能生成公文内容的内容篇幅；（1101基线暂不受控）

（6）主送单位、发文单位：默认根据后台公文字段设置映射的表单字段值代入

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052890213670923&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（7）参考素材：支持选择系统中有权限的文档（多选关联文档浏览按钮），也支持上传本地文件（支持上传多个文件）；

（8）生成正文：当填写完成关键字后，点击【生成正文】按钮，系统会根据已填写的关键信息生成正文内容，填充到正文区域内；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191092034517966863&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（9）生成大纲：当填写完成关键字后，点击【生成正大纲】按钮，系统会根据已填写的关键信息生成大纲内容，填充到正文区域内

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191092167562797066&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（10）重写：若对生成的正文或大纲内容不满意，可点击【重写】按钮，重写后会替换已生成正文区域的内容

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191092270682447875&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（11）若已经生成过正文或大纲内容，修改关键信息后，再次点击生成，此时会替换原先生成的内容，二次确认

**根据大纲生成**

（1）大纲内容：填写后生成正文按钮才可操作，当填写大纲内容后，点击【生成正文】按钮，系统会根据已填写的大纲内容生成正文内容，填充到正文区域内

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191092768976625670&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）自动填充：将正文内容自动填充到下方的大纲区域中，比较适用于先通过关键信息生成大纲，再通过大纲来生成正文的操作；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191092872077393921&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（3）重写：重新生成正文，重写后会替换已生成正文区域的内容

（4）若已经生成过正文内容，修改大纲内容后，再次点击生成，此时会替换原先生成的内容，出现二次确认提示

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093039533432833&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

**AI助手生成**

对接智能对话助手，支持以对话的方式协助用户快速写作（受控后台公文设置【启用AI助手显示在公文助手中】开关，开关开启后AI助手显示在公文助手-写作中）

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052872999280640&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052847092613135&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（1）重写：点击重写后根据当前话题重新生成内容

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093168380944388&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）替换：框内文字直接替换正文区域中的已选内容，若正文区域内没有已选内容，则找上一次光标位置进行插入

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093284237516805&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（3）插入：将框内文字插入到正文区域中的光标处，若未找到光标位置，则默认找上一次光标位置进行插入

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093395898277891&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 3.3 改写润色

支持对正文区域内已选中的文本内容进行文字的改写或润色功能

（1）鼠标需要先选中正文中需要改写润色的文本内容，再点击具体操作；改写润色后的文字会显示在上方框内，支持编辑修改。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093507627114499&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）改写润色后的操作说明：

1)

插入：将框内文字插入到正文区域的已选内容的末尾（即光标末尾），若未找到光标位置，则默认找上一次光标位置进行插入；插入后的文字内容，在正文区域内均默认选中，可以清晰看到插入位置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093645154729986&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2)

替换：框内文字直接替换正文区域中的已选内容，若正文区域内没有已选内容，则找上一次光标位置进行插入；替换后的文字内容，在正文区域内均默认选中，可以清晰看到替换位置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093765356232707&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3)

换一换：重新生成改写润色的内容

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093864175542275&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 3.4 智能核稿

对公文正文内容进行字词、通用规则、行文规范等方面的校对，自动生成校对结果，依据错误标识，可以迅速锁定并核查以及一键替换。

（1）点击【开始检查】按钮后，系统会对正文中错误进行检测，并将检测出来的结果分类展示，并给出建议，正文内容中的错误内容点击具体错误后会自动定位到错误位置并高亮展示

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191093980080939014&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）错误类型共分为四大类：错误（字词类错误、英文拼音类错误等类型）、疑似错误（疑似的语法、字词错误）、严重错误（公文场景下的政治性错误、歧视性词语、法律禁止词汇等）、标点错误（正文内容中的标点错误）

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052881410408452&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（3）点击具体错误后，正文会自动定位到对应的错误处，用户可对该错误进行替换（将错误内容替换为建议内容）或忽略（忽略该错误，原文处不进行任何改动）；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191094246394077187&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（4）检测结果中的对于错误的分类，默认全部勾选。可点击复选框进行筛选过滤

（5）重新检测：点击【重新检测】按钮，可重新对正文内容进行校验核对

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191094375117266946&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（6）批量操作：全部替换、全部忽略

### 3.5 AI助手

AI助手独立展示效果，（功能同 _写作-AI助手生成_ 一致，同一功能不同位置展示，受控后台公文设置【启用AI助手显示在公文助手中】开关，开关关闭后AI助手独立显示在正文侧边栏）

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052885759320097&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052838631153666&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

对接智能对话助手，支持以对话的方式协助用户快速写作

(1)

重写：点击重写后根据当前话题重新生成内容

(2)

替换：框内文字直接替换正文区域中的已选内容，若正文区域内没有已选内容，则找上一次光标位置进行插入

(3)

插入：将框内文字插入到正文区域中的光标处，若未找到光标位置，则默认找上一次光标位置进行插入

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191094521355870209&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 3.6 智能推荐

智能推荐共有三个入口：

【智能推荐】页签

写作页面-【智能推荐】按钮-【智能推荐】页面

AI助手中直接对话推荐

**公文智能助手-【智能推荐】页签**

点击【智能推荐】页签：点击后，可输入公文标题或在高级搜索里输入关键信息，系统会自动推荐关联度高的公文素材

其中推荐结果页：

（1）默认按【关联度优先】进行排序，也支持根据最新创建优先、最早创建优先进行排序

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052855759183900&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）关联度颜色分为三部分：

关联度>=90，绿色；

90>关联度>=50，橙色；

关联度<50，灰色

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052877232881676&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（3）推荐结果页只能看到自己有权限的公文（公文库数据）

（4）推荐结果页的公文，点击标题或右下方“预览”按钮，弹窗展示文档具体内容；点击“替换”按钮，可直接将推荐素材替换到右侧正文区域

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052834343067652&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052894432174088&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

**写作页面-【智能推荐】按钮**

（1）从【写作-按关键信息生成】页面中，点击【智能推荐】按钮后，自动将公文标题填入到搜索框内，其余关键信息填入高级搜索条件中，系统根据这些信息自动推荐公文素材

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052842951286795&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

（2）从【写作-根据大纲生成】页面中，点击【智能推荐】按钮后，系统首先将大纲内容汇总为一个公文标题，再填入搜索框内进行推荐

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052894479859712&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

**AI助手中直接对话推荐**

通过AI助手（采用对话的方式）直接对话推荐，系统会对输入的语义进行解析，然后智能推荐公文。 推荐后的公文支持替换、预览操作，与上述入口操作一致，此处不赘述。

(1)

支持直接通过智能对话助手进行推荐功能（按关联度从高到低排序，最多展示前10条数据）

(2)

预览：点击标题或“预览”按钮，弹窗展示文档具体内容；

(3)

替换：点击标题或“替换”按钮，可直接将推荐素材替换到右侧正文区域

![](https://weapp.eteams.cn/papi/file/preview?fileId=1191052881410408459&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

四、

# 上下游关联功能点

1.

AI连接器服务：必须在AI连接器中进行完整配置后才可使用。

2.

公文字段设置：写作功能字段内容主要取后台公文流程-公文设置-公文字段设置中映射的表单字段值。

3.

智能排版功能[** _点击此处查看_**](https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1181424621334257675&space_id=1963763057932358932 "点击此处查看") 。

五、

# 注意点

1.

公文助手必须购买WPS在线服务、信创WPS客户端插件、金格iweboffice插件后才可使用。

2.

能推荐时，仅会推荐自己有权限的公文数据。
