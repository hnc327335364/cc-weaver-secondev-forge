# 文件夹模板

来源快照：`result_data_new_260518.json`

- 来源 ID：`1178063968375414837`
- 模块：知识文档
- 目录：管理员操作指南 - 知识文档
- space ID：`1161759301968437263`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景及价值用途

支持将文件夹设置存为模板，供其他文件夹可以复用一些相关配置，以提高新建/编辑文件夹的效率

# 二、功能概述及使用说明

## 1、将文件夹设置存为模板

在文件夹设置页面，选中某一文件夹，点击右上角操作菜单里【存为设置模板】打开存为模板窗口，输入模板名称确定，文件夹模版即创建成功

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867605938839566&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867601668784133&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

说明：

a.系统管理员、【文件夹维护】角色权限的用户及文件夹上文件夹权限配置的管理员可以进行文件夹存为模板以及导入文件夹模板操作

b.文件夹模板存成功之后，需要到【设置】-【系统设置】-【文件夹模板设置】页面查看存好的文件夹模板信息 

## **2、文件夹模板的查看与维护**

文件夹模板设置页面，展示了当前用户有权限维护的文件夹模板，系统管理员默认展示所有文件夹模板：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867605790859272&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867605787590664&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

说明：

a.系统管理员、【文件夹模板维护】角色权限的用户展示所有文件夹模板

b.文件夹上文件夹权限配置的管理员仅展示当前文件夹作为源文件夹存为的文件夹模板

c.文件夹模板设置页面的所有修改均与源文件夹无关，不会产生更新或覆盖

d.在文件夹模板设置页面，点击前面的check框可进行批量删除；点击模板名称可以打开详细的文件夹设置窗口，可进行调整 

## 3、导入文件夹模板应用到文件夹

在文件夹设置页面，选中某一文件夹，点击右上角操作菜单里【导入设置模板】：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867605790859266&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867605790859274&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

打开导入模板窗口，展示的是用户有权限维护的文件夹模板，选中某个模板点击确定，会弹出【应用范围】{应用于当前文件夹、应用于当前及下级文件夹} 供用户选择：

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867610049257475&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1182867610070622209&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

说明：

a.系统管理员、【文件夹维护】角色权限的用户及文件夹上文件夹权限配置的管理员可以进行导入文件夹模板操作

b.导入文件夹模板的应用范围说明：

\-->应用于当前文件夹：仅当前文件夹的设置项会被文件夹模板的设置项覆盖

\-->应用于当前及下级文件夹：当前文件夹及当前文件夹的所有下级文件夹的设置项都会被文件夹模版的设置项覆盖

# 三、使用注意点

文件夹模板不支持批量套用，若是想引用文件夹模板，则需到文件夹设置页面，选中某一文件夹导入文件夹模版才可应用。

# 四、上下游关联功能点

文件夹设置
