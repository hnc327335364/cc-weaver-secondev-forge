---
description: "middleware 组件无侵入二开 middleware：组件化方便了无侵入二次开发能力扩展，类似 E9 后续扩展的 ecode 组件无侵入修改能力，本次默认在工具库提供规范的埋点和二开注册能力，将覆盖更大范围的组件，不再仅限于公共组件库的组件。 参考一平台前端无侵入研发规范"
category: extension-hooks
keywords: ["middleware", "getOverwrite", "regOvComponent", "regOvProps", "unRegOvComponent", "unRegOvProps", "组件无侵入二开", "组件复写", "组件替换", "无侵入二开", "插件", "weId", "错误边界"]
source: "https://www.e-cology.com.cn/utils/middleware/freepass"
---

# middleware 组件无侵入二开 middleware

## 适用场景

组件化方便了无侵入二次开发能力扩展，类似 E9 后续扩展的 ecode 组件无侵入修改能力，本次默认在工具库提供规范的埋点和二开注册能力，将覆盖更大范围的组件，不再仅限于公共组件库的组件。 参考一平台前端无侵入研发规范

## 检索符号

- `getOverwrite`
- `middleware`
- `regOvComponent`
- `regOvProps`
- `unRegOvComponent`
- `unRegOvProps`

## 代表示例

```js
import { middleware } from '@weapp/utils';

@inject('demoStore')
@middleware('weappDemo', 'Demo')
@observer
class Demo extends React.Component<DemoProps> {
  render() {
    return <div className={demoClsPrefix}>demo</div>;
  }
}
export default withRouter(Demo);

middleware('weappDemo', 'Demo')(Demo);
// 不使用装饰器, 可以直接使用 function 方式处理
```

## 深入阅读
- [在线免登文档](https://www.e-cology.com.cn/utils/middleware/freepass)

> 本卡用于快速选型。参数、返回值、限制和完整示例以原始文档为准。
