# 卡片设置

来源快照：`result_data_new_260518.json`

- 来源 ID：`1166985718720102484`
- 模块：督查督办
- 目录：督办设置（非专项形式）
- space ID：`1159139608028520478`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景及价值用途

自定义布局功能允许用户根据具体督办事项的特点，调整数据展示模块和界面结构，支持用户对pc端、移动端自定义设计个性化布局，满足不同用户的需求。

# 二、业务流程图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986517668454463&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 三、功能使用说明

## 1、功能入口

【督办设置】-【卡片设置】，可在此维护配置和维护督办类型新建布局、变更布局、分解布局，支持个性化自定义设置布局。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986508938838069&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2、默认设置

① 

应用初始化后，会自动生成【默认设置】，卡片上显示当前使用的布局名称。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986504660647967&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

② 

点击对应卡片布局，打开表单设计器，可自定义配置布局，如点击pc端督办任务布局：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986513292525591&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

③ 

点击【选择布局】按钮，弹出弹窗，弹窗显示并支持选择PC端、移动端的督办立项、督办变更、督办分解三个表单的布局

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986508942098486&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1)

布局数据根据pc端和移动端进行过滤，如：pc端督办变更点击布局浏览按钮后，显示的布局数据只有pc端督办变更表单

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986508938838025&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

④ 

若是在默认设置中进行选择布局操作，则选择布局后，新建的督办类型则复制的是当前最新默认设置的pc端和移动端立项、变更、分解布局

⑤ 

点击【同步】按钮，弹出弹窗，支持对各个督办类型的pc端和移动端布局进行统一的修改

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986513365925899&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1)

点击布局浏览框弹出对应表单下的布局数据，可进行选择。

2)

选择布局后，勾选督办类型，可将当前所选布局赋予对应督办类型，把所选类型当前使用布局直接指向这个布局id，不覆盖原有布局。

 

 

## 3、具体督办类型

① 

基础设置中新建督办类型后，卡片设置里会同步增加该督办类型布局，点击指定督办类型，如”重要会议“，卡片上显示当前使用的布局名称。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986509129678862&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

② 

点击对应卡片布局，打开表单设计器，可自定义配置布局，如点击pc端督办任务布局：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986517671378998&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

③ 

点击【选择布局】按钮，弹出弹窗，弹窗显示并支持选择PC端、移动端的督办立项、督办变更、督办分解三个表单的布局

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986509129678878&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1)

选择对应布局后，该督办类型下的督办任务在进行督办立项、督办变更、督办分解操作时将会使用所选择的布局，其中，查看督办任务详情时的布局对应的是督办类型的立项布局。

2)

布局数据根据pc端和移动端进行过滤，如：pc端督办变更点击布局浏览按钮后，显示的布局数据只有pc端督办变更表单

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986517624307728&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

# 四、使用注意点

 此功能需要初始化应用：云商店安装此应用后会自动初始化应用，或者手动导入该应用后手动执行接口初始化应用：  
[/api/bs/ebuilder/form/govern/initField?apid=xxx&mode=govern（](http://192.0.2.10/api/bs/ebuilder/form/govern/initField?apid=730439843898146816&mode=govern)[xxx](http://192.0.2.10/api/bs/ebuilder/form/govern/deleteField?apid=726748177787092993&mode=govern)代表督查督办应用的apid值，需要手动替换成正在使用的应用apid值，示例如下：

① 

应用包导入成功之后，进入应用的后台管理界面，可查看地址栏的域名信息和apid信息，如下图红框的位置：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986504717271076&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

② 

重新打开一个窗口，复制[/api/bs/ebuilder/form/govern/initField?apid=xxx&mode=govern](http://192.0.2.10/api/bs/ebuilder/form/govern/initField?apid=730439843898146816&mode=govern)，把域名信息拼接在/api之前，api信息替换到xxx位置，如下图，完成上述两个位置的替换之后，鼠标放置地址栏内手动回车，出现接口返回信息内包含接口反馈成功代表执行成功。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986508938838082&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 五、上下游关联功能点

① 

用户自定义配置完对应督办类型的pc端以及移动端的新建、变更、分解布局后，用户进行立项、变更、分解时分别显示对应的布局，如督办类型”重要会议“为例：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986513365925907&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1)

pc端立项、任务详情显示布局：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986513365925889&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986517624307775&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986513186734084&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2)

pc端分解：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986513197326348&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3)

pc端变更：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1166986517624307761&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
