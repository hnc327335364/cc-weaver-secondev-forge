---
table_name: ebdf_escene_func
cn_name: 场景功能关联表
module: e-Builder应用建模
database: ebuilder_escene
type: 普通表
owner: 程东勇
creator: 熊雪兵
public_config: 0
data_id: 100655700000007595
has_fields: true
tags: [E10, 数据字典]
---

# ebdf_escene_func

> 场景功能关联表

> [!info] 基本信息
> - 数据库表名：`ebdf_escene_func`
> - 中文名称：场景功能关联表
> - 所属模块：e-Builder应用建模
> - 所属数据库：`ebuilder_escene`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：熊雪兵
> - 是否公共配置：0
> - 描述：场景功能关联表
> - 数据ID：`100655700000007595`
> - 最后更新：2023-08-30 10:03:34

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | escene_id | 场景ID | 长整型 |  |  |  |  |  |  |  | 场景ID |
| 2 | function_id | 功能ID | 长整型 |  |  |  |  |  |  |  | 功能ID |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/ebuilder_escene]]
