# 项目汇总

来源快照：`result_data_new_260518.json`

- 来源 ID：`1203980969176531138`
- 模块：项目管理
- 目录：科研项目管理 - 前台使用 - 项目管理
- space ID：`1973261491939008706`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# **一、** 功能背景和价值

通过项目看板，集中展现本人负责的、团队负责的、组织负责的和项目集项目信息，帮助快速了解项目进展。

# **二、业务流程图**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1203985234172403716&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# **三、功能介绍**

## 1\. 项目汇总

默认展现所有本人负责的项目，左侧树可进行团队/组织筛选，筛选后，显示筛选人员负责的项目；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1203985728210255874&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2\. 团队筛选

显示本人下属人员，包括直接下属和间接下属；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1203993351729242113&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 3\. 组织筛选

显示本人负责的组织以及下级组织，即组织负责人能够查看当前组织以及下级组织人员负责的项目，其中组织维度和组织负责人可在基础设置-组织设置-组织负责人中入口进行配置。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1203993927202988034&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 4\. 统计项

项目总数：项目总数

未开始：系统状态为“未开始”的项目数量

进行中：系统状态为“进行中”且 （“计划完成时间”大于等于当前时间或“计划完成时间”为空）的项目数量

已延期 ：系统状态为“进行中”且 “计划完成时间”小于当前时间）或 （系统状态为“未开始” 且 “计划开始时间”小于当前日期）

已暂停： 系统状态为“已暂停”的项目数量

已完成：系统状态为“已完成”的项目数量

特殊说明：如果立项流程未完成得审批，我们统一认为还不是一个正式的项目，不会在项目列表和项目统计中展示。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1203994124827549703&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 5\. 项目列表

展示科研项目数据列表，可以进行搜索，按照搜索条件显示对应相应数据。

点击列表上方的项目申报，可以发起流程，对纵向科研项目进行立项。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1203994494056325121&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
