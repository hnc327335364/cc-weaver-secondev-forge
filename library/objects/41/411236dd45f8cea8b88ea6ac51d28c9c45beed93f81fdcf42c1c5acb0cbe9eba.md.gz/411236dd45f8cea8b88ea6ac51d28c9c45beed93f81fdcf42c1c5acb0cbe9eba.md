---
table_name: pr_reportcard_doc_1
cn_name: 成绩单-创建文档数量
module: 组织画像
database: portrait
type: 同步表
owner: 何前锋
creator: 张博文
public_config: 0
data_id: 904972188084961285
has_fields: true
tags: [E10, 数据字典]
---

# pr_reportcard_doc_1

> 成绩单-创建文档数量

> [!info] 基本信息
> - 数据库表名：`pr_reportcard_doc_1`
> - 中文名称：成绩单-创建文档数量
> - 所属模块：组织画像
> - 所属数据库：`portrait`
> - 表类型：同步表
> - 负责人：何前锋
> - 创建者：张博文
> - 是否公共配置：0
> - 描述：成绩单-创建文档数量
> - 数据ID：`904972188084961285`
> - 最后更新：2023-09-05 17:14:17

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  | CURRENT_TIMESTAMP |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  | CURRENT_TIMESTAMP |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  | -1 |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | userid | 人员id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | item_id | 指标id | 长整型 |  |  |  |  |  |  |  |  |
| 9 | item_date | 统计周期 | 字符 | 20 |  |  |  |  |  |  |  |
| 10 | amount | 实际值 | 整型 |  |  |  |  |  |  |  |  |
| 11 | main_id | 成绩单id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/组织画像]]
- 数据库索引：[[数据库索引/portrait]]
