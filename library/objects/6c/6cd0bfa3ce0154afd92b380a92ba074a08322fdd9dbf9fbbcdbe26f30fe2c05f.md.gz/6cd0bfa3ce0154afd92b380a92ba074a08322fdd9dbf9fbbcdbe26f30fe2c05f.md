---
title: "4.2.1.3、表单回收站：FormTrashService"
docId: "208461097080979456"
source: "https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/repository/9c2e5f92-03b4-4207-9b22-a0c1dd79ac56/doc/208461097080979456"
---
> 所属包：weaver-common-form-extend
> 
> 所属类：com.weaver.common.form.metadata.formtrash.FormTrashService

### 一 表单还原

1、复写FormTrashService，将原有业务还原逻辑放入复写接口

```java

@Service("formdatareport_FormTrashService")
public class ReportFormTrashServiceImpl extends FormTrashServiceImpl implements FormTrashService {

    @Override
    public List<FormTrash> batchRestoreForms(FormTrashParam formTrashParam, SimpleEmployee employee) {
        List<Long> formIds = formTrashParam.getTrashSearchEntity().getFormIds();
        List<FormTrash> formTrashes = super.batchRestoreForms(formTrashParam, employee);
        List<Long> formTrashesFormIds = formTrashes.stream().map(FormTrash::getForm).map(Form::getId).collect(Collectors.toList());
        //移除已经还原的表单ID
        formIds.removeAll(formTrashesFormIds);
        //执行业务自己的逻辑，例如：
        //1、根据formId删除业务的数据
        //2、记录删除日志
        //。。。。
    }
}

```

2、原有还原代码调用复写接口

```java
//引入依赖
@Resource(name = "formdatareport_FormTrashService")
private FormTrashService formTrashService;
。。。
。。。
//原业务逻辑
public void recover(List<Long> formIds, SimpleEmployee employee) {
	if (CollectionUtils.isEmpty(formIds)) {
		return;
	}
    //通过formIds删除表单
	FormTrashParam formTrashParam = new FormTrashParam();
	formTrashParam.getTrashSearchEntity().setFormIds(formIds);
	formTrashService.batchRestoreForms(formTrashParam, employee);
}

```

### 二 表单彻底删除

1、与还原逻辑相同

```java
@Override
public List<FormTrash> batchCompletelyDeleteForms(FormTrashParam formTrashParam, SimpleEmployee employee) {
    //先掉用super方法
    List<FormTrash> formTrashes = super.batchCompletelyDeleteForms(formTrashParam, employee);
    List<Long> ids = formTrashParam.getTrashSearchEntity().getFormIds();
    List<Long> formTrashesFormIds = formTrashes.stream().map(FormTrash::getForm).map(Form::getId).collect(Collectors.toList());
    //移除已经还原的表单ID
    ids.removeAll(formTrashesFormIds);
        //执行业务自己的逻辑，例如：
        //1、根据formId删除业务的数据
        //2、记录删除日志
        //。。。。

       //业务自己回收站记录的formIds彻底删除
       formService.batchCompletelyDeleteForms(formIds, employee);
 }
```

2、原有彻底删除逻辑调用复写接口

```java
public void thorougDestroy(List<Long> formIds, SimpleEmployee employee) {
    if (CollectionUtils.isEmpty(formIds)) {
       return;
    }
    FormTrashParam formTrashParam = new FormTrashParam();
    formTrashParam.getTrashSearchEntity().setFormIds(formIds);
    formTrashService.batchCompletelyDeleteForms(formTrashParam, employee);
}
```

3、业务回收站表单直接彻底删除

```java
//表单彻底删除
formService.batchCompletelyDeleteForms(formIds, employee);
```

### 三 表单回收站插入数据

```java
@Override
public void batchAddForms(List<Long> formIds, SimpleEmployee employee) {
    super.batchAddForms(formIds, employee);
    //业务自己逻辑（有需求就复写）。。。。
}
```

### 四 分页查询表单回收站数据

```java
/**
 * 获取回收站表单列表，不支持国际化（有需要后面加）
 *
 * @param formTrashParam formTrashParam
 * @param employee       employee
 */
Page<FormTrash> pageForms(FormTrashParam formTrashParam, SimpleEmployee employee);
```

2、参数

```java
{
    "type": "form",
    "pageNo": 1,
    "pageSize": 100,
    "trashSearchEntity": {
        "formId": "930582300758925313"
    }
}
```

| 参数名 | 必选 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| module | 是 | string |  | module |
| pageNo | 是 | int | 1 |  |
| pageSize | 是 | int | 10 |  |
| trashSearchEntity | 否 | obj |  | 条件搜索对象 <br>表单IDs：formIds<br>表单名称：formName <br>表单类型：physicalTable <br>字段名称：fieldName <br>字段类型：fieldTypes <br>所属表：sourceForms <br>布局名称：layoutName <br>布局类型：layoutType <br>终端：terminalType <br>创建人list：creaters <br>创建时间：createStartTime\createEndTime<br>删除人list：deleters <br>删除时间：deleteStartTime\deleteEndTime |
