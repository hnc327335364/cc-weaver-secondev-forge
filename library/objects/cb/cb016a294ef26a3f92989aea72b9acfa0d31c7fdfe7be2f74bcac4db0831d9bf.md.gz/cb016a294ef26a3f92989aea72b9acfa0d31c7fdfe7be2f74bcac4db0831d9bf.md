---
table_name: ebda_app
cn_name: 应用基本信息
module: e-Builder页面引擎
database: ebuilder_app
type: 普通表
owner: 常程
creator: 熊雪兵
public_config: 0
data_id: 100655700000000058
has_fields: true
tags: [E10, 数据字典]
---

# ebda_app

> 应用基本信息

> [!info] 基本信息
> - 数据库表名：`ebda_app`
> - 中文名称：应用基本信息
> - 所属模块：e-Builder页面引擎
> - 所属数据库：`ebuilder_app`
> - 表类型：普通表
> - 负责人：常程
> - 创建者：熊雪兵
> - 是否公共配置：0
> - 描述：ebuilder应用基本信息表
> - 数据ID：`100655700000000058`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | short_name | 应用简称 | 字符 | 1000 |  |  |  |  |  |  |  |
| 2 | description | 应用描述 | 字符 | 1000 |  |  |  |  |  |  |  |
| 3 | folder | 应用所属文件夹 | 长整型 |  |  |  |  |  |  |  |  |
| 4 | icon_path | 应用图标路径 | 字符 | 400 |  |  |  |  |  |  |  |
| 5 | cover_type | 应用封面类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 6 | cover_path | 应用封面路径 | 字符 | 400 |  |  |  |  |  |  |  |
| 7 | scope | 应用适用终端类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 8 | publish_eteams | 是否发布eteams | 小整数 |  |  |  |  | 0 |  |  |  |
| 9 | publish_ebridge | 是否发布云桥 | 小整数 |  |  |  |  | 0 |  |  |  |
| 10 | ebridge_name | 云桥发布应用名称 | 字符 | 1000 |  |  |  |  |  |  |  |
| 11 | ebridge_mobile_url | 云桥发布移动端链接 | 字符 | 1000 |  |  |  |  |  |  |  |
| 12 | ebridge_pc_url | 云桥发布pc链接 | 字符 | 1000 |  |  |  |  |  |  |  |
| 13 | ebridge_agentid | 云桥发布应用id | 字符 | 50 |  |  |  |  |  |  |  |
| 14 | publish_enabled | 应用发布启用状态 | 小整数 |  |  |  |  | 0 |  |  | 应用发布启用状态 |
| 15 | org_id | 所属机构id | 长整型 |  |  |  |  |  |  |  |  |
| 16 | app_from | 应用来源 | 固定长度 | 50 |  |  |  |  |  |  |  |
| 17 | app_key | 应用标识 | 固定长度 | 50 |  |  |  |  |  |  |  |
| 18 | watermark | 水印 | 大字段3 |  |  |  |  |  |  |  |  |
| 19 | teamwork_status | 团队工作状态 | 整型 |  |  |  |  | 0 |  |  | 发布团队工作状态 |
| 20 | doc_dir_id | 文档目录id | 长整型 |  |  |  |  |  |  |  |  |
| 21 | sync_code | 系统应用版本标识 | 字符 | 255 |  |  |  |  |  |  | 系统应用版本标识 |
| 22 | tag | 应用标签 | 字符 | 200 |  |  |  |  |  |  |  |
| 23 | ecode_id | ecode应用id | 长整型 |  |  |  |  |  |  |  |  |
| 24 | app_type | 应用类型 | 整型 |  |  |  |  | 1 |  |  | 应用类型 |
| 25 | read_only | 是否只读应用 | 整型 |  |  |  |  | 0 |  |  | 1：只读 |
| 26 | upload_cloud | 是否上传云商店 | 整型 |  |  |  |  | 0 |  |  |  |
| 27 | ecode_version | ecode版本 | 整型 |  |  |  |  | 2 |  |  |  |
| 28 | developer | 开发者信息 | 字符 | 500 |  |  |  |  |  |  |  |
| 29 | manage_detach | 应用管理分权 | 小整数 |  |  |  |  | 0 |  |  | 应用管理分权 |
| 30 | theme_id | 主题 | 长整型 |  |  |  |  |  |  |  |  |
| 31 | simple_mode | 精简模式 | 小整数 |  |  |  |  | 0 |  |  | 精简模式 |
| 32 | paid | 是否付费 | 小整数 |  |  |  |  | 0 |  |  | 是否付费 |
| 33 | enable_watermark | 启用水印 | 整型 |  |  |  |  | 0 |  |  | 启用水印 |
| 34 | parent_id | 父应用id | 长整型 |  |  |  |  |  |  |  | 父应用id |
| 35 | remark | 备注 | 字符 | 1000 |  |  |  |  |  |  | 备注 |
| 36 | related_time | 关联时间 | 日期时间 |  |  |  |  |  |  |  | 关联时间 |
| 37 | child_id | 子应用id | 大字段3 |  |  |  |  |  |  |  | 子应用id |
| 38 | remark_label_id | 备注多语言id | 长整型 |  |  |  |  |  |  |  |  |
| 39 | org_dimension | 组织维度 | 长整型 |  |  |  |  |  |  |  | 组织维度 |
| 40 | org_dimension_switch | 组织维度开关 | 整型 |  |  |  |  |  |  |  | 组织维度开关 |
| 41 | ecode_cache_version | ecode应用版本号 | 字符 | 50 |  |  |  |  |  |  | ecode应用版本号 |
| 42 | field_permission | 字段权限 | 整型 |  |  |  |  |  |  |  | 字段权限 |
| 43 | field_permission_switch | 字段权限开关 | 整型 |  |  |  |  |  |  |  | 字段权限开关 |
| 44 | special_app_tag | 专项应用标签 | 字符 | 200 |  |  |  |  |  |  | 专项应用标签 |
| 45 | enable_action_flow_result_tip | 启用动作流执行后默认提示 | 小整数 |  |  |  |  | 1 |  |  | 启用动作流执行后默认提示 |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder页面引擎]]
- 数据库索引：[[数据库索引/ebuilder_app]]
