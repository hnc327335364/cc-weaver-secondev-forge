# 绩效分布规则

来源快照：`result_data_new_260518.json`

- 来源 ID：`1174451471298084896`
- 模块：绩效考核
- 目录：绩效管理员-基础配置
- space ID：`1159419923312574474`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景与价值

绩效等级体系是将企业战略目标分解到部门和员工的关键手段。通过设定清晰的绩效标准和等级划分，组织能够确保员工的工作行为与整体战略方向保持一致

在同部门、跨部门、跨团队的评价中，不同管理者的评分标准可能存在差异。通过统一的分布规则，有助于在组织层面实现绩效结果的横向可比性，便于人才盘点和资源分配

 

[点击查看绩效考核方案整体介绍](https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1174448160079626291&space_id=1159419923312574474 "点击查看绩效考核方案整体介绍")

# 二、功能概述

1、支持按照分数设置绩效等级

2、支持按照分数排名设置绩效等级

3、支持按人数分布设置绩效分布规则

4、支持按比例分布设置绩效分布规则

# 三、业务流程图

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451548758884359&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 四、功能使用说明

## 1、功能入口

【绩效考核】-【绩效等级】，需要有后台管理中心-低代码平台e-builder-绩效等级表单的“查看权限”，如图所示：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451557217427457&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

点击绩效考核应用，进入绩效等级菜单，进入后展示绩效等级相关功能。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451548728655878&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

## 2、新建考核方案

点击新建按钮，新建绩效等级

**规则名称** ：根据用户需求自定义

**等级评定类型：** 选择按分数评定或者按分数排名评定

**按分数评定-详细信息：** 输入不同的分数对应的分数等级，如4-5分，算A绩效等级，3-4分，算B绩效等级........

**排名顺序：** 数值越高，代表该等级越优秀

 ![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451553140563975&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

按分数排名评定-详细信息：按照最终分数的排名进行评级，如最终分数的前10%，算A绩效等级，再25%算绩效等级B，再25%的人员算绩效等级C，剩余40的人员算绩效等级D

排名顺序：数值越高，代表该等级越优秀

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451553028685838&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

## 3、新建绩效分布规则

点击新建按钮，新建绩效分布规则，

**规则名称：** 根据用户需求自定义

**适用范围-绩效活动：** 创建绩效活动时，直接可以选择到此绩效分布规则进行使用

**适用范围-自定义：** 配置需要特殊规则的人员，启用后自动匹配，匹配到多个规则按最新规则生效

**分布规则-按比例分布：** 限制对应绩效等级的比例，如A绩效只可有总数的10%

**分布规则-按人数分布** ：限制对应绩效等级的人数，如A绩效只可以有2个人

**等级分布说明：** 根据用户需求自定义

**提醒方式：** 阻止/警告/不处理

**绩效等级：** 选择本次新建的绩效分布规则，约束那个绩效等级

**分布规则详情：** 根据人数配置详情，或者根据比例配置分布规则详情

按照人数，规定A绩效不超过5人

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451548652126219&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

按照比例，规定A绩效不超过20%

![](https://weapp.eteams.cn/papi/file/preview?fileId=1174451557189435394&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 五、使用注意点

# 六、上下游关联功能点

绩效活动关联功能点，[点击查看详情](https://weapp.eteams.cn/sp/ebdpage/view/freepass/1152863419640021002?id=1174454623999705109&space_id=1159419923312574474 "点击查看详情")
