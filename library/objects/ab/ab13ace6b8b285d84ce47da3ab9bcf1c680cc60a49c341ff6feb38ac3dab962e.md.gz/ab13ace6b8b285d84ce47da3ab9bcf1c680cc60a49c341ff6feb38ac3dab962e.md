---
table_name: ebde_escene
cn_name: 智能场景
module: e-Builder应用建模
database: ebuilder_escene
type: 普通表
owner: 程东勇
creator: 系统管理员
public_config: 0
data_id: 100655700000005001
has_fields: true
tags: [E10, 数据字典]
---

# ebde_escene

> 智能场景

> [!info] 基本信息
> - 数据库表名：`ebde_escene`
> - 中文名称：智能场景
> - 所属模块：e-Builder应用建模
> - 所属数据库：`ebuilder_escene`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：智能场景
> - 数据ID：`100655700000005001`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | escene_name | 场景名称 | 字符 | 100 |  |  |  |  |  |  | 场景名称 |
| 8 | escene_classify_id | 场景分类id | 长整型 |  |  |  |  |  |  |  | 场景分类id |
| 9 | function_name | 功能标识 | 字符 | 100 |  |  |  |  |  |  | 功能标识 |
| 10 | func_finish_answer | 功能完成时的回答 | 大字段1 |  |  |  |  |  |  |  | 功能完成时的回答 |
| 11 | func_cancel_answer | 功能取消时的回答 | 大字段1 |  |  |  |  |  |  |  | 功能取消时的回答 |
| 12 | need_confirm | 是否需要确认 | 小整数 |  |  |  |  |  |  |  | 是否需要确认 |
| 13 | func_action_mobile | 功能最终执行动作(移动端) | 大字段2 |  |  |  |  |  |  |  | 功能最终执行动作(移动端) |
| 14 | func_action_pc | 功能最终执行动作(PC) | 大字段2 |  |  |  |  |  |  |  | 功能最终执行动作(PC) |
| 15 | enable_form | 是否启用功能表单 | 小整数 |  |  |  |  |  |  |  | 是否启用功能表单 |
| 16 | show_order | 顺序 | 整型 |  |  |  |  |  |  |  | 顺序 |
| 17 | src_scene_id | 源场景id | 长整型 |  |  |  |  |  |  |  | 源场景id |
| 18 | src_intention_id | 源意图id | 长整型 |  |  |  |  |  |  |  | 源意图id |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/ebuilder_escene]]
