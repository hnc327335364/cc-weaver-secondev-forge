---
table_name: hrsa_secusetsecauthlogs
cn_name: 安全设置-二次身份认证表日志表
module: 薪酬管理
database: hrm_salary
type: 普通表
owner: 蔡志军
creator: 王祥忠
public_config: 0
data_id: 1120458844710797368
has_fields: true
tags: [E10, 数据字典]
---

# hrsa_secusetsecauthlogs

> 安全设置-二次身份认证表日志表

> [!info] 基本信息
> - 数据库表名：`hrsa_secusetsecauthlogs`
> - 中文名称：安全设置-二次身份认证表日志表
> - 所属模块：薪酬管理
> - 所属数据库：`hrm_salary`
> - 表类型：普通表
> - 负责人：蔡志军
> - 创建者：王祥忠
> - 是否公共配置：0
> - 描述：安全设置-二次身份认证表
> - 数据ID：`1120458844710797368`
> - 最后更新：2025-04-08 09:52:34

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | 日志UUID | 字符 | 36 |  |  |  |  |  |  |  |
| 8 | log_date | 记录时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 9 | device | 终端信息 | 字符 | 500 |  |  |  |  |  |  |  |
| 10 | log_operator | 操作者 | 长整型 |  |  |  |  |  |  |  |  |
| 11 | operatorname | 操作人姓名 | 字符 | 100 |  |  |  |  |  |  |  |
| 12 | targetid | 操作目标id | 长整型 |  |  |  |  | -1 |  |  |  |
| 13 | targetname | 操作目标名称 | 大字段1 |  |  |  |  |  |  |  |  |
| 14 | modulename | 模块 | 字符 | 100 |  |  |  |  |  |  |  |
| 15 | functionname | 服务（方法） | 字符 | 100 |  |  |  |  |  |  |  |
| 16 | interfacename | 访问接口名 | 字符 | 100 |  |  |  |  |  |  |  |
| 17 | requesturl | 请求全路径 | 字符 | 200 |  |  |  |  |  |  |  |
| 18 | requesturi | 请求地址 | 字符 | 200 |  |  |  |  |  |  |  |
| 19 | operatetype | 操作类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 20 | operatetypename | 操作类型名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 21 | operatedesc | 操作详细说明 | 字符 | 3000 |  |  |  |  |  |  |  |
| 22 | params | 涉及的相关参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 23 | belongmainid | 所属主表uuid | 字符 | 36 |  |  |  |  |  |  |  |
| 24 | clientip | 操作IP | 字符 | 50 |  |  |  |  |  |  |  |
| 25 | groupid | 分组 | 字符 | 50 |  |  |  |  |  |  |  |
| 26 | groupnamelabel | 分组标题 | 字符 | 1000 |  |  |  |  |  |  |  |
| 27 | redoservice | 重做业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 28 | redocontext | 重做参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 29 | cancelservice | 撤销业务接口 | 字符 | 200 |  |  |  |  |  |  |  |
| 30 | cancelcontext | 撤销参数 | 大字段1 |  |  |  |  |  |  |  |  |
| 31 | totalruntime | 总运行时长 | 长整型 |  |  |  |  | 0 |  |  |  |
| 32 | mainruntime | 主方法运行时长 | 长整型 |  |  |  |  | 0 |  |  |  |
| 33 | log_result | 日志结果 | 字符 | 100 |  |  |  |  |  |  |  |
| 34 | fromterminal | 来自pc web | 字符 | 100 |  |  |  |  |  |  |  |
| 35 | resultdesc | 运行结果描述 | 大字段1 |  |  |  |  |  |  |  |  |
| 36 | old_content | 原先内容 | 字符 | 3000 |  |  |  |  |  |  |  |
| 37 | link_type | 链接类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 38 | link_id | 链接id | 长整型 |  |  |  |  | 0 |  |  |  |
| 39 | old_link_id | 原先链接id | 长整型 |  |  |  |  | 0 |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/薪酬管理]]
- 数据库索引：[[数据库索引/hrm_salary]]
