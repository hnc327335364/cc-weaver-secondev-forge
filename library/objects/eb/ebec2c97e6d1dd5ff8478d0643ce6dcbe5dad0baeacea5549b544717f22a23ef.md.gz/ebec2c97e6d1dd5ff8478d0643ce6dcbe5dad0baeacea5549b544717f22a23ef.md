---
table_name: crm_warning_rule
cn_name: crm_warning_rule
module: 营销管理
database: crm
type: 普通表
owner: 曹刘远
creator: 系统管理员
public_config: 0
data_id: 100655700000000535
has_fields: true
tags: [E10, 数据字典]
---

# crm_warning_rule

> crm_warning_rule

> [!info] 基本信息
> - 数据库表名：`crm_warning_rule`
> - 中文名称：crm_warning_rule
> - 所属模块：营销管理
> - 所属数据库：`crm`
> - 表类型：普通表
> - 负责人：曹刘远
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：crm_warning_rule
> - 数据ID：`100655700000000535`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | field_type | FIELD_TYPE | 字符 | 20 |  |  |  |  |  |  |  |
| 2 | value_type | VALUE_TYPE | 字符 | 20 |  |  |  |  |  |  |  |
| 3 | deleted | DELETED | 字符 | 10 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/营销管理]]
- 数据库索引：[[数据库索引/crm]]
