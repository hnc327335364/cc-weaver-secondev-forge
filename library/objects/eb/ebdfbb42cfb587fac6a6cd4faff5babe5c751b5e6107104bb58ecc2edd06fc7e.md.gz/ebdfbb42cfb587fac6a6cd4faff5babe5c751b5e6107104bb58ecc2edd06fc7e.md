---
table_name: ebuilder_packing_datamap
cn_name: 迁入迁出导入数据
module: 迁出迁入
database: ebuilder-packing
type: 普通表
owner: 汤海军
creator: 系统管理员
public_config: 0
data_id: 100655700000007450
has_fields: true
tags: [E10, 数据字典]
---

# ebuilder_packing_datamap

> 迁入迁出导入数据

> [!info] 基本信息
> - 数据库表名：`ebuilder_packing_datamap`
> - 中文名称：迁入迁出导入数据
> - 所属模块：迁出迁入
> - 所属数据库：`ebuilder-packing`
> - 表类型：普通表
> - 负责人：汤海军
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：迁入迁出导入数据
> - 数据ID：`100655700000007450`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | module_name | 模块 | 字符 | 50 |  |  |  |  |  |  |  |
| 2 | export_id | 导出id | 长整型 |  |  |  |  |  |  |  |  |
| 3 | data_type | 数据类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 4 | json_data | 数据 | 大字段3 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/迁出迁入]]
- 数据库索引：[[数据库索引/ebuilder-packing]]
