# 消息转待办-H5

## 组件效果
![](https://im.weaver.com.cn/server/index.php?s=/api/attachment/visitFile&sign=7d48a2e572f7e065609adfd626766753)

## 消息转待办 

```js
{host}/mobile/my/wait/msg/{msgIds}/{title}
```

### 参数说明

| 参数名 | 类型   | 是否必传 | 说明                                                      |
|:-------|:-------|:---------|-----------------------------------------------------------|
| msgIds | string | 是       | 消息id，多个消息使用 , 符号隔开                           |
| title  | string | 否       | 待办标题，不传，将默认使用第一条消息数据中的 content 字段 |


### 示例
https://weapp.yunteams.cn/mobile/my/wait/msg/1646807252260100078/demo

### 关闭自动回复

通过URL传参【disabledAutoReply】可关闭自动回复功能，例如： https://weapp.yunteams.cn/mobile/my/wait/msg/1646807252260100078/demo?disabledAutoReply=true
