---
table_name: cmmk_live_code_wx_customer
cn_name: 添加的人员信息
module: 
database: crm_market
type: 
owner: 
creator: 系统管理员
public_config: 0
data_id: 100655700000000675
has_fields: true
tags: [E10, 数据字典]
---

# cmmk_live_code_wx_customer

> 添加的人员信息

> [!info] 基本信息
> - 数据库表名：`cmmk_live_code_wx_customer`
> - 中文名称：添加的人员信息
> - 所属模块：—
> - 所属数据库：`crm_market`
> - 表类型：—
> - 负责人：—
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000000675`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | external_userid | 企业微信返回的添加的客户ID信息 | 字符 | 200 |  |  |  |  |  |  |  |
| 2 | service_employee_id | 服务人员 | 长整型 |  |  |  |  | 0 |  |  |  |
| 3 | introduce_employee_id | 引流人员  目前只针对公司员工 如果不是就为空 | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/crm_market]]
