---
table_name: esb_cs_order_action
cn_name: 客服模块esb工单状态
module: 客服管理
database: esb_setting
type: 
owner: 温明刚
creator: 系统管理员
public_config: 0
data_id: 100655700000004355
has_fields: true
tags: [E10, 数据字典]
---

# esb_cs_order_action

> 客服模块esb工单状态

> [!info] 基本信息
> - 数据库表名：`esb_cs_order_action`
> - 中文名称：客服模块esb工单状态
> - 所属模块：客服管理
> - 所属数据库：`esb_setting`
> - 表类型：—
> - 负责人：温明刚
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：客服模块提供给EB存储条件规则的表
> - 数据ID：`100655700000004355`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | work_order_id | 工单ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | work_order_status | 工单状态 | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/客服管理]]
- 数据库索引：[[数据库索引/esb_setting]]
