原始文档链接：[获取空闲会议室列表](https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/repository/9c0c2d7b-adce-4d9a-bf09-d42be37fcf8d/doc/954703846292062208)

# 获取空闲会议室列表

接口请求路径：/sapi/meeting/meetingOpenApi/getFreeRoomEvents

mthod：POST

入参：

| **参数名** | **必选** | **类型** | **说明** |
| --- | --- | --- | --- |
| access_token | 是 | String | 调用接口凭证 |
| userid | 是 | Long | 用户ID |
| id | 否 | String | 会议室ID（多个地点以”,”分隔） |
| start | 是 | String | 开始时间，格式为（yy-MM-dd HH:mm:ss） |
| end | 是 | String | 结束时间，格式为（yy-MM-dd HH:mm:ss） |
| size | 是 | int | 推荐的数据个数 |

出参：

| code | 0：正常返回，其余为异常返回 |
| --- | --- |
| status | 状态：true：正常返回，其余异常返回 |
| msg | 返回说明 |
| data | 数据集合 |
