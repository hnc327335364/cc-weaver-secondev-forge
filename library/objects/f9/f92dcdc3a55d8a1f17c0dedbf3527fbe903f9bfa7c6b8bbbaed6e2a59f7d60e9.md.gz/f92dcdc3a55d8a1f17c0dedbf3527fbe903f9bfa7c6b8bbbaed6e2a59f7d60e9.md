---
title: "单个新建索引个数限制"
docId: "302234032085663744"
source: "https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/repository/9c2e5f92-03b4-4207-9b22-a0c1dd79ac56/doc/302234032085663744"
---
```properties
#默认为20，建议不要超过30，索引过多也会影响整表的更新性能
form.data.physical.maxIndexNumer=30
```
