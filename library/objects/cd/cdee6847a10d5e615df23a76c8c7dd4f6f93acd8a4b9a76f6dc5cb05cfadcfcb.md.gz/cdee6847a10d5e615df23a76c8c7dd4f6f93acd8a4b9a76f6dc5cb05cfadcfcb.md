---
table_name: sign_dstemplate
cn_name: docusign合同模板表
module: 电子签
database: signcenter
type: 普通表
owner: 吴奇
creator: 胡斌
public_config: 0
data_id: 900521644223152132
has_fields: true
tags: [E10, 数据字典]
---

# sign_dstemplate

> docusign合同模板表

> [!info] 基本信息
> - 数据库表名：`sign_dstemplate`
> - 中文名称：docusign合同模板表
> - 所属模块：电子签
> - 所属数据库：`signcenter`
> - 表类型：普通表
> - 负责人：吴奇
> - 创建者：胡斌
> - 是否公共配置：0
> - 描述：docusign模版表
> - 数据ID：`900521644223152132`
> - 最后更新：2023-08-24 17:23:54

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | template_id | 模版id | 字符 | 100 |  |  |  |  |  |  |  |
| 8 | title | 模版名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 9 | is_ds_delete | docusign是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 10 | server_id | 绑定服务 | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/电子签]]
- 数据库索引：[[数据库索引/signcenter]]
