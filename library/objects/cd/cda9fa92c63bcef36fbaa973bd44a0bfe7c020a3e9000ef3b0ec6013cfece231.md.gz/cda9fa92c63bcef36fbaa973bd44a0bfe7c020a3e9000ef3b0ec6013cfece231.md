---
table_name: data_rule_linkage
cn_name: 
module: 
database: eteams
type: 
owner: 
creator: 系统管理员
public_config: 0
data_id: 100655700000001067
has_fields: true
tags: [E10, 数据字典]
---

# data_rule_linkage

> [!info] 基本信息
> - 数据库表名：`data_rule_linkage`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`eteams`
> - 表类型：—
> - 负责人：—
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000001067`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | primerule_id | 主规则ID | 小数 |  |  |  |  |  |  |  |  |
| 2 | childrule_id | 子规则ID | 小数 |  |  |  |  |  |  |  |  |
| 3 | linkage_type | 联动类型 | 字符 | 100 |  |  |  |  |  |  |  |
| 4 | create_time |  | 日期时间 |  |  |  |  |  |  |  |  |
| 5 | status | 数据状态 | 字符 | 20 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/eteams]]
