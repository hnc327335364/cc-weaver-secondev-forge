---
table_name: odoc_official_type_ext
cn_name: 公文类型补充表
module: 公文管理
database: weaver_odoc
type: 
owner: 岁军攀
creator: 系统管理员
public_config: 0
data_id: 100655700000003271
has_fields: true
tags: [E10, 数据字典]
---

# odoc_official_type_ext

> 公文类型补充表

> [!info] 基本信息
> - 数据库表名：`odoc_official_type_ext`
> - 中文名称：公文类型补充表
> - 所属模块：公文管理
> - 所属数据库：`weaver_odoc`
> - 表类型：—
> - 负责人：岁军攀
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：公文类型补充表
> - 数据ID：`100655700000003271`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | pattern_name | 名称 | 字符 | 200 |  |  |  |  |  |  |  |
| 2 | pattern_desc | 描述 | 字符 | 200 |  |  |  |  |  |  |  |
| 3 | order_num | 序号 | 小数 | 2 |  |  |  |  |  |  |  |
| 4 | official_type_id | 公文类型Id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/公文管理]]
- 数据库索引：[[数据库索引/weaver_odoc]]
