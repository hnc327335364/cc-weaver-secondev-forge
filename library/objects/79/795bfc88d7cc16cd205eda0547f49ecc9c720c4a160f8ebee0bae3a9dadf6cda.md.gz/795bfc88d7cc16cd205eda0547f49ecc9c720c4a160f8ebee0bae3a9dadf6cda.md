---
table_name: t_analyze_dm_ap_dp
cn_name: 行业案例
module: 数据分析BI
database: weaver_analyze
type: 普通表
owner: 何伟
creator: 李浩（上海）
public_config: 0
data_id: 1043767178545659912
has_fields: true
tags: [E10, 数据字典]
---

# t_analyze_dm_ap_dp

> 行业案例

> [!info] 基本信息
> - 数据库表名：`t_analyze_dm_ap_dp`
> - 中文名称：行业案例
> - 所属模块：数据分析BI
> - 所属数据库：`weaver_analyze`
> - 表类型：普通表
> - 负责人：何伟
> - 创建者：李浩（上海）
> - 是否公共配置：0
> - 描述：行业案例
> - 数据ID：`1043767178545659912`
> - 最后更新：2024-09-13 17:49:44

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | bmmc |  | 字符 | 100 |  |  |  |  |  |  |  |
| 8 | form_data_id |  | 长整型 | 20 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/数据分析BI]]
- 数据库索引：[[数据库索引/weaver_analyze]]
