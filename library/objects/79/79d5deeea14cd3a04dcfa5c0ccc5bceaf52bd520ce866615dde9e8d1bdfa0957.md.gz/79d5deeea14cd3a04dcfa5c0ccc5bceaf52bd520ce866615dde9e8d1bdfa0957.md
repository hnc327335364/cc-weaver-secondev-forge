**简要描述：** 

- 批量更新是否支持关联关系

**请求URL：** 
- pc : `{host}/api/my/tag/queryChildTagId`
- app :`{host}/api/app/my/tag/queryChildTagId`
  
**请求方式：**
- POST   http payload

**参数：** 
``` 
{"tagId":"1091981235911163905","module":"task"}
```
|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
 |tagId|是|Long|标签id|
 |module|否|string|模块id(如果传入模块 那么只会过滤出当前模块关联了事项的标签id)|



 **返回示例**

``` 
{
    "code": 200,
    "msg": "接口返回成功",
    "status": true,
    "data": {
        "tagIds": [
            "1091981235911163905",
            "1092266623556001793"
        ]
    },
    "fail": false
}
```

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|tagIds |long[]   |标签id（包含自己）  |




 **备注** 

- 更多返回错误代码请看首页的错误代码描述
