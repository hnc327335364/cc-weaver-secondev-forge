---
table_name: cs_app_download_info
cn_name: 应用下载信息表
module: 云商店
database: cloudstore
type: 普通表
owner: 汤海军
creator: 徐德力
public_config: 0
data_id: 1072339044832878626
has_fields: true
tags: [E10, 数据字典]
---

# cs_app_download_info

> 应用下载信息表

> [!info] 基本信息
> - 数据库表名：`cs_app_download_info`
> - 中文名称：应用下载信息表
> - 所属模块：云商店
> - 所属数据库：`cloudstore`
> - 表类型：普通表
> - 负责人：汤海军
> - 创建者：徐德力
> - 是否公共配置：0
> - 描述：应用下载信息表
> - 数据ID：`1072339044832878626`
> - 最后更新：2024-11-29 17:43:10

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | ver_id | 版本id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | app_name | 名称 | 字符 | 255 |  |  |  |  |  |  |  |
| 9 | module_type | 一级分类 | 字符 | 100 |  |  |  |  |  |  |  |
| 10 | second_module_type | 二级分类 | 字符 | 100 |  |  |  |  |  |  |  |
| 11 | pri_employee_id | 下载人id | 长整型 |  |  |  |  |  |  |  |  |
| 12 | pri_username | 下载人名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 13 | pri_tenant_key | 下载租户key | 字符 | 20 |  |  |  |  |  |  |  |
| 14 | pri_tenant_key_name | 下载租户名称 | 字符 | 100 |  |  |  |  |  |  |  |
| 15 | pri_mobile | 下载手机号 | 字符 | 50 |  |  |  |  |  |  |  |
| 16 | pri_cid | 下载客户id | 字符 | 100 |  |  |  |  |  |  |  |
| 17 | pri_company_name | 下载公司名称 | 字符 | 255 |  |  |  |  |  |  |  |
| 18 | pri_desc | 下载描述 | 字符 | 255 |  |  |  |  |  |  |  |
| 19 | file_id | 文件id | 长整型 |  |  |  |  |  |  |  |  |
| 20 | app_id | 应用id | 长整型 |  |  |  |  |  |  |  |  |
| 21 | pri_license_code | 系统识别码 | 字符 | 500 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/云商店]]
- 数据库索引：[[数据库索引/cloudstore]]
