---
table_name: em_customer_basic_config
cn_name: em客服基础配置表
module: 系统消息
database: em_msg
type: 普通表
owner: 钱文明
creator: 王富昕
public_config: 0
data_id: 1172527072704340400
has_fields: true
tags: [E10, 数据字典]
---

# em_customer_basic_config

> em客服基础配置表

> [!info] 基本信息
> - 数据库表名：`em_customer_basic_config`
> - 中文名称：em客服基础配置表
> - 所属模块：系统消息
> - 所属数据库：`em_msg`
> - 表类型：普通表
> - 负责人：钱文明
> - 创建者：王富昕
> - 是否公共配置：0
> - 描述：em客服基础配置表
> - 数据ID：`1172527072704340400`
> - 最后更新：2025-08-26 17:23:53

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | customer_tk | 访客的租户key | 字符 | 10 |  |  |  |  |  |  |  |
| 8 | agent_id | 应用id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/系统消息]]
- 数据库索引：[[数据库索引/em_msg]]
