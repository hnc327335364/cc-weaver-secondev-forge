# 盘点之后会自动修改库存信息吗

来源快照：`result_data_new_260518.json`

- 来源 ID：`1970297005476065208`
- 模块：低代码平台e-builder
- 目录：常见问答 - 业务组件
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

**问题描述：**

在盘点中设置的盘点数量，可以直接修改库存信息吗？

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157720430512406530&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)  


** **

**解决方式：**

盘点计划中盘点出的实际数量，只作为参考比对，不会自动改变库存数量
