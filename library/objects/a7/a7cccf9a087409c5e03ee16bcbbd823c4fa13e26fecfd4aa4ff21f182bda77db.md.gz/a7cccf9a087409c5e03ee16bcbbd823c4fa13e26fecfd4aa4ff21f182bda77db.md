---
table_name: inde
cn_name: 1
module: e-Builder报表
database: srm_purchase
type: 
owner: 张健
creator: 系统管理员
public_config: 0
data_id: 100655700000005558
has_fields: true
tags: [E10, 数据字典]
---

# inde

> 1

> [!info] 基本信息
> - 数据库表名：`inde`
> - 中文名称：1
> - 所属模块：e-Builder报表
> - 所属数据库：`srm_purchase`
> - 表类型：—
> - 负责人：张健
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：1
> - 数据ID：`100655700000005558`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | grouplevel | 1 | 整型 | 1 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder报表]]
- 数据库索引：[[数据库索引/srm_purchase]]
