---
table_name: odoc_convert_record
cn_name: 文档转换记录表
module: 公文管理
database: weaver_odoc
type: 
owner: 岁军攀
creator: 系统管理员
public_config: 0
data_id: 100655700000003566
has_fields: true
tags: [E10, 数据字典]
---

# odoc_convert_record

> 文档转换记录表

> [!info] 基本信息
> - 数据库表名：`odoc_convert_record`
> - 中文名称：文档转换记录表
> - 所属模块：公文管理
> - 所属数据库：`weaver_odoc`
> - 表类型：—
> - 负责人：岁军攀
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：动作设置中文档前台转换时，记录转换信息表
> - 数据ID：`100655700000003566`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | doc_id | 正文ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | convert_doc_id | 转换后文档docid | 长整型 |  |  |  |  |  |  |  |  |
| 3 | convert_imagefile_id | 转换后文档fileid | 长整型 |  |  |  |  |  |  |  |  |
| 4 | convert_status | 转换状态 | 整型 |  |  |  |  |  |  |  |  |
| 5 | convert_node_id | 转换节点 | 长整型 |  |  |  |  |  |  |  |  |
| 6 | convert_field_id | 转换文档存放字段 | 长整型 |  |  |  |  |  |  |  |  |
| 7 | convert_type | 转换类型 1：ofd 2:pdf 3:merge | 整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/公文管理]]
- 数据库索引：[[数据库索引/weaver_odoc]]
