---
title: "收发文单位限制口子"
publicId: "829422f0-f8d2-4d75-81cf-d1f2626abb67"
source: "https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/doc/829422f0-f8d2-4d75-81cf-d1f2626abb67"
---
250601以后

**二开接口标识：**ODOC_RECEIVE_UNIT_BROWSER_002

**参数：**

| 参数名 |  | 必选 | 类型 | 说明 |
| --- | --- | --- | --- | --- |
| unitIdList |  | 是 | List<Long> | 单位id |
| userId |  | 是 | Long | 用户id |
| params |  | 是 | map | 前端参数 |

params主要参数commonShareType是 limit的时候表示标准会过滤限制

**返回值：**

| 参数名 |  | 必选 | 类型 | 说明 |
| --- | --- | --- | --- | --- |
| unitIdList |  | 是 | List<Long> | 单位id |
