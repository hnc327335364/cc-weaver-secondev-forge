---
description: "historyUtil historyUtil 全局路由工具：historyUtil 为 HistoryUtil 构造器内部实例化的对象"
category: cross-app-routing
keywords: ["historyUtil", "全局路由工具", "跨应用", "跨模块", "路由", "history", "链接拦截", "多级路径"]
source: "https://www.e-cology.com.cn/utils/historyUtil/freepass"
---

# historyUtil historyUtil 全局路由工具

## 适用场景

historyUtil 为 HistoryUtil 构造器内部实例化的对象

## 能力说明

historyUtil 全局路由工具

## 检索符号

- `historyUtil`

## 代表示例

```js
const historyUtil = new HistoryUtil();

const history = {
  go: historyUtil.go.bind(historyUtil),
  goBack: historyUtil.goBack.bind(historyUtil),
  goForward: historyUtil.goForward.bind(historyUtil),
  push: historyUtil.push.bind(historyUtil),
  replace: historyUtil.replace.bind(historyUtil),
  block: historyUtil.block.bind(historyUtil),
  listen: historyUtil.listen.bind(historyUtil),
  createHref: historyUtil.createHref.bind(historyUtil),
};

export { historyUtil };

export default history;
```

## 深入阅读
- [在线免登文档](https://www.e-cology.com.cn/utils/historyUtil/freepass)

> 本卡用于快速选型。参数、返回值、限制和完整示例以原始文档为准。
