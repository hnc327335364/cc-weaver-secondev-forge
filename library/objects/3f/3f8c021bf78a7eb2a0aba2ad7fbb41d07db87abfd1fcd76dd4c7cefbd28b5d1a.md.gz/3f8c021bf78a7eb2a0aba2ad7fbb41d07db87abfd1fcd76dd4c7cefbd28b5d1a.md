# 优化字段联动触发支持级联字段功能

来源快照：`result_data_new_260518.json`

- 来源 ID：`1234846558465105961`
- 模块：低代码平台e-builder
- 目录：功能更新说明 - 2026-01 - ESB动作流
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

### 2601基线字段联动触发支持级联字段

联动字段设置：支持选择级联字段

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234848083105423361&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

输出参数设置：级联字段赋值映射后联动触发正常

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234847756714278915&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

联动效果：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1234849023758581767&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
