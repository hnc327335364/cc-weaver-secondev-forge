---
table_name: esb_constant
cn_name: esb常量表
module: ESB中心
database: esb_setting
type: 普通表
owner: 程新
creator: 系统管理员
public_config: 0
data_id: 100655700000000042
has_fields: true
tags: [E10, 数据字典]
---

# esb_constant

> esb常量表

> [!info] 基本信息
> - 数据库表名：`esb_constant`
> - 中文名称：esb常量表
> - 所属模块：ESB中心
> - 所属数据库：`esb_setting`
> - 表类型：普通表
> - 负责人：程新
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：esb常量表
> - 数据ID：`100655700000000042`
> - 最后更新：2025-09-26 17:02:57

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  |  |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | name | 连接器名称 | 字符 | 500 |  |  |  |  |  |  |  |
| 8 | content | 内容 | 大字段1 |  |  |  |  |  |  |  |  |
| 9 | content_type | 类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 10 | description | 描述 | 字符 | 1000 |  |  |  |  |  |  |  |
| 11 | status | 状态 | 整型 |  |  |  |  | 0 |  |  | 0、正常  1、封存 |
| 12 | group_pk | 分组 | 长整型 |  |  |  |  |  |  |  | esb_group.primarykey |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/ESB中心]]
- 数据库索引：[[数据库索引/esb_setting]]
