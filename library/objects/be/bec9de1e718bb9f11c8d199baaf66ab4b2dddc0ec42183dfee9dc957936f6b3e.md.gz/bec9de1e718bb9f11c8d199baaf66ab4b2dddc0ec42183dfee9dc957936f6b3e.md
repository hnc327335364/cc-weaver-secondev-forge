---
table_name: ebdf_tpa_app
cn_name: 第三方应用app相关的配置存储表
module: e-Builder应用建模
database: ebuilder_form
type: 普通表
owner: 程东勇
creator: 陈建江
public_config: 0
data_id: 985745597917020171
has_fields: true
tags: [E10, 数据字典]
---

# ebdf_tpa_app

> 第三方应用app相关的配置存储表

> [!info] 基本信息
> - 数据库表名：`ebdf_tpa_app`
> - 中文名称：第三方应用app相关的配置存储表
> - 所属模块：e-Builder应用建模
> - 所属数据库：`ebuilder_form`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：陈建江
> - 是否公共配置：0
> - 描述：第三方应用app相关的配置存储表
> - 数据ID：`985745597917020171`
> - 最后更新：2025-12-04 15:21:35

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | enable_create_form | 启用创建表单 | 整型 | 5 |  |  |  |  |  |  |  |
| 8 | enable_merge_card_set | 开启聚合卡片设置 | 整型 | 5 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/ebuilder_form]]
