---
table_name: esb_event_log
cn_name: 
module: 
database: ebuilder_esb
type: 
owner: 
creator: 系统管理员
public_config: 0
data_id: 100655700000000874
has_fields: true
tags: [E10, 数据字典]
---

# esb_event_log

> [!info] 基本信息
> - 数据库表名：`esb_event_log`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`ebuilder_esb`
> - 表类型：—
> - 负责人：—
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000000874`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id |  | 整型 |  |  |  |  |  |  |  |  |
| 2 | batchkey |  | 字符 | 30 |  |  |  |  |  |  |  |
| 3 | eventtime |  | 字符 | 100 |  |  |  |  |  |  |  |
| 4 | eventstate |  | 字符 | 100 |  |  |  |  |  |  |  |
| 5 | requestparams |  | 大字段3 |  |  |  |  |  |  |  |  |
| 6 | responseparams |  | 大字段3 |  |  |  |  |  |  |  |  |
| 7 | clientip |  | 字符 | 100 |  |  |  |  |  |  |  |
| 8 | logpath |  | 字符 | 800 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/ebuilder_esb]]
