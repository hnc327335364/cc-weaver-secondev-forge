# 创建部门群

来源快照：`result_data_new_260518.json`

- 来源 ID：`1191830064494927882`
- 模块：工作消息
- 目录：管理员操作指南 - 群聊管理
- space ID：`1159418347111063584`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# **一、功能背景**

想快速给整个部门人员或多个部门联合创建一个群聊，方便部门协作，提升管理效率；同时，当人员部门变更后能够自动加入或退出相应的部门群，降低群组管理成本。

# **二、功能价值**

1.

提升管理效率：支持单部门创建或多部门合并快速建群。

2.

灵活权限配置：支持后台配置部门群群主、管理员等信息。

3.

群成员动态调整：群成员部门岗位变更，自动进退群。

# **三、功能概述**

部门群聊统一管理：支持搜索部门群，修改部门群名称、部门、群主、管理员等。

新建部门群：支持选择一个或多个部门创建部门群聊，支持选择是否包含下级部门成员。

普通群转部门群：支持选择一个普通群，再选择需要转换的部门进行转换，普通群将变为部门群，部门人员将自动进群。

部门群转普通群：将一个部门群转换为普通群，群成员进退群将不再受到部门变更影响。

# **四、业务流程图**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200736289075290120&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# **五、功能详细说明**

## **1\. 新建部门群**

点击新增部门群——选择部门——分别创建。

1.

若部门中没有人员，创建部门群会成功，群人数为0；

2.

部门存在人员，若此部门未创建群聊，则弹窗创建部门群成功；若此部门已存在部门群，则弹窗创建部门群失败， _**_ 部门已存在。

3.

选择包含下级部门人员指群成员中包含已有的及以后新增的下级部门所包含人员；

4.

创建成功后，该部门的人可在前台查看到该群聊，其他部门人无法查看。后台创建人若不在此部门，也在前台看不到此群聊。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200736555395276808&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200736847295209474&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200736894638145540&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200736924795191299&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## **2\. 新建联合部门群**

点击新增部门群——选择多个部门——联合创建。

1.

A\B\C三个部门未创建过联合部门群时，选择联合创建，创建成功；群成员包含A+B+C三个部门人员；若A\B\C三个部门已创建联合部门群，则会创建失败；

2.

若选择包含下级部门人员那么联合部门群成员为A+B+C+a+b+c。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737105110687754&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737139462037511&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737165179142146&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## **3\. 普通群转部门群或部门群转普通群**

点击普通群转部门群——选择部门（未创建的部门群的）——点击确定

1.

普通群所转的部门群，要求该部门未创建部门群，若已创建会转群失败；

2.

普通群转部门群成功后，原部门人员存在于部门群中，普通群成员未在此部门的，不会进入部门群聊。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737272612044802&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737311189426180&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737354042630154&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

部门群转普通群后，原部门群人员继续保留在普通群中，此后群成员不会跟随部门人员变化，普通群默认群列表第一人为群主，并且会有灰色消息提示：**此群组已变更为普通群， A成为群主。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737495994654720&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## **4\. 部门群设置**

点击单条数——进入群设置页面

1.

可修改群名称、部门进行添加或删除、设置群主、设置管理员（未设置时，部门群默认为无群主和管理员）

2.

点击人员校对，可对当前部门群人数进行校对；

3.

解散群聊：此功能会将群成员从群聊中退出，历史消息也将会删除，解散后可再次根据部门或联合部门重建群身份。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737646188486660&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## **5\. 部门群搜索**

可根据创建日期、群组名称、群id等进行搜索；点击重置，会重置所有搜索条件。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1200737787872075785&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# **六、上下游关联功能点**

1.

全员群开启，参考文档：[开启全员群](https://im.weaver.com.cn/web/#/46/5649 "开启全员群")；

2.

团队所有群聊维护，参考文档：群聊维护。

# **七、注意点**

1.

部门群只能通过后台创建，后台解散、后台管理。

2.

部门群前台不能邀请成员、移除群成员、修改群名称、修改群头像以及不能修改部门群动态规则。

3.

部门群解散后重建，群id不会变，因此部门群身份不会因解散而删除。

4.

人员入职、离职、部门调整，部门群人员会自动更新。

5.

部门群具有部门群标识，并且在群高级搜索处可根据部门群类型快速筛选数据。
