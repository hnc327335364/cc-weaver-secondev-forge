---
table_name: flow_step_26
cn_name: 
module: 
database: flow
type: 
owner: 
creator: 系统管理员
public_config: 0
data_id: 100655700000001854
has_fields: true
tags: [E10, 数据字典]
---

# flow_step_26

> [!info] 基本信息
> - 数据库表名：`flow_step_26`
> - 中文名称：—
> - 所属模块：—
> - 所属数据库：`flow`
> - 表类型：—
> - 负责人：—
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：—
> - 数据ID：`100655700000001854`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id |  | 小数 |  |  |  |  |  |  |  |  |
| 2 | title | 节点标题 | 字符 | 255 |  |  |  |  |  |  |  |
| 3 | type | 节点类型 | 字符 | 50 |  |  |  |  |  |  |  |
| 4 | creator | 节点创建人 | 小数 |  |  |  |  |  |  |  |  |
| 5 | create_time | 节点创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 6 | start_time |  | 日期时间 |  |  |  |  |  |  |  |  |
| 7 | end_time |  | 日期时间 |  |  |  |  |  |  |  |  |
| 8 | flow_request |  | 小数 |  |  |  |  |  |  |  |  |
| 9 | tenant_key |  | 字符 | 20 |  |  |  |  |  |  |  |
| 10 | last_path |  | 字符 | 20 |  |  |  |  |  |  |  |
| 11 | next_step | 下个节点 | 小数 |  |  |  |  |  |  |  |  |
| 12 | flow_sequence |  | 小数 |  |  |  |  |  |  |  |  |
| 13 | readonly |  | 小数 |  |  |  |  |  |  |  |  |
| 14 | form_writable |  | 小数 |  |  |  |  |  |  |  |  |
| 15 | or_check |  | 小数 |  |  |  |  |  |  |  |  |
| 16 | verify |  | 小数 |  |  |  |  |  |  |  |  |
| 17 | source_id |  | 小数 |  |  |  |  |  |  |  |  |
| 18 | is_delete |  | 小数 |  |  |  |  |  |  |  |  |
| 19 | sort |  | 小数 |  |  |  |  |  |  |  |  |
| 20 | is_died |  | 小数 |  |  |  |  |  |  |  |  |
| 21 | auto_pass_switch |  | 小数 |  |  |  |  |  |  |  |  |
| 22 | take_back_switch |  | 小数 |  |  |  |  |  |  |  |  |
| 23 | take_back_type |  | 字符 | 20 |  |  |  | unRead |  |  |  |
| 24 | process_time | 节点处理工时 | 整型 |  |  |  |  |  |  |  |  |
| 25 | plan_finish_time | 计划完成时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 26 | actual_finish_time | 实际完成时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 27 | operate_type | 节点类型 | 字符 | 20 |  |  |  |  |  |  |  |
| 28 | field_auth_version |  | 小数 |  |  |  |  |  |  |  |  |
| 29 | add_operator_switch |  | 小数 |  |  |  |  |  |  |  |  |
| 30 | add_step_switch |  | 小数 |  |  |  |  |  |  |  |  |
| 31 | add_step_type |  | 字符 | 20 |  |  |  | allAuthority |  |  |  |
| 32 | free_reject_switch |  | 小数 |  |  |  |  |  |  |  |  |
| 33 | sub_and_con |  | 整型 |  |  |  |  | 0 |  |  |  |
| 34 | or_check_num |  | 整型 |  |  |  |  |  |  |  |  |
| 35 | or_check_type |  | 字符 | 20 |  |  |  |  |  |  |  |
| 36 | operate_round |  | 整型 |  |  |  |  | 1 |  |  |  |
| 37 | flow_condition |  | 小数 |  |  |  |  |  |  |  |  |
| 38 | time_out_type |  | 字符 | 100 |  |  |  | none |  |  |  |
| 39 | time_out_hours |  | 小数 |  |  |  |  |  |  |  |  |
| 40 | time_out_frequency | 节点延期处理频率 | 字符 | 50 |  |  |  | none |  |  |  |
| 41 | entrust_switch | 委托开关 | 小数 |  |  |  |  | 1 |  |  |  |
| 42 | carbon_copy_switch | 抄送开关 | 小数 |  |  |  |  | 1 |  |  |  |
| 43 | copy_switch | 复制开关 | 小数 |  |  |  |  | 1 |  |  |  |
| 44 | print_switch | 打印开关 | 小数 |  |  |  |  | 1 |  |  |  |
| 45 | signature_switch |  | 小数 |  |  |  |  | 0 |  |  |  |
| 46 | stop_global_approve_switch |  | 小数 |  |  |  |  | 0 |  |  |  |
| 47 | edit_flow_name_switch |  | 小数 |  |  |  |  | 1 |  |  |  |
| 48 | serial_no |  | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/未命名]]
- 数据库索引：[[数据库索引/flow]]
