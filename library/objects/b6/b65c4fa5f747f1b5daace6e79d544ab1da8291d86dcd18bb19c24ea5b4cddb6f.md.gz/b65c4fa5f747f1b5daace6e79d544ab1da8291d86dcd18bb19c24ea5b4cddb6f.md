---
table_name: ic_ldap_cleanlog
cn_name: Ldap日志定时清理表
module: LDAP集成
database: int_center_ldap
type: 普通表
owner: 陆迪付
creator: 系统管理员
public_config: 0
data_id: 100655700000005928
has_fields: true
tags: [E10, 数据字典]
---

# ic_ldap_cleanlog

> Ldap日志定时清理表

> [!info] 基本信息
> - 数据库表名：`ic_ldap_cleanlog`
> - 中文名称：Ldap日志定时清理表
> - 所属模块：LDAP集成
> - 所属数据库：`int_center_ldap`
> - 表类型：普通表
> - 负责人：陆迪付
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：Ldap日志定时清理
> - 数据ID：`100655700000005928`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | isused | 是否启用 | 字符 | 1 |  |  |  |  |  |  | 1为启用；非1 不启用，默认不启用 |
| 8 | days | 保留日志天数 | 整型 |  |  |  |  |  |  |  |  |
| 9 | pointid | 计划任务标识 | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/LDAP集成]]
- 数据库索引：[[数据库索引/int_center_ldap]]
