---
table_name: ic_mail_coremaildeftpwd
cn_name: 集成中心邮箱集成coremail邮箱新建人员默认密码记录表
module: 邮箱集成
database: intmail_web
type: 
owner: 陆迪付
creator: 系统管理员
public_config: 0
data_id: 100655700000004138
has_fields: true
tags: [E10, 数据字典]
---

# ic_mail_coremaildeftpwd

> 集成中心邮箱集成coremail邮箱新建人员默认密码记录表

> [!info] 基本信息
> - 数据库表名：`ic_mail_coremaildeftpwd`
> - 中文名称：集成中心邮箱集成coremail邮箱新建人员默认密码记录表
> - 所属模块：邮箱集成
> - 所属数据库：`intmail_web`
> - 表类型：—
> - 负责人：陆迪付
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：集成中心邮箱集成coremail邮箱新建人员默认密码记录表
> - 数据ID：`100655700000004138`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | base_id | 基本设置标识 | 固定长度 | 50 |  |  |  |  |  |  | 邮箱基本设置标识id |
| 2 | userid | 用户id | 固定长度 | 50 |  |  |  |  |  |  |  |
| 3 | loginid | 登录名 | 固定长度 | 200 |  |  |  |  |  |  |  |
| 4 | lastname | 姓名 | 固定长度 | 200 |  |  |  |  |  |  |  |
| 5 | defaultpwd | 新建时密码 | 固定长度 | 50 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/邮箱集成]]
- 数据库索引：[[数据库索引/intmail_web]]
