---
table_name: ds_logic_field_cowork
cn_name: 数据源对接，cowork服务，cowork表
module: 协作区
database: cowork
type: 普通表
owner: 李伟（上海）
creator: 系统管理员
public_config: 0
data_id: 100655700000004799
has_fields: true
tags: [E10, 数据字典]
---

# ds_logic_field_cowork

> 数据源对接，cowork服务，cowork表

> [!info] 基本信息
> - 数据库表名：`ds_logic_field_cowork`
> - 中文名称：数据源对接，cowork服务，cowork表
> - 所属模块：协作区
> - 所属数据库：`cowork`
> - 表类型：普通表
> - 负责人：李伟（上海）
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：数据源对接，cowork服务，cowork表
> - 数据ID：`100655700000004799`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | field_name | 字段名称 | 字符 | 255 |  |  |  |  |  |  | 字段名称 |
| 8 | field_type | 字段类型 | 字符 | 255 |  |  |  |  |  |  | 字段类型 |
| 9 | field_text | 字段描述 | 字符 | 255 |  |  |  |  |  |  | 字段描述 |
| 10 | table_id | 字段所在表id | 长整型 |  |  |  |  |  |  |  | 字段所在表id |
| 11 | is_main_field | 是否是主表字段 | 整型 |  |  |  |  |  |  |  | 是否是主表字段 |
| 12 | sub_table_id | 明细表id | 长整型 |  |  |  |  |  |  |  | 明细表id |
| 13 | field_usage | 字段用途 | 字符 | 20 |  |  |  |  |  |  | 字段用途 |
| 14 | label_id | 国际化ID | 长整型 |  |  |  |  |  |  |  |  |
| 15 | disallowed_usage | 字段不允许的操作 | 字符 | 255 |  |  |  |  |  |  | 字段不允许的操作 |
| 16 | main_primary_key | 是否租表主键 | 小整数 |  |  |  |  |  |  |  |  |
| 17 | service_module | 字段所属模块 | 字符 | 255 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/协作区]]
- 数据库索引：[[数据库索引/cowork]]
