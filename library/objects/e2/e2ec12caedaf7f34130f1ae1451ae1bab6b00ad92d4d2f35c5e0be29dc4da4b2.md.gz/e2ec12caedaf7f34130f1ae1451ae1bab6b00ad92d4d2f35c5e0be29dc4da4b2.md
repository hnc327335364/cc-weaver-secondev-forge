# 标签选择器-Dialog

## 组件效果图
![](https://im.weaver.com.cn/server/index.php?s=/api/attachment/visitFile&sign=728a2048c52d5557faf2a314f9053175)

## DEMO

CorsComponent 组件方式

```js

render() {
    return <>
            <Button onClick={this.toggleTagSelector}>打开标签选择器</Button>
            <CorsComponent
                app='@weapp/my'
                compName='WTagSelectorDialog'
                module="task"
                entityIds={['2225467478715054228', '2225467475828154209']}
                visible={this.state.openTagSelector}
                onClose={this.toggleTagSelector}
                onSelect={this.onSelectWTag}
            />
    </>
}

toggleTagSelector = () => {
    this.setState({ openTagSelector: !this.state.openTagSelector })
}

onSelectWTag =(tags:TagData[])=> {
    console.log('on select wtags', tags)
}
```

### 参数说明

| 参数      | 说明                               | 类型                       | 是否必填 | 默认值   |
|:----------|:-----------------------------------|:---------------------------|:---------|:---------|
| type            | 标签类型 0 公共标签 ，1 个人标签，2 全部标签，3 模块标签                                                                              | enum                      | 否       | 1      |
| module    | 事项所属模块的模块标识             | string                     | 是       | -        |
| entityId  | 事项 id                            | string                     | 否       | -        |
| entityIds | 事项 id（支持批量时传入）          | string[]                   | 否       | -        |
| visible   | 是否显示                           | boolean                    | 是       | -        |
| title     | 选择器标题                         | string                     | 否       | 选择标签 |
| onClose   | 关闭时的回调                       | (isBack?: boolean) => void | 是       | -        |
| onSelect  | 选中标签的回调方法，返回设置的标签 | (tags: TagData[]) => void  | 否       | -        |
| onLoadRecommend | 加载推荐标签，异步返回推荐标签列表列表，比如：[{id:'xx', name: 'xx'}]）                                      | () =>  Promise<TagData[]> | 否       | -        |
| isTree   | 是否启用标签树选择器，开启将使用最新的标签树选择组件，不传则使用之前老的标签选择组件（基于兼容和风险性考虑）                           | boolean                    | 是       | -        |

注意： 该组件基于公共UI库的 DIalog 组件，所以支持直接传入 DialogProps，比如要自定义设置高度，直接传入 height 即可
