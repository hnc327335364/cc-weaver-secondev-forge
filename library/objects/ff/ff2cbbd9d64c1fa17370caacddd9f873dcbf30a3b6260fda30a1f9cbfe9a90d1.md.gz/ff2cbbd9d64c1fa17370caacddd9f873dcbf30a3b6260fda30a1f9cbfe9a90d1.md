### 获取分页数据

**最低基线支持:2501.01**

#### 请求接口：

- com.weaver.ebuilder.form.client.service.emobile.IEtFormDatasetService#getDatas#ebuilderform
  
  (interface#method#group)

##### ([为后续项目使用中切换应用独立部署的需要，二开逻辑请使用独立部署方式调用](https://weapp.eteams.cn/build/techdoc/wdoc/index.html#/public/doc/81831572-da60-474d-9328-2309af780fb9))

```java
// 基线版本:10.0.2410.01(含), 版本后必须使用该方式操作 - (为后续项目使用中切换应用独立部署的需要)
// 如 调用RemoteSimpleDataService#saveFormData方法需要按以下方式调整

@Autowired
private PublishKitRuntimeUtil publishKitRuntimeUtil;

RemoteSimpleDataService remoteSimpleDataService = publishKitRuntimeUtil.buildRpcService(com.weaver.ebuilder.form.client.service.data.RemoteSimpleDataService.class, "ebuilderform", appId);
remoteSimpleDataService.saveFormData(ebDataChangeReqDto);

/******************************************************************************************************************/

// 基线版本:10.0.2410.01之前版本可使用:
@RpcReference(group = "ebuilderform")
private com.weaver.ebuilder.form.client.service.data.RemoteSimpleDataService remoteSimpleDataService;

remoteSimpleDataService.saveFormData(ebDataChangeReqDto);
```

#### 请求参数：

| 参数名 | 参数类型 | 参数说明 |
| --- | --- | --- |
| objId | String | EB表单id |
| module | String | 模块标识（可传空） |
| query | String | com.weaver.ebuilder.teams.etform.base.query.Query对象base64转码之后的值 |
| otherParm | String | 其他条件值 可支持自定义参数处理 |

#### 返回值：

| 类型 | 类型所属包路径 | 描述 |
| --- | --- | --- |
| Map\<String, Objcet\> | java.util.Map | 数据集合 |

特殊参数构造说明:

```java
// 构建参数， 组装到query对象中
// 1.接口获取数据默认校验权限，如果无需校验权限获取 需组装:
Map<String, Object> ebuilderDataConfig = Maps.newHashMap();
Map<String, Object> dataSetup = Maps.newHashMap();
dataSetup.put("dataPermission", "ALL");
ebuilderDataConfig.put("dataSetup", dataSetup);
query.setEbuilderDataConfig(ebuilderDataConfig); 

// 2.若为免登场景或需要手动指定和人员和租户信息可通过设置简化人员对象显式传入参数
EBSimpleEmployee ebSimpleEmployee = new EBSimpleEmployee("人员id", "租户识别码");
query.setEbSimpleEmployee(ebSimpleEmployee);
```

**获取人员参数优先级说明（建议通过第一种方式通过参数方式显式传递租户和人员信息）：**

1. 从Query对象EBSimpleEmployee对象获取. 如果没有加载到显式传递参数
2. 从架构的RpcContext中获取, 线程上下文如果没有加载到
3. 从UserContext中获取
4. 如果都没有加载到， 提示组织信息获取异常

query对象说明：

| 参数名 | 参数类型 | 参数说明 |
| --- | --- | --- |
| conditions | List\<Condition\> | 老版条件解析,List结构 |
| conditionTrees | ConditionTreeDto | 新树形条件解析 |
| queryFields | List\<QueryField\> | 查询字段 |
| orderFields | List\<OrderField\> | 排序字段 |
| pageNo | Integer | 分页查询当前页码 |
| pageSize | Integer | 分页查询单页大小 |
| statCount | Boolean | 是否统计数据(true统计) |
| groupFields | List\<GroupField\> | 分组字段(分组接口使用) |
| groupStatFields | List\<StatField\> | 分组统计字段(分组接口使用) |
| ebSimpleEmployee | EBSimpleEmployee | 简化人员对象 |

- 具体使用方式见[请求数据](https://weapp.eteams.cn/sp/techdoc/doc/682655755930173441#ojiPF)

#### 条件构造说明:

```java

// 新版条件(支持场景更多 - 推荐使用)
ConditionTreeDto conditionTreeDto = new ConditionTreeDto();
conditionTreeDto.setRelationship("0 or/1 and");
conditionTreeDto.setIsParent(true/false 只做树形上下级解析使用， 当为parent节点会解析下级条件并以relationship关联子级条件);
conditionTreeDto.setConditionList(List<ConditionTreeDto> 子级条件);
conditionTreeDto.setConditionId("条件字段fieldId-- getFields接口返回的fieldId");
conditionTreeDto.setConditionValue("条件值 针对多选条件场景逗号分隔");
conditionTreeDto.setCompareType("eq/neq/gt/lt/gtAndEq/ltAndEq/startWith/endWith/range/contains/uncontains/like/notLike/aggregate/unaggregate/in/notIn/isNull/isNotNull")
```

~~// 老版条件(方便构造，可用但不推荐，~~~~ 现在已不再迭代~~~~)~~

~~Condition condition = new Condition();~~

~~condition.setConditionId("条件字段fieldId-- getFields接口返回的fieldId");~~

~~condition.setCompareType("eq/neq/isNull/isNotNull/like/notlike/startWith/endWith 条件类型");~~

~~condition.setConditionValue("条件值 针对多选条件场景逗号分隔");~~

~~condition.setGroupId("groupId不同或为空 为and条件， 相同的为一组条件，一组条件内or处理");~~

~~query1.setConditions(Collections.singletonList(condition)); ~~

#### 简单请求示例：

```java
Query query = new Query();
List<Condition> conditions = new ArrayList<>();
Condition condition = new Condition();
condition.setConditionId("id");
condition.setCompareType("eq");
condition.setConditionValue("910048294042828805");
conditions.add(condition);
query.setConditions(conditions);
String queryStr = Base64.getEncoder().encodeToString(JSONUtil.stringify(query).getBytes());
Map<String, Object> datas = iEtFormDatasetService.getDatas(objId, "", queryStr, null);
```

**请求字段设置**

```java
// QueryFields未做设置默认查询主表全字段.  如果指定设置为查询对应主表字段
// 如果需要查询明细表字段， 需要额外指定明细表字段为请求参数 传入otherParams
List<String> tableField = new ArrayList<>();
tableField.add("id_762435945861169156");
tableField.add("id_762752210240208901");
tableField.add("id_762752454969458688");
otherParm.put("tableField", tableField);
```

#### 返回示例：

```json
{
        "count": 66,
        "field_map": {},
        "list": [
            {
                "7833469351760250635": "33333",
                "7833469351760250637": "33333",
                "7833469352480064398": "15111111111",
                "7833469355344650653": [
                    {
                        "id": "5112849484828049659",
                        "name": "yyk不乱码"
                    }
                ],
                "7833469355344650654": [
                    {
                        "id": "5140517273323883176",
                        "name": "weaver-demo"
                    }
                ],
                "UPDATE_TIME": 1656569251000,
                "create_time": 1656560458000,
                "creator": [
                    {
                        "id": "5112849484828049659",
                        "name": "yyk不乱码"
                    }
                ],
                "data_status": [
                    {
                        "id": "1",
                        "name": "提交"
                    }
                ],
                "form_data_id": "5955656045764824598",
                "id": "744577497769918465",
                "obj_id": "650659679596281856"
            }
        ]
}
```

#### 返回主要属性说明:

| 参数名 | 参数类型 | 参数说明 |
| --- | --- | --- |
| id | String | 数据ID |
| form\_data\_id | String | 表单数据ID |
| obj\_id | String | 表单ID |
| creator | List | 创建人对象 |
| data\_status | List | 数据状态对象 |
| create\_time | imestamp | 创建时间 |
| UPDATE\_TIME | imestamp | 更新时间 |
