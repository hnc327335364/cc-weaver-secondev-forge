---
table_name: excel_temp_variable
cn_name: 函数临时变量
module: Excel函数
database: eteams
type: 普通表
owner: 江伟
creator: 系统管理员
public_config: 0
data_id: 100655700000001135
has_fields: true
tags: [E10, 数据字典]
---

# excel_temp_variable

> 函数临时变量

> [!info] 基本信息
> - 数据库表名：`excel_temp_variable`
> - 中文名称：函数临时变量
> - 所属模块：Excel函数
> - 所属数据库：`eteams`
> - 表类型：普通表
> - 负责人：江伟
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：函数临时变量
> - 数据ID：`100655700000001135`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | formula_id | 函数id | 整型 |  |  |  |  |  |  |  |  |
| 2 | var_key | key | 字符 | 100 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/Excel函数]]
- 数据库索引：[[数据库索引/eteams]]
