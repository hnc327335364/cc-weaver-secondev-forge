---
title: "E10特色门户主题ecode开发说明（视频与Demo整理）"
aliases:
  - "E10特色门户主题ecode开发说明"
  - "E10特色门户主题开发"
  - "特色门户主题ecode开发"
  - "门户主题前端开发"
domain: "weaver-knowledge"
category: "e10-reference"
note_type: "reference-note"
status: "active"
language: "zh-CN"
summary: "基于 2026-07-21 学习视频和商务蓝门户主题 demo 整理的 E10 特色门户主题 ecode 开发说明，覆盖开发入口、发布启用、MainLayout 覆盖、moduleContent 内容区占位、顶部工具栏、左侧菜单、样式配置、验证清单和 demo 风险点。"
source_path: "02-Weaver-Knowledge 泛微知识库/02-E10 E10资料/E10特色门户主题ecode开发说明（视频与Demo整理）.md"
source_docs:
  - "<已失效>下载文件：7月21日.mov"
  - "WEAVER_E10_PROJECT_ROOT/secondev-shxivii-jingwen-cc/ecode/商务蓝门户主题示例"
  - "02-Weaver-Knowledge 泛微知识库/02-E10 E10资料/e10平台定制开发指引.md"
  - "02-Weaver-Knowledge 泛微知识库/02-E10 E10资料/weappUtils-注入与React扩展.md"
  - "02-Weaver-Knowledge 泛微知识库/02-E10 E10资料/weappUtils-主题与样式.md"
tags:
  - "vault/CcLLMWiki"
  - "domain/weaver"
  - "type/reference"
  - "platform/e10"
  - "topic/frontend"
  - "topic/ecode"
  - "topic/portal"
  - "topic/theme"
product_line: "E10"
tech_scene:
  - "前端"
  - "门户"
capability_module:
  - "e-code"
  - "门户"
  - "特色主题"
artifact_type: "开发说明"
retrieval_terms:
  - "特色门户主题"
  - "门户主题"
  - "ecode主题"
  - "MainLayout"
  - "regOvComponent"
  - "moduleContent"
  - "LayoutSDK"
  - "hybridModuleMenus"
  - "moduleMenuItemClick_mixed"
source_type: "视频与Demo整理"
confidence: "medium"
---

# E10特色门户主题ecode开发说明（视频与Demo整理）

## 资料性质

当前资料不是官方完整开发手册，而是根据学习视频和 `商务蓝门户主题示例` demo 反推整理的开发说明。可作为特色门户主题 ecode 开发入门、demo 二开拆解和项目交付前检查依据；涉及平台内部接口、基线差异、标准主题扩展口子时，仍需结合项目环境或官方人员确认。

已知相关官方/准官方资料线索：

- `e10平台定制开发指引.md` 的“门户开发”章节列出 `Ecode门户元素、门户主题前端开发说明文档`、`特色主题开发`、`门户元素二开`等入口。
- `weappUtils-注入与React扩展.md` 说明 `regOvComponent` 属于无侵入二次开发能力。
- `weappUtils-主题与样式.md` 说明 `setTheme` 及 CSS 变量主题能力。

## 适用范围

适用于 E10 PC 端特色门户主题开发，典型目标是重写门户壳层的顶部、左侧菜单、账号区、搜索区和主题样式，同时保留标准门户内容区。

不适用于：

- 直接修改 E10 标准门户源码。
- 默认认为标准主题的所有配置交互会自动在特色主题中生效。
- 在没有确认口子的情况下改标准主题交互行为。

视频问答中提到：特色主题是“半开发”的形式。系统配置的数据可以读取，但展示方式、点击行为和弹层行为是否生效，取决于特色主题代码是否实现对应逻辑。

## 开发与启用流程

1. 准备主题应用。

   可以从已有主题 demo 或平台案例库导入。视频中强调：导入后的应用不一定已发布，必须先发布后才能在特色主题配置中选择。

2. 新建特色主题。

   在特色主题配置中选择已发布的 ecode 应用，按需设置使用范围。主题记录需要启用，禁用状态不会生效。

3. 开发入口文件。

   视频中建议从“前置加载”标记定位主题入口文件。demo 中入口为 `entry.js`，案例通常使用规范命名，但不要只凭文件名判断。

4. 编写主题布局。

   通过入口覆盖 `MainLayout`，在自定义主布局中渲染顶部、左侧、内容区。内容区必须保留 `moduleContent`。

5. 发布并验证。

   修改代码后发布 ecode 应用，再刷新门户页面验证主题效果、菜单切换、工具栏、账号弹层和控制台报错。

## demo 文件结构

```text
商务蓝门户主题示例/
├─ entry.js                # 主题入口，前置加载，覆盖 MainLayout
├─ Main.js                 # 自定义主布局
├─ config/config.js        # logo、主题色、弹层位置、左侧菜单色值
├─ utils/index.js          # 动态样式、弹层配置、隐藏标准左侧菜单
├─ Logo.js                 # logo 与租户切换
├─ Toolbar.js              # 顶部工具栏
├─ Account.js              # 账号区与更多菜单
├─ AsideMenu.js            # 左侧混合菜单
├─ AsideCalendar.js        # 左侧日期区域
├─ Default.js / Custom.js  # 标准/自定义顶部菜单项
├─ CornerMark.js           # 角标
├─ styles/                 # 布局、工具栏、账号、菜单、搜索样式
└─ resources/              # 预览图和示例图片
```

## 核心入口机制

demo 的 `entry.js` 做了三件事：

```js
if (window.TEAMS && window.TEAMS.theme && window.TEAMS.theme.appId === '${appId}') {
  const Main = React.lazy(() => asyncImport('${appId}', 'Main'));
  const fn = () => React.forwardRef((props, ref) => (
    <React.Suspense fallback={() => { }}>
      <Main ref={ref} {...props} />
    </React.Suspense>
  ));
  regOvComponent('weappUi', 'MainLayout', fn, 0);
}
```

关键点：

- `window.TEAMS.theme.appId === '${appId}'` 用于限定只在当前主题应用生效。`${appId}` 会由 ecode 平台解析为实际应用 ID，通常不需要手工替换。
- `asyncImport('${appId}', 'Main')` 按需加载当前应用的 `Main` 组件。
- `regOvComponent('weappUi', 'MainLayout', fn, 0)` 使用无侵入方式替换标准主布局。
- `forwardRef` 用于透传组件实例引用，符合 `regOvComponent` 文档中的建议。

## MainLayout 内容区约束

`Main.js` 是特色主题壳层。demo 将页面拆成顶部 header、左侧 aside 和右侧 content：

```jsx
<div className="app-737142488378564608-content" style={contentStyle}>
  {this.props.moduleContent}
</div>
```

`moduleContent` 是标准门户/模块内容区占位。视频中明确强调：自定义主题时其他结构和样式可以按需求调整，但这个占位必须保留；否则只会显示顶部和左侧壳层，中间业务内容无法显示。

demo 中左侧显隐会同步调整宽度，并触发 `resize`：

```js
onAsideHiddenChange = (asideHidden) => {
  this.setState({ asideHidden }, () => { window.dispatchEvent(new Event('resize')); });
}
```

## 主题配置与样式初始化

`config/config.js` 提供主题基础配置：

- `logoImage`：默认 logo 图片。
- `logoActiveImage`：鼠标移入或展开时 logo 图片。
- `themeColor`：主题颜色。
- `dialogTop`：右侧弹层顶部位置。
- `asideBackgroundColor`：左侧背景色。
- `asideMenuHoverBackgroundColor`：左侧菜单 hover 背景色。
- `asideMenuActiveBackgroundColor`：左侧菜单选中背景色。

`utils/index.js` 中的 `loadThemeConfig()` 负责：

- 动态插入自定义 `<style>`，覆盖左侧菜单背景、hover、active 色值。
- 调整 `emContainerDiv` 的顶部和高度，使工作消息区域避开 60px 顶部栏。
- 设置 `Dialog.dialogConfig = { top, placement: 'right' }`，控制右侧展开弹层位置。
- 调用 `LayoutSDK.setAsideHidden(true)` 隐藏标准左侧菜单，让自定义左侧菜单接管展示。

样式建议：

- 使用独立命名空间前缀，demo 使用 `app-737142488378564608-*`，避免污染标准页面。
- 优先复用 E10 CSS 变量，例如 `var(--primary)`、`var(--danger)`、`var(--font-size-14)`。
- 动态样式插入时用固定 `style.id` 防止重复插入。

## 顶部区域开发

demo 顶部由 `Logo`、`QuickSearchCom`、`Toolbar`、`Account` 组成：

- `Logo.js`：私有化单租户场景不展示租户切换；多租户场景用 `TenantDropCom` 做下拉。
- `QuickSearchCom`：来自 `@weapp/layout`，通过 `className` 和 `popupClassName` 定制样式。
- `Toolbar.js`：读取 `headerMenuStore.navMenus` 渲染顶部默认菜单和自定义菜单。
- `Account.js`：展示 `window.TEAMS.currentUser`、`window.TEAMS.currentTenant`，并用 `QuickMenusCom` 展示未放入顶部的更多菜单。

顶部菜单打开方式由 `Toolbar.onOpen` 处理：

- `openWay === 2`：当前页打开。完整 URL 用 `window.location.href`，站内路径用 `history.push`。
- `openWay === 0`：`window.open(item.url)`。
- `openWay === 1`：按配置窗口大小打开新窗口。

demo 将可见顶部菜单控制在约 7 个，超出部分放入账号下拉的 `externalMenus`。这是示例策略，不是平台强制规则。

## 左侧混合菜单开发

`AsideMenu.js` 是 demo 中最核心、代码量最大的部分。整体思路是：读取系统混合菜单数据，转成 `@weapp/ui` 的 `Menu` 数据结构，再将点击事件交给 `LayoutSDK`。

数据来源：

```js
request({
  url: '/api/cusapp/app/hybridModuleMenus?terminalType=PC&menuType=0',
  method: 'GET'
})
```

数据处理要点：

- 从返回项中取 `cusAppMenus[0]` 作为菜单主体。
- 将 `portal` 模块提前展示。
- 递归补充 `parentIds`，用于点击和路由上下文。
- 递归处理 `angleCount`、`angleIcon`、`hasSearch` 等角标和设置入口。
- 一级菜单可根据 `module` 使用 `AppIcon` 或手工指定 `Icon`。

与标准布局联动的 hook：

- `LayoutSDK.regHook('asideMenusData', ...)`：监听标准侧边菜单数据变化，并决定自定义侧边栏是否隐藏。
- `LayoutSDK.regHook('asideMenuActiveKey', ...)`：监听当前激活菜单。
- `LayoutSDK.regHook('themeMenuData', ...)`：同步主题菜单角标数据。

菜单点击事件：

```js
LayoutSDK && LayoutSDK.doEvent('moduleMenuItemClick_mixed', { data, e, event: e });
```

这个事件是特色主题复用标准模块菜单行为的关键。视频中也强调：主题开发主要是前端展示改造，菜单数据和导航动作尽量复用系统标准能力，不需要单独重写接口。

## 跨应用组件复用

demo 大量使用 `CorsComponent` 和 `corsImport` 复用其他 E10 应用组件：

- `@weapp/em`：消息提醒列表、未读数监听。
- `@weapp/layout`：清缓存弹层、终端弹层、快捷菜单等。
- `@weapp/cusapp`：自定义菜单设置弹层。
- `@weapp/ebdcoms`：资产图标组件。

使用建议：

- 优先复用标准跨应用组件实现系统已有功能。
- 弹层 visible/onClose 状态由主题组件维护。
- 对未读数、角标等异步数据，需要注册刷新 hook 或重新请求。

## 配置导航与自定义交互

视频问答中对“配置导航菜单点击后不跳转、改成其他动作”的结论需要区分实现方式：

- 如果是特色主题全代码开发，点击行为由当前代码决定，可以自行处理。
- 如果是特色主题搭建/系统数据，需要看配置项是否提供点击事件或插件扩展能力。视频中提到 `0301` 基线之后支持部分插件模式，但具体基线版本和插件口子需要项目环境确认。
- 如果是标准门户主题，需要标准主题本身开放口子后才能改交互，不能默认通过特色主题 demo 的写法影响标准主题。
- 如果只是想改接口返回数据，可考虑 ecode 平台的接口拦截方案，并通过生效范围限制到目标页面；但该方案需要另查接口拦截资料确认。

## 开发排查方法

视频建议按效果反查代码：

1. 先从入口文件确认 `MainLayout` 覆盖。
2. 对照页面效果拆区域：顶部、搜索、工具栏、账号、左侧菜单、内容区。
3. 使用 Chrome DevTools 选中目标区域，看 DOM className 和组件命名。
4. 回到 demo 文件中按命名查找，例如 `AsideMenu`、`Toolbar`、`Logo`。
5. 如果不熟悉 `Menu`、`Trigger` 等组件参数，回到 E10 UI 组件库查 API。

## 发布验证清单

- ecode 应用已发布，且特色主题配置选择的是已发布应用。
- 特色主题记录处于启用状态，使用范围覆盖当前账号/团队。
- 控制台无入口文件加载失败、模块 import 失败、组件渲染错误。
- `window.TEAMS.theme.appId` 与当前应用匹配，`entry.js` 确实执行。
- 页面顶部、左侧菜单、右侧内容区都正常显示。
- `moduleContent` 存在，门户内容或模块内容能正常切换。
- 标准左侧菜单已隐藏，自定义左侧菜单点击能触发标准模块跳转。
- 顶部搜索、应用总览、消息、账号菜单、退出、清缓存等标准能力可用。
- 菜单角标、消息未读数、主题菜单刷新后能同步。
- 切换浏览器尺寸或展开/隐藏左侧栏后，内容区域布局正常。

## demo 风险点

当前 `商务蓝门户主题示例` 适合作为学习和参考，但不建议无脑复制到生产：

- `Default.js` 引用了 `./Wechat`，当前 demo 目录未发现 `Wechat.js`，直接构建可能报缺失模块。
- `AsideMenu.js` 的 `onAsideMenuSettingChange` 中使用了 `result?.value`，但该作用域内没有定义 `result`，需要按实际回调结果修正。
- `styles/AsideMenu.css` 中存在 `min-width: none` 这类无效 CSS 值，复制时应清理。
- 部分文件是 `.js` 后缀但包含 TypeScript 类型标注，例如 `props: any`，需要确认 ecode 编译器是否支持；若项目普通 Babel/JS 编译不支持，应改为合法 JS 或 TS。
- demo 的宽度、顶部显示数量、菜单排序、日历组件等属于示例设计策略，不是平台标准约束。

## 最小开发骨架

保留主题机制时，最小骨架可收敛为：

```text
entry.js
Main.js
config/config.js
utils/index.js
styles/index.css
```

其中：

- `entry.js` 负责判断主题 appId 并覆盖 `MainLayout`。
- `Main.js` 负责布局和 `moduleContent`。
- `config/config.js` 负责可改色值和 logo。
- `utils/index.js` 负责加载动态样式、隐藏标准侧边栏、调整弹层。
- `styles/index.css` 负责基础布局尺寸。

如果需要完整复刻商务蓝效果，再逐步加入 `Logo`、`Toolbar`、`Account`、`AsideMenu`、`AsideCalendar` 和对应样式。

## 后续需要补充的资料

- 特色主题配置页面的官方字段说明。
- 特色主题搭建模式和全代码模式的边界。
- `LayoutSDK` 在门户主题场景下的完整 hook/event 列表。
- `0301` 基线后插件模式的正式说明。
- ecode 接口拦截方案在门户菜单数据改造中的适用范围。
