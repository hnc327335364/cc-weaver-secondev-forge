# EB视图在组合页面、关联、按钮动作打开页面等场景下只需显示一个页头

来源快照：`result_data_new_260518.json`

- 来源 ID：`1243392641354956804`
- 模块：低代码平台e-builder
- 目录：功能更新说明 - 2026-02 - 应用建模
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

## 一、功能背景及价值用途

EB视图在组合页面、关联、按钮动作打开页面等场景下链接不同页面目前既展示了本身页头又展示了被链接页面的页头。

## 二、功能效果

入口：关联、按钮等打开表格，不会出现双页头

![](https://weapp.eteams.cn/papi/file/preview?fileId=1243392907865628675&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1243392942049206275&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
