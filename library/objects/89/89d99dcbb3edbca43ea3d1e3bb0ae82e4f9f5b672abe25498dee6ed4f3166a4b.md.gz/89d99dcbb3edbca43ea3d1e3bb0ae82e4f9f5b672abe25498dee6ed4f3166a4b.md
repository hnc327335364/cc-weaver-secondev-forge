---
table_name: em_app_link_setting
cn_name: appLink设置
module: 用户终端(EMobile)
database: em_base
type: 普通表
owner: 吴钱力
creator: 程利华
public_config: 0
data_id: 972469398701932582
has_fields: true
tags: [E10, 数据字典]
---

# em_app_link_setting

> appLink设置

> [!info] 基本信息
> - 数据库表名：`em_app_link_setting`
> - 中文名称：appLink设置
> - 所属模块：用户终端(EMobile)
> - 所属数据库：`em_base`
> - 表类型：普通表
> - 负责人：吴钱力
> - 创建者：程利华
> - 是否公共配置：0
> - 描述：用于配置scheme相关信息以及applink地址设置
> - 数据ID：`972469398701932582`
> - 最后更新：2024-03-05 14:37:56

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | app_link_name | applink名称 | 字符 | 200 |  |  |  |  |  |  |  |
| 8 | app_link_uri | applink路径参数 | 字符 | 200 |  |  |  |  |  |  |  |
| 9 | app_link_param | applinkUrl参数 | 字符 | 1000 |  |  |  |  |  |  |  |
| 10 | app_link_req_url | 生成的请求地址 | 字符 | 2000 |  |  |  |  |  |  |  |
| 11 | app_link_extra | 预留字段 | 字符 | 200 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/用户终端(EMobile)]]
- 数据库索引：[[数据库索引/em_base]]
