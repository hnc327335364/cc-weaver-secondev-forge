---
table_name: wfr_functionparam
cn_name: 条件函数映射参数
module: 工作流程
database: weaver_wfp
type: 普通表
owner: 柳直阳
creator: 柳直阳
public_config: 0
data_id: 100655700000004116
has_fields: true
tags: [E10, 数据字典]
---

# wfr_functionparam

> 条件函数映射参数

> [!info] 基本信息
> - 数据库表名：`wfr_functionparam`
> - 中文名称：条件函数映射参数
> - 所属模块：工作流程
> - 所属数据库：`weaver_wfp`
> - 表类型：普通表
> - 负责人：柳直阳
> - 创建者：柳直阳
> - 是否公共配置：0
> - 描述：条件函数映射参数表,用于存放函数映射关系
> - 数据ID：`100655700000004116`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | dataid | 数据id | 长整型 |  |  |  |  |  |  |  |  |
| 2 | datavalue | 映射值 | 字符 | 1000 |  |  |  |  |  |  |  |
| 3 | mapbaseid | 对应wfr_mapbase表的主键 | 长整型 |  |  |  |  |  |  |  |  |
| 4 | mapid | 对应wfr_maplist表的主键 | 长整型 |  |  |  |  |  |  |  |  |
| 5 | valueoption | 参数类型 | 整型 |  |  |  |  |  |  |  |  |
| 6 | orders | 顺序 | 整型 |  |  |  |  |  |  |  |  |
| 7 | datasrc | 数据来源 | 整型 |  |  |  |  | 0 |  |  |  |
| 8 | datavaluetext | datavalue实际显示值 | 字符 | 500 |  |  |  |  |  |  |  |
| 9 | otherparams | 扩展参数 | 字符 | 500 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/工作流程]]
- 数据库索引：[[数据库索引/weaver_wfp]]
