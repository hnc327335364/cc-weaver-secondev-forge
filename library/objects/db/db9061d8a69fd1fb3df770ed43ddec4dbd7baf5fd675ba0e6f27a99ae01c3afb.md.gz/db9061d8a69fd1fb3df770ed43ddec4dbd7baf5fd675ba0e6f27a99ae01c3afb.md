---
table_name: bcw_phraselogs_detail
cn_name: 短语日志详情表
module: 公共业务组件
database: eteams
type: 
owner: 师源
creator: 系统管理员
public_config: 0
data_id: 100655700000004313
has_fields: true
tags: [E10, 数据字典]
---

# bcw_phraselogs_detail

> 短语日志详情表

> [!info] 基本信息
> - 数据库表名：`bcw_phraselogs_detail`
> - 中文名称：短语日志详情表
> - 所属模块：公共业务组件
> - 所属数据库：`eteams`
> - 表类型：—
> - 负责人：师源
> - 创建者：系统管理员
> - 是否公共配置：0
> - 描述：短语日志详情
> - 数据ID：`100655700000004313`
> - 最后更新：2023-06-22 06:16:55

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | module_name_set | 项目名 | 字符 | 255 |  |  |  |  |  |  |  |
| 2 | old_value_id | oldValue多语言id | 长整型 |  |  |  |  |  |  |  |  |
| 3 | new_value_id | newValue多语言id | 长整型 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/公共业务组件]]
- 数据库索引：[[数据库索引/eteams]]
