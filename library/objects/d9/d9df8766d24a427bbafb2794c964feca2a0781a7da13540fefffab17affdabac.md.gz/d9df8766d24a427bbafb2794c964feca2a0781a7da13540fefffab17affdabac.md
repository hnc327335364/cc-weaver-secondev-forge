# 二维/条形码

来源快照：`result_data_new_260518.json`

- 来源 ID：`1183913125333835852`
- 模块：低代码平台e-builder
- 目录：页面引擎 - 页面设计器 - 页面组件 - 基础组件 - 基础组件_其它
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 二维/条形码

一、

## 功能背景和价值

随着信息化和自动化技术的发展，条形码与二维码作为高效、可靠的信息识别与采集手段，广泛应用于各行各业。其核心功能是将文本、数字或其他数据编码为机器可读的图形形式，便于快速扫描、识别与处理。用于生成和展示二维条形码（如 Code128、PDF417）和二维二维码（如Code128、DataMatrix）的可视化组件；常用于电子票务、信息存储等。

二、

## 功能概述

组件可切换二维码、条形码两种显示形式；

选择二维码类型时，可设置二维码类型【CODE128、DATAMATRIX】，使用CODE128类型时，扫码内容可选择自定义，链接地址，企业微信名片，微信公众号；可自定义二维码尺寸，logo图片，logo尺寸；自定义和链接地址两种方式可开启有效期设置及扫码次数限制。

选择条形码类型时，可设置条形码类型【CODE128、PDF417】，自定义扫码内容，可选择是否显示扫码内容，EB表单设计器内，可自定义组件高度，EB页面设计器内可拖拽组件宽高。

两种扫码类型均可设置无数据时是否隐藏组件。

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329666482241554&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329670700883977&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

三、

## 功能使用说明

组件配置入口：EB表单、EB页面，业务表单

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329670821249039&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 1、组件基础设置

标题、图标、启用标题，通用属性，不展开说明，都是统一的逻辑

### 2、组件基础设置（类型）

#### 2.1条形码

2.1.1条形码类型

CODE128 ：适合短数据、快速识别的场景，如商品编号、SKU。

PDF417 ：适合需要携带较多信息、有一定容错需求的场合，如证件、电子票据。

注：两种条码类型配置项一致

2.1.2扫码内容

1、不支持中文

2、可自定义扫码内容

3、可通过问号插入系统参数

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329670665125904&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

注：

1、字段相关：可用范围—业务表单、EB表单；表单内插入的自定义字段

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329675208491022&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

2、系统字段：可用范围，已对接的业务表单：流程模块

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329675114119189&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3、外部分享：可用范围—EB表单；显示前提：表单设计器后台开启外部分享

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329679414444036&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329679414444043&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.1.3 宽度、高度

EB表单：条形码高度固定为auto，宽度默认100px

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329683591970820&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

EB页面：宽高均可自行拖拽

2.1.4是否显示数据文本

均默认开启不显示数据文本，关闭后，将条形码的扫码内容展示在条形码下端

 

 

#### 2.2二维码

2.2.1二维码类型

 

CODE128：编码容量较小，数据类型仅支持ASCII字符，识读设备要求普通激光，应用场景为商品、物流、包装标签

  
 DATAMATRIX：编码容量较大，数据类型为文本、二进制等任意数据，识读设备要求为图像式扫描器或摄像头，应用场景工业、医疗、精密制造等

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329683591970840&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

 

2.2.2扫码内容

2.2.2.1CODE128

**①****、自定义**

1、可自定义扫码内容【支持中文】

2、可通过问号插入系统参数【字段相关、系统字段、外部分享与条形码——扫码内容一致，参考2.1.2】

 

**②****、链接地址**

1、地址：可自定义系统内地址，会自动补全该环境域名；可插入外部地址，但需要填写完整的url(包含http://或https://的前缀)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329688054710279&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329688040964100&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、菜单：系统内菜单列表

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329692296085510&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

3、传参方式：URL传参、隐式传参[丁嘉玲1]

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329692344320013&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

 

**③****、企业微信名片**

尺寸：表单设计器内，为整个组件宽度大小

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329692383232016&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

2、企业微信应用：该账号已绑定的企微列表【后台设置——云桥——企业微信】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329696445521924&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3、用户来源：可选择固定当前登录人，可选择指定用户【动态插入系统参数】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329696678199302&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

4、企微名片尺寸：组件容器内，名片尺寸大小

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329696683327502&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

** **

**④****、微信公众号**

四、

**微信公众号**

后台管理中心—云桥—微信公众号集成—可新建微信公众号；进入微信公众号后台，获取需要绑定的公众号APPid/APPsecret，并修改token，域名，配置好回调

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329700950204434&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

** **

** **

五、

**邀请人**

固定值：系统内固定人员

动态赋值：设置动作流，动作流返回inviter字段,无标准返回值时将使用系统管理员作为默认邀请人【该动作流在生成二维码时，便会触发设置的动作流，确定外部联系人的邀请人】

EG:动态赋值动作流内，动态获取inviter为当前用户

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329700950204444&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

** **

** **

六、

**参数设置**

参数设置中的参数将作为邀请人动态赋值及触发动作流的入参（externalEmployeeId、inviter参数名称已占用，避免使用），自定义参数名称和参数值

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329705136119812&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

** **

七、

**触发动作流**

用以执行扫码后业务逻辑，入参为参数设置中自定义参数以及扫码人员(externalEmployeeId)

八、

**上传****logo**

素材库内logo图片

九、

**logo****尺寸**

最大限制100px

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329705239707668&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

 

2.2.2.2DATAMATRIX

1、可自定义扫码内容

2、可通过问号插入系统参数

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329705136119845&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3、尺寸：自定义码的大小

2.2.3扫码限制

1、类型为二维码，且二维码类型为CODE128，扫码内容为自定义/链接地址时，才可配置扫码时间限制、扫码次数限制

2、有效期限制默认为长期有效，扫码次数限制默认关闭

3、有效期限制分为：提供一天、三天、长期有效....等默认快捷选项，也可自定义

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329709439475717&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

自定义：扫码时间限制自定义，若自定义内容为空，则无时间限制

4、扫码显示有效期：启用后，若前台扫码时未在有效期内，则扫码后页面显示有效期

5、扫码次数限制：超过限制时二维/条形码不会被删除，但扫码会显示总扫码次数已达上限，无法查看内容；自定义总扫码次数，为空时，则不限制扫码次数，可重置已扫码次数

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329709439475725&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### 3、其他

无内容时隐藏：启用后二维/条形码如果无内容则会在页面上隐藏，可能对页面排版有影响，请谨慎开启

 

## 四、使用注意点

1、EB表单流式布局内，组件默认排头显示，若需改变组件位置，可在样式设置布局及其间距

2、EB页面内为组件拖拽高度，所以页面内的尺寸设置不生效

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329709358514203&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

3、切换条码类型，自定义扫码内容会被清空

4、表单内，插入参数才可插入系统字段、表单字段，EB页面无该功能

## 五、上下游关联功能

1、表单内插入系统字段功能，仅对接了流程模块的系统字段，其他业务模块暂未对接【具体配置参考2.1.2扫码内容】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329713633779719&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2、外部共享，近支持EB表单，且需要在表单后台-外部协作-外部分享，开启统一外部分享

![](https://weapp.eteams.cn/papi/file/preview?fileId=1163329713720590352&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
