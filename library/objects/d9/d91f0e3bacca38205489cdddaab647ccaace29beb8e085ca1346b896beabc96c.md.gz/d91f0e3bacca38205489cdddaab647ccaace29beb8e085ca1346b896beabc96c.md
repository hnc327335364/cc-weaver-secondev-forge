---
title: "E10表单OpenAPI格式与结构管理风险边界"
aliases: ["FormFieldManageDto", "E10表单dataKey重命名", "E10表单OpenAPI参数"]
domain: "weaver"
category: "e10-form-backend"
note_type: "technical-reference"
status: "active"
language: "zh-CN"
summary: "区分新旧OpenAPI参数格式、明细更新删除语义、表字段自动对比和SDK结构管理，说明重命名涉及元数据、物理列与缓存的风险。"
source_path: "01-AI-Resources AI资料整理/04-Agents Agent规则/99-SourceFiles 原始资料/e-code智能化开发工具包/1.3.4/skills/e10-local-knowledge/modules/e10-form-backend-api-docs/references"
source_docs:
  - "01-AI-Resources AI资料整理/04-Agents Agent规则/99-SourceFiles 原始资料/e-code智能化开发工具包/1.3.4/skills/e10-local-knowledge/modules/e10-form-backend-api-docs/references/docs/openapi/1-表单数据--410175472819765248.md"
  - "01-AI-Resources AI资料整理/04-Agents Agent规则/99-SourceFiles 原始资料/e-code智能化开发工具包/1.3.4/skills/e10-local-knowledge/modules/e10-form-backend-api-docs/references/docs/openapi/2-表和字段--438222824805498880.md"
  - "01-AI-Resources AI资料整理/04-Agents Agent规则/99-SourceFiles 原始资料/e-code智能化开发工具包/1.3.4/skills/e10-local-knowledge/modules/e10-form-backend-api-docs/references/docs/5、物理表常用 sql--421764177665720320/5-2-修改字段列名称-表名称-dataKey--195060975383085056.md"
tags: ["weaver/e10", "type/reference", "topic/form-data", "topic/openapi", "topic/schema-change", "domain/weaver", "platform/e10"]
retrieval_terms: ["autoCompare", "delRowIds", "subFormMatchFields", "seniorFormParam", "checkDataMap", "checkAndCreateFormData", "FormTrashService", "重命名", "dataKey", "getRelateDataInfo"]
source_type: "本地归档正文及API记录核读"
confidence: "medium"
product_line: "E10"
tech_scene: "OpenAPI参数与表字段结构管理"
capability_module: "form-backend-api"
artifact_type: "knowledge-page"
---

# E10表单OpenAPI格式与结构管理风险边界

## 来源与使用方式

本页处理数据格式与结构变更边界，不提供可直接执行的生产改表脚本。来源编号对应 [[E10表单后端续补来源核对-20261023.json]] 的 `source_id`，内含精确库内相对路径、SHA-256、行数和完整阅读范围。相关正文没有统一最低产品版本；示例中出现类名并不证明客户已部署相同重载。

| 编号 | 原文与范围 |
|---|---|
| F014 / F049 | 《2.2、表单字段》1125行 / `openapi/2、表和字段`1131行；高度重复的表字段结构与属性字典 |
| F025 / F026 | FormAPIService 666行 / FormTrashService 139行；表单与物理附属表管理、回收站 |
| F027 / F029 | FormFieldAPIService 966行 / FormLayoutVersionApiService 184行；字段、选项和布局补充 |
| F040 | 《5.2、修改字段列名称、表名称、dataKey》654行；六类数据库示例 |
| F048 | `openapi/1、表单数据`1138行；DTO、新旧校验格式与明细操作 |
| FA001 | `form-dubbo-getrelatedatainfo-077.json`95行；workflow 浏览数据名称查询 |

## OpenAPI 示例是参数结构，不是完整 HTTP 合同

F048 第 6–22 行说明 `FormDataDtoParam` 可用于创建/提交流程、创建/更新 EB；创建流程的 `seniorFormParam` 对应 `formDataDtos` **外层**参数。该页没有统一请求 URL、请求头、鉴权、错误码或业务权限定义，因此不能凭“OpenAPI”目录生成可直接调用的通用端点。

新 DTO 使用 formId、formDataDtos[]，单条含 dataId/objectId/dataDetails。传 dataId 走更新，objectId 代表 requestId 等业务 ID（附件复制场景需要）；外层的 execMonitor、execRelate、validate、needValidateInfo、needDefaultValue 有各自作用，不能统称“自动执行业务逻辑”。保存校验及默认值规则参见 [[E10表单SDK数据保存校验与导入导出契约]]。

### 组件格式必须按类型选择

| 类型 | 来源样例的实际格式 | 行段 |
|---|---|---|
| 普通文本、金额 | content 字符串，币种可放 extendParams.moneyType | F048 40–54 |
| 地区、级联 | dataOptions 内 optionId 可为完整层级 ID 路径；不同路径是不同选项 | 55–98、330–339 |
| 附件 | 已有 ID；或 uploadParam（loadUrl/base64Url）；也列 fileByte/fileUrl 旧式 | 99–147；上传大小/授权/超时需文档服务合同，空 byte[] 不是有效文件 |
| 多语言 | content 当前语言；contentObj.formDataMultiLangSet 同时多个 langId/value | 211–236 |
| 人员组织多选 | type 使用 resource/department/subcompany | 238–254 |
| 人员范围选择 | type 使用 user/dept/subcompany | 255–270；不能与上行统一替换 |
| 日期区间 | 分别传开始、结束**子字段 ID**，不是复合组件 ID | 318–329 |
| 明细 | 同一行各字段共享 dataIndex，按 subFormId 或 subFormDataKey 定位 | 369–418；已有行另需真实 rowId |

附件 URL 只说明支持某种输入形式，不授权抓取任意内网地址，也不保证复制/上传与业务保存同事务。各类示例包含注释、尾逗号及未定义数据，不能直接作为严格 JSON。

### 明细覆盖与删除是显式破坏性操作

`subFormMatchFields[subFormId].cover`：true 覆盖、false 追加、null 不处理；dataKey 方式对应 subFormDataKeyMatchFields（F048 425–495）。更新/删除特殊明细操作的示例要求传相应匹配对象，即使它是空对象（498–505）。

`delRowIds` 每项含 dataId、subFormId、rowId。**第 516 行明确：不传 rowId 则删除该明细表全部数据。** 因此不能在行 ID 解析失败时自动丢弃该字段后继续请求；应停止并核对准确目标。

“覆盖明细而不变更 rowId”章节 551–555、“按字段条件更新明细”章节 600–606 均仍在完善中且没有样例；不能把标题当已完成合同。按主表字段条件更新样例 557–598 使用 noMatch=ZERO、matchMore=ALL，是样例选择，不是安全默认策略。

## 旧校验 Map 与新结构不能混装

| 方法 | 已知输入与结果 | 边界 |
|---|---|---|
| `OpenFormDataVerifyService#checkDataMap` | result、dataId、formId、FormLayoutVersion、user、dataMap、fieldReads、module；成功 result.formdata，失败 result.message | F048 968–1008；以 fieldId 为键，老格式用 `_*` 分隔明细行，部分选项以名称表示 |
| `checkDataMapByDataKey` | 同上但字段键为 dataKey | 1010–1045；不是替换所有字段 ID 后就能兼容所有新 DTO |
| `checkDataJson` | 数据参数改为 jsonStr | 1047–1068；样例空白，不补造 jsonStr 形状 |
| `checkAndCreateFormData` | jsonStr 示例含 dataMap.dataDetails | 1070–1138；使用 fieldValue、subDetail，不是 DTO 的 content/dataOptions |

旧接口参数表名为 `fieldReads`，样例写 `fieldRead`，需核实真实调用包装。`checkAndCreateFormData` 名称中的 Create 不能仅凭该参数页判定是否已持久化；来源未说明其事务与后续保存边界。

## 表与字段管理：autoCompare 不是局部补丁

F049 第 6–44 行给出 `FormFieldManageDto`（`weaver-common-form-bean`），并明确只有部分业务模块支持。主要结构是 form、formTableList、subFormList、formFieldList、module。

- form/formTableList/subFormList.dataKey：来源写不超过 30 位数字、字母、下划线；字段 dataKey 不超过 20 位。它们是该合同说明，不能用其他页面的可配置长度上限覆盖所有数据库和接口。
- subFormDataKey 指明细表；mainDataKey 指多物理表；未传按主表处理。dataKey、物理 columnName、表名及显示标题是不同身份。
- 选项使用 options.name/valueKey，父级用 parentDataKey/parentOptionIds；日期需 format，自定义浏览需 browserType（原文指向标准浏览配置获取入口）。必填属性应按组件类型而非一个通用 Map 处理。
- `autoCompare=true` 且表已存在时，**未传字段会删除**，已传字段比对后新增或覆盖。只想改一个字段时不能用不完整列表打开该开关。

F014 12–40 与 F049 16–44 是重叠说明；1125/1131 行不代表两套新增能力。属性字典列出了 File/Image、Money/Number、员工范围、日期、富文本等属性名，但不等于完整类型、默认值、校验和后端权限合同。例如 single 与 isSingle 表述不同、数字示例 maxNum=1/minNum=100 相反，均需校核。

## SDK 管理补充：区分修改、删除和权限读取

F025 第 12–102、262–301 行区分 saveForm、buildForm、createFormAndInitFormLayout；后两者会初始化布局。updateForm（339–382）声明传哪些属性更新哪些，不能套用 autoCompare 的删除语义。completelyDeleteForm（384–413）将 IS_DELETE 置为 2，但是否立即删除物理数据不是本段保证。

多物理附属表提供 listFormTable、saveFormTable、deleteFormTable、batchUpdateFormTable、findAllFormTableName（F025 451–666）。saveFormTable 的 formTable 包含 form.id/tableName/tableType，且 module 必需；修改附属表显示名不是通用数据库物理表重命名入口。相同 formId 可能对应不同 tableName，不能只按 formId 选定一个物理表。

F026 第 10–107 行的回收站扩展先调用 super，再按返回 formIds 排除已处理项，执行业务自己的逻辑；示例缺 return、引用未定义变量，恢复段甚至残留删除说明，不能照抄上线。彻底删除与还原要分别实现并校验目标；分页回收站 `pageForms`（109–139）说明暂不支持国际化，参数表为 module，样例却是 type/formId，需核对实际 DTO。

F027 第 195–265 行区分按权限集合取可读字段、按单个权限取可写字段；字段 ID 不能当权限 ID。`listSimpleFormFields` 第 571–610 行默认查询删除状态 0/1，默认不过滤加密和脱敏字段，不是安全导出的自动筛选器；返回不含 formId，明细名称支持说明与 needSubFormTitle 参数存在差异，按当前依赖确认。

F027 标题 FormFieldAPIService、开头却写 FormAPIService；F029 标题 FormLayoutVersionApiService、正文实际是 FormLayout 读取及权限重置，不凭标题构造额外版本 API。后者 resetFormLayoutByFormIdAndPermissionIds 为 void，将权限放入布局用于展示；权限集合必须由可信后端上下文推导，不信任前端自报 ID。相关布局实践见 [[E10表单元数据布局与模块字段接入实践]]。

FA001 记录 `BusinessRest#getRelateDataInfo(SearchRelateEntity,SimpleEmployee)`，group workflow，服务 `weaver-workflow-core-service`，最低基线 `10.0.2307.00`，两参必填，返回浏览数据 Map。其请求/响应/代码示例均 `{}`，没有新增通用浏览 HTTP 合同；须结合对应业务模块正文，不能凭 Map 反推键结构。

## 重命名是元数据、物理结构与缓存的一致性操作

F040 第 6 行首先警告直接 SQL 修改风险；正文分别列 MySQL 8–114、Oracle 116–222、PG 224–330、DM 332–438、ST 440–546、SQL Server（原文拼作 sqlservre）548–654。重复结构是数据库适配示例，不是六份独立功能。

共同链路包括：核对字段类型和物理表 → form_field.data_key 与 other_properties 中 dataKey/columnName → form_table_field.column_name → 真实物理列 → 必要的 complex_field 与附属列 → 缓存刷新。共享表主要改 dataKey，不能盲目执行物理列 DDL。

| 对象 | 必须核对的关联 |
|---|---|
| 日期区间、矩阵等复合字段 | complex_id、多个子字段及 `_0/_1/...`、complex_field.other_properties |
| 附属列 | 选项/人员等 `_obj`、金额 `_cur`、地理位置 long/lat；以实际元数据为准，不凭类型名称生成所有后缀 |
| 主表名 | form_table.table_name 与物理表；多物理表须精确区分，不直接按 formId 批量改全部 |
| 明细表名 | sub_form.data_key/other_properties、form_table、物理表名称 |
| 缓存 | 文档建议表单基础设置保存或未改字段重新保存；不能证明其他业务模块缓存和外部引用自动更新 |

原文 REPLACE 依赖 JSON 的精确空格和文本格式；多个明细表替换示例还把匹配片段中的 `,"title"` 一起替掉，可能破坏 JSON。ST 示例 `alter table 旧表名 to 新表名` 缺少明确重命名关键字；SQL Server 示例也没有细化对象类型。这些都不能生成“已验证可执行脚本”。

实施需另行确认数据库版本、精确对象与租户范围、引用扫描、备份恢复、DDL 事务特性和缓存/业务回归；SQL 成功不等于产品可正常读写。此处仅整理原始材料，不执行任何 SQL。其他结构调整限制见 [[E10表单结构调整与数据源查询边界]]。

## 验证状态

本页与 SDK 数据页共同消化分派的 12 篇正文 8958 行及 FA001 95 行；重复段仍全文核读，但不折算为功能量。没有读取远端链接、运行原脚本、修改数据库或调用客户服务；未提供的接口细节与产品版本保持待确认。
