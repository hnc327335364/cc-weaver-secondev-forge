# 流程流转设置—显示布局

来源快照：`result_data_new_260518.json`

- 来源 ID：`1968360407136205308`
- 模块：低代码平台e-builder
- 目录：专题学习 - 功能点专题 - 流程设计
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

**1.  ****场景说明  **  


在实际业务场景中，流程流转至各节点所展示的布局样式往往是不同的，例如在员工经费报销审批时，员工填写经费报销单并发起流程后，上级节点需要填写审批意见，财务节点需要填写实际核销金额，各节点展示的布局样式、表单字段以及字段的读写属性等都会有所差别。

展示效果如下：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707696017375239&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

** **

**2.  ****功能简介**  

上述场景可以通过【表单视图】搭配【流程节点-显示布局】实现。用户可根据各节点需要展示出的字段以及字段读写属性的不同，创建多个不同的表单视图，并在流程-流转设置-节点显示布局中进行布局设置，关联对应的表单视图。同时可以对节点的字段权限进行设置，便可以实现各流程节点展示不同的布局样式。

 

**3.  ****操作说明**  

1.新建表单视图

进入后台管理-表单-视图-新建表单视图，设置视图名称、布局形式、布局类型等，如下图所示：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707696017375263&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

在该场景中，我们需要设置三个视图，分别对应三个节点：员工申请、领导审批、财务批复，需要注意的是，我们在创建表单时，表单会自动生成一个默认视图，用户可以使用该视图，或者重新创建新的表单视图。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707700259332120&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

此外，还可以直接复制视图，这样就能保存视图中的布局字段等，帮助用户更加快捷的创建视图：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707700259332140&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

创建完表单视图后，我们可以对视图内的内容进行设置，按照场景需求，我们可以对各节点进行配置，各节点字段的读写属性（显示、编辑、必填）都可以单独设置，各节点内重复字段也可以在已有字段里直接找到并拖拽使用。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707704555036693&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.配置流程显示布局

首先新建流程-关联该表单，注意eb的流程表单与表单是一体的：表单没有关联流程，就当普通的台账表单使用，记录信息数据；表单关联了流程，那么表单的新建并保存就是流程的发起节点。

之后点击流程-更多-流转设置，配置节点操作者并设置显示布局，分别设置各节点显示布局对应各个表单视图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707704733139038&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

注意点：

①   除了发起节点和结束节点之外，其他节点若是需要修改表单数据，则需要打开允许修改流程表单内容

②   若不设置布局，则该节点自动显示该表单的默认视图

③   若发起节点不是表单的默认视图，需要单独设置视图，则不仅需要在流程节点设置显示布局，还需要在表单-创建权限处设置表单布局视图。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707704555036800&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3.效果展示：

如图所示，不同节点展示不同的布局样式：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707708877111305&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157707717439938636&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
