---
table_name: edc_reportdsorderby_dev
cn_name: 报表数据集排序字段
module: e-Builder报表
database: edcreportdev
type: 普通表
owner: 张健
creator: 田小斌
public_config: 0
data_id: 1231916763658281008
has_fields: true
tags: [E10, 数据字典]
---

# edc_reportdsorderby_dev

> 报表数据集排序字段

> [!info] 基本信息
> - 数据库表名：`edc_reportdsorderby_dev`
> - 中文名称：报表数据集排序字段
> - 所属模块：e-Builder报表
> - 所属数据库：`edcreportdev`
> - 表类型：普通表
> - 负责人：张健
> - 创建者：田小斌
> - 是否公共配置：0
> - 描述：报表数据集排序字段
> - 数据ID：`1231916763658281008`
> - 最后更新：2026-02-02 18:26:13

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | dataset_id | 数据集id | 长整型 |  |  |  |  | 0 |  |  |  |
| 8 | name_index | name_index | 字符 | 1000 |  |  |  |  |  |  |  |
| 9 | f_name | 数据集字段 | 字符 | 1000 |  |  |  |  |  |  | 数据库实际字段name |
| 10 | f_text | text | 字符 | 1000 |  |  |  |  |  |  | 数据库实际字段text |
| 11 | order_type | 排序方式 | 字符 | 10 |  |  |  |  |  |  |  |
| 12 | display_type | display_type | 字符 | 100 |  |  |  |  |  |  |  |
| 13 | browser_type | browser_type | 大字段3 |  |  |  |  |  |  |  |  |
| 14 | select_options | select_options | 大字段3 |  |  |  |  |  |  |  |  |
| 15 | agg_type | agg_type | 字符 | 20 |  |  |  |  |  |  |  |
| 16 | qfw_switch | qfw_switch | 字符 | 10 |  |  |  |  |  |  |  |
| 17 | is_agg | is_agg | 字符 | 10 |  |  |  |  |  |  |  |
| 18 | f_priority | priority | 整型 |  |  |  |  | 0 |  |  | 数据库实际字段priority |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder报表]]
- 数据库索引：[[数据库索引/edcreportdev]]
