# 共享范围

来源快照：`result_data_new_260518.json`

- 来源 ID：`1177710088881430600`
- 模块：集成中心
- 目录：统一认证中心 - 后台管理配置 - 认证应用管理
- space ID：`1158011075224911873`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能介绍

本文件旨在介绍统一认证应用访问控制的共享范围，能够对人员认证应用的权限进行有效控制。

# 二、功能概述以及使用说明

## 1、共享范围配置说明

进入认证应用管理/应用设置-共享范围页面，可对认证应用的用户权限进行维护，从而确定哪些用户可以使用该应用进行认证授权登录。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1177724446974033932&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 2、共享范围功能说明

当业务系统通过 CAS/OAuth/OIDC/SAML 协议进行认证授权登录时，若当前登录人员处于所属认证应用的共享范围内，则授权可通过，系统将回调并登录业务系统；若不在共享范围内，则授权失败，系统将跳转至提示页面，显示“登录用户不在认证应用注册的适用对象范围内，请联系管理员检查配置”。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1177724446834253831&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
