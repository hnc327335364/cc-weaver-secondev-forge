# 生成JSON、XML文本

来源快照：`result_data_new_260518.json`

- 来源 ID：`1179911732066484602`
- 模块：低代码平台e-builder
- 目录：动作流 - 执行组件 - 数据操作 - 更多数据操作 - 综合
- space ID：`1157961794811633670`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能介绍

新增【生成JOSN/XML文本】组件，可自定义参数生成标准的JSON或XML格式的数据

![](https://weapp.eteams.cn/papi/file/preview?fileId=1179912088669741062&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

 

# 二、使用说明

1、数据类型：默认为JSON，也可选择XML格式，即需要生成的数据必须为JOSN或者XML格式的才可以

2、结构设置：根据需要生成的数据，按照标准的JSON/XML格式在设置中添加对应参数，后续组件可在上下文中获取到生成的JOSN或者XML数据

 

# 三、场景案例

**场景案例：**

当需要将第三方接口的param中的参数转成JOSN格式传给另一个组件时，由于直接获取三方接口的上下文无法获取到param参数的JOSN格式，只能获取对应值，所以需要使用【生成JOSN/XML文本】组件将param参数转成JOSN格式

**前提：** 三方接口的上下文，获取获取是无法获取到param参数的JOSN格式

![](https://weapp.eteams.cn/papi/file/preview?fileId=1179912668235841544&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

**实现方式：** 可在三方接口下面加个【生成JOSN/XML文本】组件，选择JOSN格式，根据需要的参数进行配置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1179912865941880839&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1179912904503279620&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

# 四、常见问题
