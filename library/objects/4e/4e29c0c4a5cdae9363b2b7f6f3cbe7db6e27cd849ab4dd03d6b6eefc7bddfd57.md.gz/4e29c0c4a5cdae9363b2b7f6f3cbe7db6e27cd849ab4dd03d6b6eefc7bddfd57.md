**简要描述：** 

- 获取eb表单列表

**请求URL：** 
- pc : `{host}/api/my/wait/getEbFormList`

  
**请求方式：**
- POST   http payload




 **返回示例**

``` 
{
    "code": 200,
    "msg": "查询成功",
    "status": true,
    "data": {
    
        "data": [
            {
                "formId": "666664",
                "formName": "1"
            
            }
         
        ]
    }
}
```

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|formId |string   |表单id  |
|formName |string   |表单名称  |




 **备注** 

- 更多返回错误代码请看首页的错误代码描述
