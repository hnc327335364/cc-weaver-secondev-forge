# 第三方预览编辑插件集成说明

来源快照：`result_data_new_260518.json`

- 来源 ID：`1267110709363777587`
- 模块：文件设置
- 目录：预览编辑设置
- space ID：`1160193825049370641`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# **写在前面，很重要，必看！！！**

1.

各插件功能统计及支持的文件格式清单 [_E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

2.

WPS，福昕，永中服务部署（自己部署或者第三方部署）请走 “WPS、永中预览编辑服务及福昕产品部署申请流程”

3.

WPS配置使用常见问题解决方法 [_E10 WPS问题解决方法（更新中……）_](https://www.kdocs.cn/l/ciOXPjiWLdhS) ；其他插件配置使用问题解决方法[ _E10预览编辑问题解决方法（更新中……）_](https://www.kdocs.cn/l/clnYqcGOejcN) ；其他问题 [_点击进入E10问答_](https://www.e-cology.com.cn/sp/ebdpage/view/977607425199128633/page/977607425199128633?cid=874152414695915520&uid=732847508265385987)

4.

默认插件为系统自带可免费使用（**文件预览/编辑效果在格式上会和本地打开有差异，无法解决，若客户介意建议采购第三方预览/编辑服务** ），其他都需要采购。金格2003，2009等低版本不再支持；wps中台v5以下版本不再支持

5.

预览和编辑使用不同的厂商产品是可以的。例如预览用wps编辑用永中，预览用wps编辑用金格2015，等等...

**若文档未解决您的问题，请em联系****张坤鹏****协助**

一、

# **插件与OA集成配置方法**

## **1.1 私有化客户插件集成步骤**

**插件的****集成步骤都一样****，下面以****wps中台为例****详细说明（****下面步骤说明请务必认真细心每一行都确认无误，每一项都很重要****）**

### **第1步 获取要集成的插件信息**

插件服务地址（eg：[https://wps.ec****.cn）**一定要保证oa服务器能正常访问填写的插件服务地址**](https://wps.ec****.cn）一定要保证oa服务器能正常访问填写的插件服务地址)

服务版本（eg：v6）

应用包名AK（eg：XED01VUM7X5*****）

应用密钥SK（eg：i6yMD3Unl3Q0ITP3ajHqZtWHPH6*****）

**WPS插件信息获取方法及配置参考1.2.1章，****其他插件所需配置信息参考第1.2章；插件为第三方厂商部署，插件信息不确定的可咨询厂商部署人员**  
---  
  
### **第2步  租户管理平台新建插件**

登录租户管理平台（oa地址/tenant/login）选择租户管理－〉预览编辑设置（系统插件设置）－〉新建插件

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267111679870951428&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267111709944111107&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

插件功能（可应用于）默认选中插件支持的所有功能，可根据采购的授权和客户业务场景自行勾选要使用的功能；文件格式支持默认配置插件所支持的所有格式，可根据业务场景删掉部分格式，不可增加格式（增加也没用��  
---  
  
### **第3步 OA后台设置使用优先级**

登录OA 选择后台管理中心－〉所有服务－〉文件设置－〉预览编辑设置（文件插件）  可进行插件的应用范围和插件预览，编辑，格式处理功能优先级设置

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112513086824451&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

设置插件预览编辑功能的人员使用范围：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112620586835984&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

设置预览编辑功能插件使用的默认优先级：

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112702291271686&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

插件应用范围若不设置则默认所有用户可用；应用范围设置只限制预览和编辑功能  
---  
  
### **  其他说明**

1.

插件相关问题公司内部沟通交流群，如有其他问题可以在群里反馈

 

## **1.2 插件集成详细说明**

### **1.2.1 WPS中台**

**插件功能简介：** 需本地部署wps中台服务；支持文档预览/编辑/协同编辑；支持公文清稿套红等功能

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：** 支持wps中台服务v5/v6/v7版本

**OA版本支持：****基线2308.01及以上版本**

**其他说明** ：

1.

如果仅采购了wps的预览授权，除编辑功能不可用其他功能一般都包含的，都可使用

**需要配置信息：**

1.

插件服务地址（wps服务地址，如果有二级路径带上二级路径。eg：[http://192.0.2.10:80）**一定要保证E10的weaver-file-online服务所在的服务器能正常访问填写的插件服务地址**](http://192.0.2.10:80）一定要保证E10的weaver-file-online服务所在的服务器能正常访问填写的插件服务地址)

 _注：例如wps后台登录地址为_[ _https://wps.ecology.cn/micsweb/sys/login，/micsweb/sys/login前面部分_](https://wps.ecology.cn/micsweb/sys/login，/micsweb/sys/login前面部分) __[_https://wps.ecology.cn为插件服务地址）_](https://wps.ecology.cn为插件服务地址）)

 _例如wps应用管理平台地址为_[ _https://wps.ecology.cn/c/manage/#/login，/c/manage/#/login前面部分https://wps.ecology.cn为插件服务地址）_](https://wps.ecology.cn/c/manage/#/login，/c/manage/#/login前面部分https://wps.ecology.cn为插件服务地址）)

2.

插件服务版本（eg：v7）

3.

应用包名AK（eg：XED01VUM7X5*****）

4.

应用密钥SK（eg：i6yMD3Unl3Q0ITP3ajHqZtWHPH6*****）

**功能更新：**

**2602.01基线** 文件下载加图片水印支持设置水印图片缩放比列

**2510.01基线** 格式转换集成 增加其他格式（doc,dot,wps,wpt,dotx,docm,dotm,rtf,uot,mht,mhtml,htm,html,xml）文件转docx格式

#### **V7版本WPS配置说明**

1.

登录**wps系统后台** （wps地址/micsweb/sys/login）－〉配置管理－〉Office组件配置 找到**极速预览禁用token验证** 这个开关然后关闭掉

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112800862150658&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.

登录**wps应用管理平台** （wps地址/c/manage/#/login）－〉应用中心－〉集成管理 点击应用名称 （如果授权后没有应用点击上面创建应用按钮新建一个）

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112843841560583&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3.

应用详情－〉基础信息 获取应用包名（应用AK）和应用密钥（应用SK）

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112886803439616&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

4.

应用详情－〉应用授权 将授权状态全部开启 选择在线编辑或在线预览 点击预览编辑配置 配置回调域名。回调域名为：｛**oa地址** ｝/papi/file/wps/metadata **此地址为wps与oa服务器端交互使用，一定要保证wps服务器可以访问这个地址 且 仅需要wps服务器能访问通这个地址即可**

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112916838916106&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112955531304970&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

5.

配置管理－〉跨域白名单（**不是IP白名单设置，IP白名单请勿设置** ） 增加oa地址（oa有多个访问地址的话每个都加进去；eg：oa地址[https://www.e-cology.com.cn/](https://www.e-cology.com.cn/)  新增 [www.e-cology.com.cn](http://www.e-cology.com.cn)） **不要带http和端口**

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267112985638019076&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

#### **V6版本WPS配置说明**

1\. 

登录wps应用管理平台－〉应用中心－〉应用管理 点击分类为集成应用的应用 点击应用名称

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113019934908427&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2\. 

应用详情－〉基础信息 获取应用包名和应用密钥

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113058573148169&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3\. 

应用详情－〉应用依赖 选择在线编辑或在线预览 点击预览编辑配置 配置回调域名。回调域名为：｛oa地址｝/papi/file/wps/metadata**此地址为wps与oa交互地址一定要保证wps服务器可以访问这个地址**

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113084367806471&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113174730203142&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

4\. 

系统设置－〉跨域白名单（**不是IP白名单设置** ） 增加OA域名（eg：oa地址[https://www.e-cology.com.cn/](https://www.e-cology.com.cn/)  新增 [www.e-cology.com.cn](http://www.e-cology.com.cn)）**不要带http和端口**

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113213401374722&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

#### **V5版本WPS配置说明**

1.

登录wps开放平台－〉管理中心－〉创建应用 创建后保存 点击详情获取应用包名和应用密钥

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113239045660676&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.

权限申请，申请预览/编辑/内容处理权限

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113273358884867&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3.

配置证书回调和申请权限，配置后设置预览和编辑回调接口。回调域名为：｛oa地址｝/papi/file/wps/metadata**此地址为wps与oa交互地址一定要保证wps服务器可以访问这个域名**

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113307655774215&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113376501080069&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

4.

基本信息－〉跨域白名单（（**不是IP白名单设置** ）） 增加oa域名（eg：oa地址[https://www.e-cology.com.cn/](https://www.e-cology.com.cn/)  新增 [www.e-cology.com.cn](http://www.e-cology.com.cn)）**不要带http和端口**

 

![](https://weapp.eteams.cn/papi/file/preview?fileId=1267113406628700179&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

### **1.2.2 WPS公有云（open）**

**插件功能简介：** 无需本地部署wps服务（老版本的wps公有云）；支持预览/编辑/协同编辑文档

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持** ：[ _WPS 开放平台_](https://open.wps.cn/)

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

应用包名（eg：XED01VUM7X5*****）

2.

应用密钥（eg：i6yMD3Unl3Q0ITP3ajHqZtWHPH6*****）

### **1.2.3 WPS公有云（solution）**

**插件功能简介：** 无需本地部署wps服务（新版本的wps公有云）；支持文档预览/编辑/协同编辑

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：**[** _WPS WebOffice 开放平台-文档在线预览编辑-文档格式转换_**](https://solution.wps.cn)

**OA版本支持：****基线2501.01及以上版本**

**需要配置信息：**

1.

预览编辑AppID（eg：SX20241206****SC）

2.

格式处理AppID（eg：SX20241224****SO）

3.

格式处理AppSecret（eg：dOlGDhQLxFLHolpqKhpPOMfeFy****Os）

**其他说明** ：

1.

回调网关设置为：｛oa域名｝/papi/file/solution/wps（一定要保证此地址通外网）；文档编辑选择三阶段保存；回调接口全部开启

2.

AppID前往应用管理创建应用获取，[ _WPS WebOffice开放平台_](https://solution.wps.cn/console/manage)

3.

不支持公文的清稿，套红场景

### **1.2.4 WPS客户端**

**插件功能简介：** 无需安装第三方服务；支持唤起本地wps客户端预览/编辑文件

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**其他说明** ：

1.

仅支持信创客户端使用

### **1.2.5 WPS加载项**

**插件功能简介：** 无需安装第三方服务；支持唤起本地wps客户端预览/编辑文件

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**客户端版本支持：** WPS客户端（专业版）

**OA版本支持：****基线2503.01及以上版本**

**其他说明** ：

1.

仅支持Windows和信创客户端环境使用

### **1.2.6 WPS Office移动增强版**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**客户端版本支持：** 无需部署第三方服务，支持唤起移动端wps客户端预览/编辑文件

**OA版本支持：****基线2508.01及以上版本**

**其他说明：**

1.

仅支持在移动端EMobile中使用

2.

插件请在oa后台 文件设置->预览编辑设置页面右上角新建，新建后应用范围设定需要使用的人员

3.

安卓安装包[ _点击下载_](https://emobilefile.weaver.com.cn/customer/wpspro/moffice_13.11.0_2052_Pro.apk)  ；ios直接去苹果商店下载WPS Office

### **1.2.7 福昕转换服务（GSDK）**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（福昕转换服务地址：eg：[https://convert.****.net/gsdk-service，gsdk服务地址一般以/gsdk-service结尾）](https://convert.****.net/gsdk-service，gsdk服务地址一般以/gsdk-service结尾）)

### **1.2.8 福昕云阅读**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（福昕版式文件预览地址）（eg：[https://fuxinread/viewer](https://fuxinread/viewer) 服务地址一般以/viewer结尾）

2.

福昕office服务地址（福昕流式文件预览地址）（eg：[http://192.0.2.10:80）](http://192.0.2.10:80）)

### **1.2.9  福昕阅读器**

**插件功能简介：** 无需安装第三方服务；支持唤起客户端福昕软件预览/编辑文件

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**其他说明** ：

1.

仅支持信创客户端环境使用

**功能更新：**

**2506.01基线** 支持在线编辑

### **1.2.10 永中FCS（DCS）**

**插件功能简介：** 需本地部署永中预览服务；支持文件预览；支持公文清稿套红功能

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：** 支持永中4.1+版本

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（永中的预览服务地址，eg：[http://192.0.2.10:8088/fcscloud](http://192.0.2.10:8088/fcscloud) 服务地址一般以/fcscloud结尾）

2.

插件服务文件目录（eg：D://yozofcs//input// 此目录为fcs服务文件的磁盘路径），此目录地址对应E9的\weaver\ecology\WEB-INF\prop\doc_yozo_for_[weaver.properties](http://weaver.properties)配置文件中的dcsinputurl设置项的值

**其他说明：**

1.

调用永中预览pdf文件convertType=20；预览ofd文件convertType=21；预览office文档convertType=42；压缩包convertType=19。如需修改预览模式可在配置页面高级设置中设置

**功能更新：**

**2510.01基线** 增加word文档痕迹显示设置功能

oa租户后台永中设置页面的高级设置增加“word预览修订显示”设置项，可全局设置是否显示修订痕迹

### **1.2.11 永中WebOffice**

**插件功能简介：** 需本地部署永中编辑服务；支持文件编辑/协同编辑

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：** 支持WebOffice服务3.3，3.4版本

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（永中的编辑服务地址，eg：[http://192.0.2.10:18080）](http://192.0.2.10:18080）)

**其他说明：**

1.

需保证oa地址和永中编辑服务地址同域才能正常调用永中jsSdk保存文件。例如：oa地址为：[https://weapp.yunteams.cn](https://weapp.yunteams.cn) 那就把永中编辑服务地址代理为[https://weapp.yunteams.cn/yozooffice](https://weapp.yunteams.cn/yozooffice)

**功能更新：**

**2506.01基线** 支持协同编辑

永中服务版本需满足Excel（3.4.3及以上版本）；PPT（3.4.4及以上版本）；Word（3.4.5及以上版本）

由于永中协同编辑有版本限制，系统中是默认关闭的。如果满足以上版本可修改配置文件开启。[修改weaver-file-service.properties](http://修改weaver-file-service.properties)配置文件，增加一行yozo.webOffice.collaborative.documents=true。

### **1.2.12 数科转换服务  **

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（eg：[http://192.0.2.10:8090）](http://192.0.2.10:8090）)

### **1.2.13 数科轻阅读**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：** 支持3.0+版本

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（eg：[http://192.0.2.10:8081/reader）](http://192.0.2.10:8081/reader）)

**功能更新：**

**2511.01基线** 预览文件支持文字水印

### **1.2.14数科阅读器**

**插件功能简介：** 无需安装第三方服务；支持唤起客户端数科软件预览/编辑文件

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**其他说明** ：

1.

仅支持信创客户端环境使用

**功能更新：**

**2506.01基线** 支持在线编辑

### **1.2.15 金格iWebOffice**

**插件功能简介：** 无需部署服务，需用户客户端安装金格控件；支持文件预览/编辑；支持公文清稿套红

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**金格版本支持：** 支持金格2015，v12版本，2003，2009等低版本不再支持

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

授权码（eg：泛微网络科技股份有限公司[开发版专用];V5.0S0xGAAEAAAAAAAAAEAAAAMYBAADQAQAALAAAAKkUdUON2WZMFlq1iX620K+2MOCGAznU8qA...）[这个授权码是过期的，点击获取[ _最新授权码_](https://www.e-cology.com.cn/sp/file/filePreview/1163215583538806819) （授权码不要直接在线复制，文件下载到本地复制），若授权码不可用联系代娟娟获取最新授权码]

**其他说明** ：

1.

仅windows pc客户端支持使用金格插件

2.

支持IE浏览器，360浏览器（极速或者兼容都可以），谷歌浏览器；

3.

金格控件客户端安装方法：

1.

下载安装包：[ _金格控件和chrome（106版本）浏览器安装包_](https://www.e-cology.com.cn/sp/doc/docShare/938655490562064393?tenantKey=t7akvdnf84)

2.

本地安装金格插件。下载到本地后双击安装，或者右键用管理员身份运行安装

3.

本地要安装办公软件（微软office、金山wps、永中office都可以，但家庭学生版、教育版、个人版这些不支持）

**功能更新：**

**基线2506.01** 支持设置金格iWebOffice的版本（2015和v12）

v12版本的授权兼容2015版本的授权，在配置前请确认自己拿到的授权版本。（上面公司提供的试用授权为v12版本授权）

**金格iWebOfficeV12：**

最新版本的 _chrome浏览器也支持嵌入到OA的页面中使用！_

**金格iWebOffice2015：**

 _        iweboffice2015插件，是基于chrome的PPAPI技术开发的插件，107之前版本的chrome浏览器支持PPAPI的方式实现插件。从107版本开始，chrome基于安全原因，终止了对于PPAPI接口的支持，因此从chrome107版本开始，无法再支持iweboffice2015插件嵌入到OA的页面中使用。_

 _替代的方案：             1.一直使用低于107版本的chrome浏览器，关掉自动更新功能             2.使用高于107版本的浏览器，通过打开一个新的软件窗口（金格提供的中间件，这个中间件本质上是个低版本的chrome内核浏览器），可以在新的窗口中在线编辑文件，体验性跟嵌入到原页面中显示有很大的不同_

金格iWebOffice2015在高版本chrome（版本号：107+）浏览器使用配置方法**（2409.01及以上基线版本不用配置）**

1.

后台管理中心－〉开放平台－〉应用管理－〉新建应用（选择第三方免登eteams）－〉提交审核

 

2.

应用审核完成后查看应用获取app_key和app_secret

 

3.

如果是组合部署登录nacos，如果是单体服务进入WEB-INF/classes/weaver/config/config-center/目录。[修改weaver-file-service.properties](http://修改weaver-file-service.properties)配置文件。增加以下配置项：

配置规则：[file.online](http://file.online).kinggrid.openApi[#{租户key}]=#{app_key},#{app_secret}

1 

#高版本chrome浏览器使用金格2015免登录金格浏览器 租户开放平台配置

2 

#{"type":"env", "value":""

3 

[file.online](http://file.online).kinggrid.openApi[ta5wskkpzz]=4915b63a0ae7b64fd34c3ccc2b9fddca,945c5e8c69d651290966d7a986a488e5

### **1.2.16 Microsoft365**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2408.01及以上版本**

**其他说明：**

1.

**需要购买MIcrosoft 365 企业版 E3/E5版本（**[** _https://www.microsoft.com/en-us/microsoft-365/enterprise/microsoft365-plans-and-pricing_ ）**](https://www.microsoft.com/en-us/microsoft-365/enterprise/microsoft365-plans-and-pricing）)

2.

需要**配置OA公网域名地址（需要是HTTPS）** 用于E10 OA系统接收Micorsoft 365回调请求 和 通过微软AAD集成接入微软AzureAD

#### **Microsoft365配置说明**

1.

##### **登录Microsoft Entra控制台创建应用程序并调整程序相关配置项，应用程序上添加Microsoft用户权限**

Microsoft Entra控制台地址 [_https://entra.microsoft.com_](https://entra.microsoft.com)

**1.1新应用注册**

 

 

**1.2注册完成之后查看应用程序租户ID、应用程序ID、应用程序密钥信息后续OA配置中会使用**

 

 

 

 

**1.3添加应用程序API权限（Sites.ReadWrite.All、Files.ReadWrite.All）**

 

 

 

 

2.

##### **创建SharePoint网站，获取SharePoint文档库ID值**

**2.1登录Microsoft 365控制台**

[ _https://www.office.com/_](https://www.office.com/)

**登录后左上角搜索SharePoint应用（如果这里没有查看用户的权限，以及是否购买Microsoft 365企业版），进入SharePoint创建一个新的site网站**

 

 

 

 

 

**2.2 获取应用程序请求令牌（记录返回的令牌，用于获取文档库ID <SiteID）**

[ _https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token_](https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token)

**参数说明：**

**grant_type： client_credentials （鉴权方式，传默认值即可）**

**client_secret：应用程序密钥（步骤1.2中获取）**

**scope ：**[** _https://graph.microsoft.com/default_****（鉴权范围，传默认值即可）**](https://graph.microsoft.com/default（鉴权范围，传默认值即可）)

**client_id：客户端ID（步骤1.2中获取）**

**tennatId：租户ID（步骤1.2中获取）**

 

 

**2.3 查询创建的SharePoint文档库ID记录该值SharePoint 文档库SiteId查询接口，可以通过curl、postman等工具调用 （需要保存查询到的ID，后续OA配置需要用到）**

[** _https://graph.microsoft.com/v1.0/sites/getAllSites_**](https://graph.microsoft.com/v1.0/sites/getAllSites)**    请求头中传递Authorization：鉴权令牌（步骤2.2中获取）**

 

3.

##### **OA 租户管理平台新建Microsoft365插件并补充配置项**

**目录租户ID（必填） -- 步骤1.2获取**

**应用程序ID（必填）-- 步骤1.2获取**

**应用程序密钥（必填）-- 步骤1.2获取**

**文档库ID（必填）-- 步骤2.3获取**

 

 

 

 

4.

##### **OA系统后台管理－文件设置－插件设置中设置预览编辑插件优先级**

 

 

5.

##### **配置E10 OA系统通过微软AAD集成接入微软AzureAD实现单点登录（可选）**

[ _https://www.e-cology.com.cn/sp/ebdpage/view/925344871484284974/page/925344871484284974_](https://www.e-cology.com.cn/sp/ebdpage/view/925344871484284974/page/925344871484284974)

 

#### **Microsoft365使用说明**

1.

**OA中集成Microsoft 365默认支持的预览格式****csv、doc、docx、odp、ods、odt、pot、potm、potx、pps、ppsx、ppsxm、ppt、pptm、pptx、rtf、xls、xlsx****，支持的编辑格式****docx，xlsx，pptx****，如果要编辑doc、xls、ppt则需要本地转换为docx、xlsx、pptx格式或者通过打开客户端office编辑。**

2.

**移动端目前不支持在线编辑，需要通过下载Microsoft 365 (offcie) APP操作编辑**

** **[**_https://www.microsoft.com/en-us/microsoft-365/mobile_**](https://www.microsoft.com/en-us/microsoft-365/mobile)

### **1.2.17 石墨文档**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2411.01及以上版本**

**其他说明：**

1.

需要准备公网域名地址用于E10 OA系统接收石墨文档服务回调请求

1.

#### **创建石墨文档应用**

##### **1.1进入石墨文档官网控制台页面（**[ _https://open.shimo.im_**）**](https://open.shimo.im）)

 

##### **1.2 创建应用**

 

##### **1.3 记录应用的AK、SK，后续配置租户插件会用到**

 

##### **1.4 石墨应用配置OA域名回调地址，支持HTTP和HTTPS （****固定OA域名 + /papi/file/shimo****）**

 

2.

#### **租户管理平台及OA后台配置**

##### **2.1 租户管理平台新建石墨插件，填写必填项AK、SK、插件服务地址（插件服务地址如果是石墨云服务使用**[ _https://office.shimoapi.com_**，如果是石墨私有化部署需要咨询石墨相关部署人员具体服务地址）**](https://office.shimoapi.com，如果是石墨私有化部署需要咨询石墨相关部署人员具体服务地址）)

 

##### **2.2 如果想要自定义石墨回调地址不使用OA默认，可以在高级设置里面配置文件回调下载地址（非必须）**

 

##### **2.3 OA后台管理－文件插件设置插件优先级使用**

 

### **1.2.18 ONLYOFFICE（社区版）**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：** ONLYOFFICE v8.2

**OA版本支持：****基线24012.01及以上版本**

**用户编辑并发数限制：社区版限制了用户并发最大数量为****20，即只能有同时最多20个用户同时编辑**

**注意：目前该插件只能支持文档、流程模块使用，公文等模块暂不兼容**

1.

#### **服务器安装onlyoffice服务**

**docker启动命令示例（****需要添加参数 -e JWT_ENABLED=false****，目前OA对接版本默认没有开启该校验）：**

4 

# 常规启动方式

5 

docker run --privileged=true -i -t -d -p {宿主机端口}:80 --restart=always  -e JWT_ENABLED=false onlyoffice/documentserver

6 

7 

# 挂载容器配置文件到宿主机的启动方式

8 

docker run --privileged=true -i -t -d -p {指定映射的宿主机端口号}:80 --restart=always \

9 

    -v /app/onlyoffice/DocumentServer/logs:/var/log/onlyoffice  \

10 

    -v /app/onlyoffice/DocumentServer/data:/var/www/onlyoffice/Data  \

11 

    -v /app/onlyoffice/DocumentServer/lib:/var/lib/onlyoffice \

12 

    -v /app/onlyoffice/DocumentServer/db:/var/lib/postgresql -e JWT_ENABLED=false onlyoffice/documentserver

**官方说明：参考官网docker安装方式示例：**[ ___Installing ONLYOFFICE Docs for Docker on a local server - ONLYOFFICE_](https://helpcenter.onlyoffice.com/docs/installation/docs-community-install-docker.aspx)

 

 

 

2.

#### **租户管理平台新建OnlyOffice插件，并配置插件服务地址（协议：//域名 或者 ip：端口号）**

 

3.

#### **OA后台管理－文件插件设置插件优先级使用**

 

#### **4\. FAQ .插件服务部署中遇到的问题**

##### **4.1 OnlyOffice生成证书及证书管理？**

官方参考资料：[ _https://helpcenter.onlyoffice.com/installation/docs-developer-install-docker.aspx_](https://helpcenter.onlyoffice.com/installation/docs-developer-install-docker.aspx)

##### **4.2 插件部署完成后系统中打开文件提示下载失败，查看插件日志有如下报错Error: DNS lookup xxx(family:undefined, host:undefined) is not allowed. Because, It is private IP address**

**预览/编辑提示报错：**

 

**插件错误日志：**

 

**解决方式：需要编辑配置文件允许私有ip通过（如果是docker部署则修改容器中配置文件）**

修改容器中插件的配置文件/etc/onlyoffice/documentserver/default.json：

搜索并修改以下字段为true：

"request-filtering-agent" : {

"allowPrivateIPAddress": true,

"allowMetaIPAddress": true

}

修改完成后重启容器或者容器内执行**supervisorctl restart all** 生效配置文件。

##### **4.3 插件服务切换成https后onlyoffice页面提示下载失败，服务器插件服务安装根目录下执行如下命令替换文件内容（如果是docker部署则在容器中执行）**

13 

find /var/www/onlyoffice/documentserver -name sdk-all-min.js | xargs -n 1 sed -E -i 's|(function +\w+\\(\w+\\) *\\{ *function +\w+\\(\\)) *\\{ *(\w+)\\.open\\((\w+),(\w+),(\w+)\\);|\1{\nif (\4 \&\& \4.length > 5) {if (\4.substring(0, 5) == "http:") {\4 = \4.replace("http://", "https://");}};\n\[2.open](http://2.open)(\3,\4,\5);\n|'

##### **4.4调整插件支持打开的文件大小，修改default.json如下内容，修改完成后重启容器或者****容器内执行supervisorctl restart all****生效配置文件。**

 

##### **4.5.容器启动后查看日志提示端口无法连接的报错。**

**解决方式：****docker启动命令添加****\--privileged=ture****  赋予容器权限。**

14 

docker run --privileged=true -i -t -d -p {宿主机端口}:80 --restart=always  -e JWT_ENABLED=false onlyoffice/documentserver

 

##### **4.6.OA系统使用Onlyoffice预览编辑页面空白，F12查看console控制台发现有报错，加载onlyoffice资源失败。**

**解决方式：****OA预览编辑会从Onlyoffice下载资源文件，****浏览器客户端需要能够访问配置的OnlyOffice插件ip地址****。**

 

##### **4.7 ecology客户端使用onlyoffice插件预览/编辑页面不加载文件，查看console控制台有报错。**

 

**解决方式****：进入onlyoffice文件目录，修改对应目录下文件有四个对应目录，比如doc格式文件需要修改/var/www/onlyoffice/documentserver/web-apps/apps/documenteditor/main/index.html 中****< head>标签下<script>标签中添加一行内容****，添加保存后重启容器****docker restart <容器id>****，其他格式文件也是相同的路径及处理方式。**

 

**添加内容：**

15 

window.process = undefined;

 

##### **4.8 提示文档安全令牌格式不正确**

 

**解决方式****：onlyoffice插件服务启动命令需要指定JWT_ENABLED=false**

##### **4.9 文件无法编辑保存失败，查看插件服务日志有如下报错**

 

 

 

**解决方式：****修改租户后台-onlyoffice插件-高级设置，配置OA访问地址。 http(s)://{OA IP}:{OA port}**

 

 

**如果修改完上方配置还是有问题尝试修改OA配置文件，如果是组合部署**  Nacos 中修改配置文件

配置文件 [weaver-file-service.properties](http://weaver-file-service.properties)

新增或修改配置项 onlyoffice.callback.url=**http(s)://{OA IP}:{OA port}**

**如果是单体部署** 则需要修改单体配置文件，**修改后需要重启E10单体服务** 。单体环境配置文件路径E10/webapps/ROOT/WEB-INF/classes/weaver/config/config-center

配置文件 [weaver-file-service.properties](http://weaver-file-service.properties)

新增或修改配置项 onlyoffice.callback.url=**http(s)://{OA IP}:{OA port}**

### **1.2.19 联想zOffice（Filez）**

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**插件服务部署支持：**[** _联想FilezOffice部署相关支持(持续更新）_**](https://www.kdocs.cn/l/coGlMirOBitb)

**服务版本支持：** FilezOffice v7.3及以上

**OA版本支持：****基线2504.01及以上版本**

**其他高级功能：** 如果客户需要联想Filez文档中台生态版之外的功能，比如：**PDF批注，公文助手** ，可以联系联想Filez销售或者商务人员，申请开通相应的license进行试用

1.

#### **FilezOffice控制台相关设置**

Filez文档中台插件部署完成后，需要登陆文档中台管理控制台进行相关应用设置。Filez文档中台管理控制台地址: **http(s)://{文档中台ip}:{port}/docs/app/admin，** 这里port的缺省值是8001，管理控制台的缺省密码是admin。

##### **1.1新增FilezOffice应用**

 

##### **1.2 FilezOffice应用配置**

**设置项的值可以自定义配置，下图中红色框选中的内容在后续OA系统中进行预览编辑文档中台管理配置会用到。**

**注意点：**

1.

三方应用ID，这里缺省设置成”weaver_e10”，**注意如果自己定义app id，id不能包含中文字符**

2.

**三方应用接口地址接口地址前缀需要调整成OA HOST的地址 http(s)://{OA域名 或 OA IP:port }/papi/file/zoffice/files ,接口URL部分保持固定**

3.

三方应用接口token名称，可以不改，就用”zdocs_access_token”

4.

集成加密密钥是一个随机字符串，可以通过openssl rand -base64 64来产生，比如：”Xtc40527tJcZpNYbAVvyKFiMwUR9Pq9qYn63bgO9Uj9lU8T3xT+3BDceoyMtXpgjNGR62etb2aY9dGoTM4/LYw==”

5.

OpenAPI验证密钥是一个随机字符串，可以通过openssl rand -base64 64来产生，比如：”Xtc40527tJcZpNYbAVvyKFiMwUR9Pq9qYn63bgO9Uj9lU8T3xT+3BDceoyMtXpgjNGR62etb2aY9dGoTM4/LYw==”

 

 

##### **1.3 FilezOffice配置管理**

泛微Ecology前端页面会调用Filez文档中台的JS SDK API实现保存、打印等功能。需要在Filez文档中台管理控制台配置管理添加SDK白名单，**如果不限制请求IP可以填 *。如果需要限制IP，配置泛微页面的host** 。

 

2.

#### **OA租户后台插件设置**

##### **2.1 租户后台新增****联想zOffice插件****，设置相关配置项的内容**

**注意点：**

**这里插件服务地址的值是：http(s)://{文档中台ip}:{port} 不包含任何路径。**

 

 

##### **2.2 租户后台-预览编辑设置-插件高级设置中填写 1.2 中定义的配置项值**

**注意点：**

**1.文件下载域名只包含****http(s)://{OA IP}:{OA port}，且要和1.2中的第三方应用接口地址填写的OA HOST地址保持一致，这里只需要填写OA HOST内容，不包含接口URL部分**

 

#### **3\. FAQ .插件使用中遇到的问题**

##### **3.1 在线预览或者在线编辑时，显示错误码11004**

错误截图：

 

错误描述：无效的请求参数，不能获取相关repo（app）的配置信息。

**解决方式：****确认该应用已经在管理控制台上创建对应的app,并且开启了前端集成。**

 

##### **3.2 在线预览或者在线编辑时，显示错误码11011**

错误截图：

 

 

错误描述：无效的请求参数DriverCallbackHandler: HMAC is expire with request timestamp

**解决方式：****时间戳已经过期。url中的时间戳可以保证url不被用户任意散布。缺省有效期是10秒。前端在线编辑/预览请求的url 只能由业务系统的服务端产生，并且业务系统的服务器和Filez 文档中台的服务器需要做时间同步NTP。**

##### **3.3 使用插件预览/编辑报错 或者插件编辑保存后最新的内容没有显示，f12查看console控制台提示handshake timeout报错。**

 

**解决方式****：FilezOffice控制台配置管理修改****SDK白名单****添加****OA访问地址****，如果不限制请求IP可以填 ***

 

##### **3.4 调用Filez插件格式处理失败（转版、合并、套红、清稿等操作失败）**

**解决方式：如果是组合部署**  Nacos 中修改配置文件，手动配置OA回调地址

配置文件 [weaver-file-service.properties](http://weaver-file-service.properties)

新增或修改配置项 filez.callback.url=｛OA host地址｝

**如果是单体部署** 则需要修改单体配置文件，**修改后需要重启E10单体服务** 。单体环境配置文件路径E10/webapps/ROOT/WEB-INF/classes/weaver/config/config-center

配置文件 [weaver-file-service.properties](http://weaver-file-service.properties)

新增或修改配置项 filez.callback.url=｛OA host地址｝

**注意：该配置应和Filez后台配置的回调地址保持一致**

 

##### **3.5预览文件时需要隐藏修订和批注内容**

**解决方式：如果是组合部署**  Nacos 中修改配置文件执行

配置文件 [weaver-file-service.properties](http://weaver-file-service.properties)

新增或修改配置项 filez.preview.with.track.change=false

**如果是单体部署** 则需要修改单体配置文件，**修改后需要重启E10单体服务** 。单体环境配置文件路径E10/webapps/ROOT/WEB-INF/classes/weaver/config/config-center

配置文件 [weaver-file-service.properties](http://weaver-file-service.properties)

新增或修改配置项 filez.preview.with.track.change=false

##### **3.6预览文件时提示报错：js load failed XXXXX**

 

**解决方式：**

1.

该地址是Filez JSSDK访问地址，浏览器需要能直接访问通当前连接才可以预览文件，**需要检查下是否浏览器或者网络拦截导致该地址无法访问** 。

2.

如果连接可以正常访问但是预览仍然提示该报错，需要查看OA访问地址和租户后台配置的Filez插件地址是否存在跨域，比如OA访问是通过HTTPS协议而Filez配置的是HTTP访问方式，则两者不同源存在跨域现象。**需要配置Filez插件域名访问地址和OA域名访问地址的映射关系** 。

**设置方式： 进入OA租户后台-预览编辑设置-查看Filez插件配置-访问策略**

 

**设置网络访问策略，支持设置多条**

 

 

#### **4\. FAQ .Filez插件部署相关（详细内容参见**[ _联想FilezOffice部署相关支持(持续更新）_](https://www.kdocs.cn/l/coGlMirOBitb)**）**

##### **4.1 Filez文档中台支持信创吗？**

支持以下信创环境

CPU架构| 操作系统  
---|---  
x86-海光| centos7.8+；redhat7.8+；ubuntu18.04+；龙蜥8.8+; Open Euler  
arm-鲲鹏| 麒麟；统信  
arm-飞腾| 麒麟；统信  
  
对于非信创的x86 环境，主流的Linux都支持，比如：centos7.8+；redhat7.8+；ubuntu18.04+；龙蜥8.8+; Open Euler

##### **4.2 Filez文档中台支持哪些国产中间件？**

Filez文档中台没有使用关系数据库。**因此无需使用国产关系数据库** ，例如达梦、人大金仓等。

Filez文档中台服务端没有使用Java技术。**因此无需使用国产Java中间件** ，例如东方通、宝兰德等。

##### **4.3 Filez文档中台支持哪些部署方式？**

Filez文档中台的标准部署方式是镜像部署。需要在目标硬件上单独部署。不推荐和别的应用模块部署在同一个节点上。

镜像部署基于docker和docker-compose，需要先安装docker和docker-compose。

Filez文档中台支持国产涉密操作系统（比如：涉密版麒麟，涉密版中科方德）上非docker 部署。该部署方式Filez文档中台生态版不支持。如果有需求，请联系Filez商务：李晨。

##### **4.4 Filez文档中台支持多大的并发？**

x86服务器资源配置建议  
---  
标准等级| 指标| 设计能力| 架构| CPU| 内存  
A1级| 日活用户数| < 1000| 1节点| 核心>=8核| 容量>=16GB  
并发数| 300  
可用性| 非高可用  
A2级| 日活用户数| < 2000| 1节点| 核心>=16核| 容量>=32GB  
并发数| 600  
可用性| 非高可用  
B级| 日活用户数| < 6000| 3节点| 核心>=16核| 容量>=32GB  
并发数| 1800  
可用性| 高可用  
C级| 日活用户数| < 12000| 3节点| 核心>=32核| 容量>=64GB  
并发数| 3600  
可用性| 高可用  
  
 

信创服务器资源配置建议  
---  
标准等级| 指标| 设计能力| 架构| CPU| 内存  
A级| 日活用户数| < 1300| 1节点| 核心>=16核| 容量>=32GB  
并发数| 400  
可用性| 非高可用  
B级| 日活用户数| < 4000| 3节点| 核心>=16核| 容量>=32GB  
并发数| 1200  
可用性| 高可用  
C级| 日活用户数| < 8000| 3节点| 核心>=32核| 容量>=64GB  
并发数| 2400  
可用性| 高可用  
  
### **1.2.20 华虹数智**

**插件功能简介：** 需部署中标慧康服务，支持文档预览/编辑/协同编辑

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：**

**OA版本支持：****基线2506.01及以上版本**

**需要配置信息：**

1.

插件服务地址（eg：[http://192.0.2.10）](http://192.0.2.10）)

**其他说明：**

1.

**功能更新：**

**2602.01基线** 支持清稿，套红

### **1.2.21 OfficeWeb365**

**插件功能简介：** 需部署officeWeb365服务，支持文档预览

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：**[** _文档在线预览 OfficeWeb365 速度更快的Office在线预览服务_**](https://officeweb365.com/)

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（eg：[http://192.0.2.10:8081）](http://192.0.2.10:8081）)

**其他说明：**

2.

**功能更新：**

**2601.01基线** 支持预览压缩包格式文件

### **1.2.22 浩辰CAD**

**插件功能简介：** 需部署浩辰服务，支持cad预览/批注

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：** 浩辰V4.0+

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

插件服务地址（eg：[http://192.0.2.10）](http://192.0.2.10）)

**其他说明：**

1.

仅支持PC端使用

2.

文件的批注内容只有在系统内在线打开会显示，文件下载到本地不会显示批注内容

**功能更新：**

**2510.01基线** 支持把cad文件批准信息回存到文件中

**2506.01基线** 支持预览dwf格式文件

### **1.2.23 广联达**

**插件功能简介：** 支持cad文件预览

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**服务版本支持：**[** _广联达BIMFACE -  国内领先BIM轻量化引擎赋能BIM二次开发应用_**](https://bimface.com)

**OA版本支持：****基线2308.01及以上版本**

**需要配置信息：**

1.

AppKey

2.

AppSecret

**其他说明：**

1.

支持的广联达为 _SaaS服务版本，文件预览过程需要从oa下载文件，一定要保证oa有服务地址可以支持外网访问_

2.

广联达获取AppKey，AppSecret方法

1)

登录广联达控制台（[** _https://bimface.com/user-console/login_** ），没有账号的话可以申请注册试用](https://bimface.com/user-console/login），没有账号的话可以申请注册试用)

2)

登录后进入项目管理获取AppKey，AppSecret，如下如所示：

 

### **1.2.24 默认插件**

**插件功能简介：** 无需安装预览编辑服务，支持各客户端预览word，excel文件（转html预览）

**插件详细功能：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**其他说明：**

1.

系统自带可直接使用

2.

此插件为研发根据开源的工具包（poi，pdfbox，pdfJs，libreoffice，...）形成的一个插件

3.

**此插件功能不适用于公文场景**

4.

**此插件预览/编辑文件效果在格式上会和本地打开有差异，无法解决，若客户介意建议采购第三方预览/编辑服务**

**功能更新：**

**2602.01基线** xlsx文件支持在线编辑；pdf，ofd加图片水印支持设置水印图片缩放比例；pdf文件加文字水印支持文字内容换行

**2601.01基线** 新增支持ofd文件预览/下载加水印

**2512.01基线** 新增支持预览压缩包（zip,rar）文件

仅支持linux服务器部署oa使用，开启前需weaver-file-online服务所在的服务器安装unzip（sudo yum install unzip）和unrar（sudo yum install unrar）解压软件。如需使用其他软件解压请联系张坤鹏协助配置解压命令

需消息中间件为RabbitMQ

压缩包文件预览默认是不开启的，开启前请确认服务器配置。开启方法：修改租户后台默认插件的可预览文件格式，增加zip,rar

**2510.01基线** 将libreoffice，内容编辑器，pdfJs，ofdJs插件功能合并到此插件中

1.

**在线预览**

word文档（doc，docx）：支持3种预览模式，默认为组件预览（设置仅对oa内部页面预览生效，外部免登页面转html预览）

组件预览：文件转html再用前端组件渲染，相对直接转html预览效果更好

转html预览：使用poi转html预览

转pdf预览：文件转pdf再使用pdf.js预览。支持预览水印

excel文档（xls，xlsx）：支持3种预览模式，默认为组件预览

组件预览：仅支持xlsx文件，xls降级为转html预览

转html预览：使用poi转html预览

转pdf预览：文件转pdf再使用pdf.js预览。支持预览水印

pdf文档：使用pdf.js预览，支持预览水印

ofd文档：使用ofd.js预览

其他文档：支持转pdf预览，支持预览水印。使用此预览需有第三方转换服务，把转换服务支持转pdf的文件格式添加到默认插件的预览格式中

 _注：转pdf预览，用什么服务转pdf取决于oa后台格式处理的优先级设置，如果没有第三方转换服务请先确保libreoffice服务已安装。_

2.

**在线编辑** ：支持在线编辑doc，docx格式文档

### **~~1.2.25 LibreOffice~~**

**插件功能简介：** 需本地部署libreoffice服务；支持各客户端文件预览（转pdf预览）

**详细功能支持：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2408.01及以上版本**

**其他说明：**

1.

系统自带可直接使用（此插件需要安装LibreOffice服务，信创服务器不一定能安装成功）

2.

此插件只能预览20M及以下大小文件

**功能更新：**

**2510.01基线** 此插件被移除，插件功能合并到默认插件中

**2507.01基线** 支持预览水印

### **~~1.2.26 内容编辑器~~**

**插件功能简介：** 无需额外部署预览编辑服务，支持各客户端预览/编辑文件

**插件详细功能：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2508.01及以上版本**

**其他说明：**

1.

系统自带可直接使用，仅支持预览编辑doc，docx格式文件

**功能更新：**

**2510.01基线** 此插件被移除，插件功能合并到默认插件中

### **~~1.2.27 pdfJs~~**

**插件功能简介：** 无需安装第三方服务，支持各客户端预览pdf文件

**插件详细功能：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2308.01及以上版本**

**其他说明：**

1.

仅支持预览pdf文件

2.

系统自带可直接使用

3.

浏览器版本支持 Chrome 70+；Firefox 65+；Safari 12.1+；Edge 79+

**功能更新：**

**2510.01基线** 此插件被移除，插件功能合并到默认插件中

### **~~1.2.28 ofdJs~~**

**插件功能简介：** 无需安装第三方服务，支持各客户端预览ofd文件

**插件详细功能：**[** _E10插件功能支持_**](https://kdocs.cn/l/cdc6s5k5QkuX)

**OA版本支持：****基线2504.01及以上版本**

**其他说明：**

1.

仅支持预览ofd文件

2.

系统自带可直接使用

**功能更新：**

**2510.01基线** 此插件被移除，插件功能合并到默认插件中

### **1.2.99 其他**

其他客户端插件无须设置插件信息，保证用户客户端插件已正确安装后直接启用即可

二、

# **二开对接一个新插件**

第一步：[新建一个类继承com.weaver.teams.file.online](http://新建一个类继承com.weaver.teams.file.online).plug.factory.abstracts.PlugBaseServer类

第二步：根据插件功能重写实现PlugBaseServer类中的方法

第三步：第三方服务回调OA接口开发，插件前端SDK方法对接（主要涉及在线编辑保存文件）

特别说明：

1.

此二开不是在二开服务里面开发，新建一个项目开发。开发完成后打成jar包上传到weaver-file-service服务

2.

 [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.*；com.weaver.teams.file.e10.*；包路径下的文件不在jar包中，去服务器weaver-file-service服务的class目录下拿，拿过来放在/devLib/classes目录下。build.gradle配置文件增加以下配置项：

 

## **2.1前端开发说明**

详细参考：[ _前端开发参考_](https://weapp.eteams.cn/ecode/playground/doc/share/view/974720966604931072#%E4%BA%8C%E3%80%81%E6%96%B0%E6%8F%92%E4%BB%B6%E5%BC%80%E5%8F%91ecode%E7%A4%BA%E4%BE%8B) （详细可咨询熊相超）

## **2.2后端开发说明**

详细说明请参考以下代码注释：

16 

package [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.factory.product;

17 

18 

import com.weaver.common.component.form.WeaForm;

19 

import com.weaver.common.component.form.item.WeaFormItem;

20 

import com.weaver.common.component.form.item.WeaFormItemType;

21 

import com.weaver.common.component.form.layout.WeaFormLayout;

22 

import com.weaver.common.i18n.label.SystemEnv;

23 

import com.weaver.eteams.file.client.file.FileCapabilityParam;

24 

import com.weaver.eteams.file.client.file.FileObj;

25 

import com.weaver.file.watermark.constant.OperationTypeEnum;

26 

import com.weaver.file.watermark.constant.WatermarkTypeEnum;

27 

import com.weaver.teams.file.e10.dto.EditFunDto;

28 

import com.weaver.teams.file.e10.dto.PreviewFunDto;

29 

import com.weaver.teams.file.e10.manager.plug.apply.PlugApplyParam;

30 

import com.weaver.teams.file.e10.param.EditUrlParam;

31 

import com.weaver.teams.file.e10.param.PreviewParam;

32 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.factory.abstracts.PlugBaseServer;

33 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.factory.abstracts.PlugFunctionService;

34 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.PlugCommonService;

35 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.conatant.PlugFunctionEnum;

36 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.conatant.UseTerminalEnum;

37 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.dto.TentPlugParamDto;

38 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.entity.PlugSettingInfo;

39 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.entity.PlugSysSetting;

40 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.util.PlugManagerUtil;

41 

import com.weaver.teams.file.watermark.entity.param.PlugWatermarkFormParam;

42 

import org.slf4j.Logger;

43 

import org.slf4j.LoggerFactory;

44 

import org.springframework.beans.factory.annotation.Autowired;

45 

import org.springframework.stereotype.Component;

46 

47 

import java.util.*;

48 

49 

/**

50 

 * @Description: 【项目二开示例插件】 二开集成一个新的预览编辑插件示例

51 

 * @Author: 张坤鹏

52 

 * @Date: 2023/7/29 15:58

53 

 */

54 

@Component

55 

public class SecondDevDemoPlug extends PlugBaseServer {

56 

57 

    private static final Logger logger = LoggerFactory.getLogger(SecondDevDemoPlug.class);

58 

59 

    /**

60 

     * 插件各项功能支持的文件格式

61 

     */

62 

    private static final String PREVIEW_FILE_TYPES = "doc,docx,wps,ppt,pptx,pot,ptm,xls,xlsx,csv,ods,pdf,ofd";

63 

    private static final String EDIT_FILE_TYPES = "doc,docx,xls,xlsx,ppt,pptx,wps,pdf,ofd";

64 

    private static final String CONVERT_PDF_FILE_TYPES = "doc,docx,xls,xlsx,ppt,pptx,wps,ofd";

65 

    private static final String REPLACE_FILE_TYPES = "doc,docx";

66 

    private static final Map<PlugFunctionEnum, String> fileTypesSupported = new HashMap<PlugFunctionEnum, String>() {{

67 

        put(PlugFunctionEnum.PREVIEW, PREVIEW_FILE_TYPES);

68 

        put(PlugFunctionEnum.EDIT, EDIT_FILE_TYPES);

69 

        put(PlugFunctionEnum.CONVERT_PDF, CONVERT_PDF_FILE_TYPES);

70 

        put(PlugFunctionEnum.REPLACE, REPLACE_FILE_TYPES);

71 

    }};

72 

73 

    /**

74 

     * 在线预览支持的水印类型

75 

     */

76 

    List<WatermarkTypeEnum> previewWatermarkList = Arrays.asList(WatermarkTypeEnum.text, WatermarkTypeEnum.image);

77 

78 

    /**

79 

     * 插件具有的功能（可设置PREVIEW,EDIT,FORMATTING）

80 

     */

81 

    private static final List<PlugFunctionEnum> plugFunctionSet = new ArrayList<PlugFunctionEnum>() {{

82 

        add(PlugFunctionEnum.PREVIEW);

83 

        add(PlugFunctionEnum.EDIT);

84 

        // 格式处理包含 清稿,套红,转pdf,加水印等（设置格式处理需设置PlugSysSetting.formattingFunctionList的值）

85 

        add(PlugFunctionEnum.FORMATTING);

86 

    }};

87 

88 

    /**

89 

     * 插件格式处理支持的具体功能（可设置PlugFunctionEnum功能项中除PREVIEW，EDIT，FORMATTING外的其他供功能项）

90 

     */

91 

    public static final List<PlugFunctionEnum> formattingFunctionList = new ArrayList<PlugFunctionEnum>() {{

92 

        add(PlugFunctionEnum.CONVERT_PDF);

93 

        add(PlugFunctionEnum.REPLACE);

94 

    }};

95 

96 

    /**

97 

     * 插件支持的客户端类型

98 

     */

99 

    private static final List<UseTerminalEnum> useTerminalSet = new ArrayList<UseTerminalEnum>() {{

100 

        add([UseTerminalEnum.WINDOWS](http://UseTerminalEnum.WINDOWS));

101 

        add(UseTerminalEnum.H5);

102 

        add([UseTerminalEnum.APP](http://UseTerminalEnum.APP));

103 

    }};

104 

105 

    @Autowired

106 

    private PlugCommonService plugCommonService;

107 

108 

    /**

109 

     * 插件的系统级别设置 此方法必须实现

110 

     **/

111 

    @Override

112 

    public PlugSysSetting getPlugSysSetting() {

113 

        PlugSysSetting plugSysSetting = new PlugSysSetting();

114 

        //插件的类型 【必须设置】（插件类型不可重复, [已集成好的插件类型详见PlugTypeEnum.id](http://已集成好的插件类型详见PlugTypeEnum.id)）

115 

        plugSysSetting.setPlugType("samplePlugin");

116 

        //插件的名称 【必须设置】

117 

        plugSysSetting.setPlugTypeName("245435");

118 

        //插件所拥有的的功能 【必须设置】

119 

        plugSysSetting.setPlugFunctionList(plugFunctionSet);

120 

        //插件所支持的客户端类型 【必须设置】

121 

        plugSysSetting.setUseTerminalList(useTerminalSet);

122 

        //插件格式处理所支持的具体功能【选择性设置】（若plugFunctionSet种包含了FORMATTING则在此设置具体的支持，若此处设置了加水印，需实现getWatermarkConfig配置水印样式）

123 

        plugSysSetting.setFormattingFunctionList(formattingFunctionList);

124 

        //插件的顺序 【选择性设置】（在后台新建插件时插件类型下拉框的顺序，若不设置默认最后一个，若想要在第一个设置为0）

125 

        plugSysSetting.setOrder(99);

126 

        //插件新建时是否默认启用 【选择性设置】（默认不启用，设置为1 默认启用）

127 

        plugSysSetting.setEnableStatus(1);

128 

        //新建插件的应用范围设置 【选择性设置】 （setTenant：指定租户可用 allTenant：所有租户可用 默认所有租户可用）

129 

        plugSysSetting.setApplicationScope(PlugManagerUtil.ALL_TENANT);

130 

        //插件的每种功能支持的文件格式 【选择性设置】 （若不设置 默认支持所有格式文件）

131 

        plugSysSetting.setFileTypesSupported(fileTypesSupported);

132 

        //在线预览支持的水印类型【选择性设置】（若此处设置值，需实现getWatermarkConfig配置水印样式。需2505.01及以上基线支持）

133 

        plugSysSetting.setPreviewWatermarkList(previewWatermarkList);

134 

        //插件的其他设置默认值 【选择性设置】

135 

        Map<String, Object> otherSettings = new HashMap<>();

136 

        plugSysSetting.setOtherSettings(otherSettings);

137 

        //插件的服务类型 【选择性设置】 （公文会用到，客户端插件=client 服务端插件server）

138 

        plugSysSetting.setClientPlugType("server");

139 

        //是否支持协同编辑 【选择性设置】

140 

        plugSysSetting.setCollaborativeDocuments(null);

141 

        //是否支持外部预览【选择性设置】 （需2505.01及以上基线支持）

142 

        plugSysSetting.setNotLoggedInPreview(null);

143 

        //是否支持外部编辑【选择性设置】（需2505.01及以上基线支持）

144 

        plugSysSetting.setNotLoggedInEdit(null);

145 

        return plugSysSetting;

146 

    }

147 

148 

    /**

149 

     * 租户后台 - 插件设置页面信息 此方法必须重写

150 

     **/

151 

    @Override

152 

    public WeaForm getPlugForm(String plugType, String langType) {

153 

        //获取默认系统标准的插件信息维护表单 在默认表单上修改

154 

        //默认表单字段包含 插件类型 插件名称 启用状态 插件服务地址 可应用于 使用终端 若这些设置项不够 可自行增加设置项

155 

        WeaForm weaForm = plugCommonService.getPlugForm(plugType, langType);

156 

        //增加其他设置项

157 

        List<List<WeaFormLayout>> layout = weaForm.getLayout();

158 

        //插件其他设置项布局 布局id和items id一致  命名规则需严格按照 插件标识_设置项标识

159 

        WeaFormLayout weaFormLayout = new WeaFormLayout("samplePlugin_setting1", SystemEnv.getHtmlLabelName(276736, "其他设置项1"), new String[]{"samplePlugin_setting1"});

160 

        layout.add(Collections.singletonList(weaFormLayout));

161 

        weaFormLayout = new WeaFormLayout("samplePlugin_setting2", SystemEnv.getHtmlLabelName(276737, "其他设置项2"), new String[]{"samplePlugin_setting2"});

162 

        layout.add(Collections.singletonList(weaFormLayout));

163 

        //插件的其他设置项items

164 

        Map<String, WeaFormItem> items = weaForm.getItems();

165 

        WeaFormItem weaFormItem = new WeaFormItem(WeaFormItemType.INPUT);

166 

        weaFormItem.setRequired(true);

167 

        items.put("samplePlugin_setting1", weaFormItem);

168 

        weaFormItem = new WeaFormItem(WeaFormItemType.INPUT);

169 

        weaFormItem.setRequired(true);

170 

        items.put("samplePlugin_setting2", weaFormItem);

171 

        return weaForm;

172 

    }

173 

174 

    /**

175 

     * 此方法必须实现  return this 即可

176 

     **/

177 

    @Override

178 

    public PlugFunctionService getPlugFunManager() {

179 

        return this;

180 

    }

181 

182 

    /**

183 

     * 在用户使用插件指定功能时候的校验 如需自定义校验 重写此方法

184 

     * tentPlugParam：插件使用参数  plugSettingInfo： 插件的租户后台设置 plugSysSetting：插件的系统级别设置

185 

     * 方法返回值 true：校验通过  false：校验失败

186 

     * 以下系统已自动校验不用再校验：

187 

     * 1）租户后台插件设置应用范围 应用时间校验

188 

     * 2）OA后台插件应用范围校验

189 

     * 3）操作功能文件格式支持校验

190 

     * 4）预览和编辑功能 客户端支持校验

191 

     * 5）文件外部预览编辑校验，协同文档编辑校验

192 

     **/

193 

    @Override

194 

    public boolean checkTenantPlug(TentPlugParamDto tentPlugParam, PlugSettingInfo plugSettingInfo, PlugSysSetting plugSysSetting) {

195 

        // 例如 文件转pdf不支持超过20M的文件

196 

        if (tentPlugParam.getFunction() == PlugFunctionEnum.CONVERT_PDF) {

197 

            FileObj fileObj = tentPlugParam.getFileObj();

198 

            if (fileObj != null) {

199 

                long fileSize = fileObj.getSize();

200 

                if (fileSize > 20 * 1024 * 1024) {

201 

                    return false;

202 

                }

203 

            }

204 

        }

205 

        return true;

206 

    }

207 

208 

    /**

209 

     * 插件的在线预览功能 如要对接插件预览功能 实现此方法

210 

     **/

211 

    @Override

212 

    public PreviewFunDto createViewUrl(PlugApplyParam plugApplyParam, PlugSettingInfo plugSettingInfo) {

213 

        // 获取自定义设置的插件信息

214 

        Map<String, Object> otherSettings = plugSettingInfo.getOtherSettings();

215 

        // 预览参数

216 

        PreviewParam previewParam = plugApplyParam.getPreviewParam();

217 

        // 当前预览的文件

218 

        FileObj fileObj = plugApplyParam.getFileObj();

219 

        // 返回预览地址。此地址可以是第三方服务的文件预览地址，也可以是自己开发的页面地址，如果没有地址也可以不返回

220 

        String previewUrl = "[https://error.t4x.org/404.html](https://error.t4x.org/404.html)";

221 

        // 封装返回结果

222 

        PreviewFunDto previewFunDto = new PreviewFunDto();

223 

        previewFunDto.setViewType(plugSettingInfo.getPlugType());

224 

        previewFunDto.setViewUrl(previewUrl);

225 

        // 对接第三方服务所需要的其他信息 反馈给前端使用

226 

        previewFunDto.setExtraMap(new HashMap<>());

227 

        return previewFunDto;

228 

    }

229 

230 

    /**

231 

     * 插件的在线编辑功能 如要对接插件编辑功能 实现此方法

232 

     **/

233 

    @Override

234 

    public EditFunDto createEditUrl(PlugApplyParam plugApplyParam, PlugSettingInfo plugSettingInfo) {

235 

        // 获取自定义设置的插件信息

236 

        Map<String, Object> otherSettings = plugSettingInfo.getOtherSettings();

237 

        // 编辑参数

238 

        EditUrlParam editUrlParam = plugApplyParam.getEditUrlParam();

239 

        // 当前编辑的文件

240 

        FileObj fileObj = plugApplyParam.getFileObj();

241 

        // 调用第三方服务获取编辑地址。此地址可以是第三方服务的文件预览地址，也可以是自己开发的页面地址，如果没有地址也可以不返回

242 

        String editUrl = "[https://error.t4x.org/404.html](https://error.t4x.org/404.html)";

243 

        // 封装返回结果

244 

        EditFunDto editFunDto = new EditFunDto();

245 

        editFunDto.setEditUrl(editUrl);

246 

        // 对接第三方服务所需要的其他信息 反馈给前端使用

247 

        editFunDto.setExtraMap(new HashMap<>());

248 

        return editFunDto;

249 

    }

250 

251 

    /**

252 

     * 插件的格式转换，加水印，清稿，套红等功能实现 如要对接插件这些功能，实现此方法

253 

     */

254 

    @Override

255 

    public String fileProcessing(FileCapabilityParam fileCapabilityParam, PlugSettingInfo plugSettingInfo) {

256 

        [logger.info](http://logger.info)("######SecondDevDemoPlug.fileProcessing {}", fileCapabilityParam);

257 

        //fileCapabilityParam参数说明 详细参数说明可查看类属性注释 特别注意调用方可以通过文件名称和文件下载地址处理文件 或者 文件id处理文件 两种情况都要兼容

258 

        //调用第三方服务服务接口获取处理后的文件下载地址 注意这个地址要oa服务器能访问通正常下载文件

259 

        String fileUrl = "[https://www.e-cology.com.cn/](https://www.e-cology.com.cn/)...";

260 

        return fileUrl;

261 

    }

262 

263 

    /**

264 

     * 插件的水印功能 - 系统水印设置页面的插件的水印设置信息表单信息

265 

     *

266 

     * @param plugWatermarkFormParam

267 

     * @return

268 

     */

269 

    @Override

270 

    public WeaForm getWatermarkConfig(PlugWatermarkFormParam plugWatermarkFormParam) {

271 

        // 水印类型

272 

        WatermarkTypeEnum watermarkType = plugWatermarkFormParam.getWatermarkType();

273 

        // 水印应用场景 预览||下载

274 

        OperationTypeEnum operationTypeEnum = plugWatermarkFormParam.getWatermarkStyleType();

275 

        // 返回水印演示设置表单 例如 文字颜色，文字大小，不透明度等

276 

        return new WeaForm();

277 

    }

278 

279 

}

## **2.3后端常用方法说明**

### **2.3.1在线编辑文件保存方法**

280 

package [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.callback.service.impl;

281 

282 

import com.weaver.common.base.entity.result.WeaResult;

283 

import com.weaver.common.i18n.label.SystemEnv;

284 

import com.weaver.eteams.file.client.param.FileEditSaveDto;

285 

import com.weaver.file.ud.api.WeaFileApiService;

286 

import com.weaver.file.ud.dto.FileEditCallBackParam;

287 

import com.weaver.file.ud.utils.FileStreamUtils;

288 

import com.weaver.teams.file.e10.dto.FileDataInfoDto;

289 

import com.weaver.teams.file.e10.manager.EditProcessManager;

290 

import com.weaver.teams.file.e10.manager.FileInfoManager;

291 

import com.weaver.teams.file.e10.param.edit.SaveFileVersionParam;

292 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).utils.OnlineFileUtils;

293 

import org.springframework.beans.factory.annotation.Autowired;

294 

import [org.springframework.core.io](http://org.springframework.core.io).FileSystemResource;

295 

296 

import [java.io](http://java.io).File;

297 

298 

/**

299 

 * @Description: 在线编辑保存文件方法示例

300 

 * @Author: 张坤鹏

301 

 * @Date: 2025/7/4 9:30

302 

 */

303 

public class EditSaveExampleFunction {

304 

305 

    /**

306 

     * 此方法在标准weaver-file-service服务中，需要把class文件拿过来放在本地开发环境中

307 

     */

308 

    @Autowired

309 

    private EditProcessManager editProcessManager;

310 

311 

    /**

312 

     * 此方法在标准weaver-file-service服务中，需要把class文件拿过来放在本地开发环境中

313 

     */

314 

    @Autowired

315 

    private FileInfoManager fileInfoManager;

316 

317 

    /**

318 

     * 此方法在weaver-file-upload-download.jar中

319 

     */

320 

    @Autowired

321 

    private WeaFileApiService weaFileApiService;

322 

323 

    /**

324 

     * 方法一，通过文件的二进制流流保存文件（此方法不推荐）

325 

     */

326 

    private void editSaveFileByBytes() {

327 

        //正在编辑文件的id（编辑同一个文件要保证这个文件id不变才能叠加版本）

328 

        Long editFileId = -1L;

329 

        //正在编辑文件的下载地址（第三方服务的下载地址）

330 

        String editFileUrl1 = "";

331 

        //文件的二进制流

332 

        byte[] editFileBytes = OnlineFileUtils.downloadUrlBytes(editFileUrl1);

333 

        //文件版本描述（eg：***插件保存版本）

334 

        String desc = "";

335 

        //保存文件

336 

        editProcessManager.saveVersion(editFileId, editFileBytes, desc);

337 

    }

338 

339 

    /**

340 

     * 方法二，通过文件流保存文件。返回文件的版本号（2508.01及以后版本强烈推荐使用方法三）

341 

     */

342 

    private Long editSaveFileByStream() {

343 

        //在线编辑保存文件方法（编辑同一个文件要保证这个文件id不变才能叠加版本）

344 

        //正在编辑文件的id

345 

        Long editFileId = -1L;

346 

        //正在编辑文件的下载地址（第三方服务的下载地址）

347 

        String editFileUrl = "";

348 

        //下载文件

349 

        File file = FileStreamUtils.loadUrlToFile(editFileUrl);

350 

        //根据附件id 初始化保存参数

351 

        FileDataInfoDto fileDataInfo = fileInfoManager.getFileDataInfoByFileId(editFileId);

352 

        SaveFileVersionParam saveFileVersionParam = new SaveFileVersionParam(fileDataInfo);

353 

        //设置描述（必填）

354 

        saveFileVersionParam.setDesc(SystemEnv.getHtmlLabelName(64781, "编辑"));

355 

        //设置文件大小（必填）

356 

        saveFileVersionParam.setSize(file.length());

357 

        //设置创建版本的类型 = 插件类型

358 

        saveFileVersionParam.setVersionCreateId(null);

359 

        //设置版本的类型（区分无效版本和有效版本 设置true是有效数据， 设置为false则为无效的版本，需要调用/api/file/edit/plug/save方法会把当前附件的最新版本设置为有效版本）

360 

        saveFileVersionParam.setVersionTagBoolean(null);

361 

        //设置附件关联文档模块的文档id

362 

        saveFileVersionParam.setDocId(null);

363 

        //设置附件关联文档模块的文件夹id（动态存储相关）

364 

        saveFileVersionParam.setFolderId(null);

365 

        //内部人员信息

366 

        saveFileVersionParam.setEmployeeId(null);

367 

        saveFileVersionParam.setSimpleEmployee(null);

368 

        //如果是外部人员 设置外部自定义编辑人员信息

369 

        saveFileVersionParam.setUserId(null);

370 

        saveFileVersionParam.setUserName(null);

371 

        //保存文件

372 

        Long version = editProcessManager.saveVersion(new FileSystemResource(file), saveFileVersionParam);

373 

        return version;

374 

    }

375 

376 

    /**

377 

     * 方法三，通过sdk上传保存文件。返回保存后的文件版本id（需基线2508.01及以上版本）

378 

     */

379 

    private WeaResult<FileEditSaveDto> editSaveFileBySdk() {

380 

        FileEditCallBackParam fileEditCallBackParam = new FileEditCallBackParam();

381 

        //正在编辑文件的id（必填）（编辑同一个文件要保证这个文件id不变才能叠加版本）

382 

        Long editFileId = -1L;

383 

        fileEditCallBackParam.setFileId(editFileId);

384 

        //编辑后的文件流（必填）

385 

        File file = new File("");

386 

        fileEditCallBackParam.setFile(file);

387 

        //当前编辑人员id（必填）

388 

        fileEditCallBackParam.setEmployeeId(-1L);

389 

        //设置当前插件的类型（必填）

390 

        fileEditCallBackParam.setEditPlugType(null);

391 

        //设置版本的类型，默认为false（区分无效版本和有效版本，设置true是有效数据，设置为false则为无效的版本，需调用/api/file/edit/plug/save方法会把当前附件的最新版本设置为有效版本）

392 

        fileEditCallBackParam.setAutoSave(true);

393 

        //当前编辑文件所属文档id

394 

        fileEditCallBackParam.setDocId(null);

395 

        //当前编辑文件所属文档的所在文件夹id

396 

        fileEditCallBackParam.setFolderId(null);

397 

        //当前版本描述（默认为“编辑”）

398 

        fileEditCallBackParam.setEditDesc(null);

399 

        //外部编辑人员信息

400 

        fileEditCallBackParam.setUserId(null);

401 

        fileEditCallBackParam.setUserName(null);

402 

        //保存文件

403 

        WeaResult<FileEditSaveDto> result = weaFileApiService.saveFileVersion(fileEditCallBackParam);

404 

        return result;

405 

    }

406 

407 

}

408 

### **2.3.2其他常用方法**

409 

package [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.callback.service.impl;

410 

411 

import com.weaver.eteams.file.client.file.FileObj;

412 

import com.weaver.teams.domain.user.SimpleEmployee;

413 

import com.weaver.teams.file.e10.manager.plug.apply.PlugApplyParam;

414 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).plug.manager.entity.PlugSettingInfo;

415 

import [com.weaver.teams.file.online](http://com.weaver.teams.file.online).service.OnlineUtilService;

416 

import org.springframework.beans.factory.annotation.Autowired;

417 

418 

import [java.util.Map](http://java.util.Map);

419 

420 

/**

421 

 * @Description: 常用方法示例

422 

 * @Author: 张坤鹏

423 

 * @Date: 2023/9/6 20:21

424 

 */

425 

public class ExampleFunction {

426 

427 

    @Autowired

428 

    private OnlineUtilService onlineUtilService;

429 

430 

    private void exampleMethod(PlugApplyParam plugApplyParam, PlugSettingInfo plugSettingInfo) {

431 

        //***** PlugApplyParam参数使用 *****

432 

        //获取当前操作的文件对象

433 

        FileObj fileObj = plugApplyParam.getFileObj();

434 

        //获取附件id

435 

        Long fileId = fileObj.getId();

436 

        //获取文件的下载地址

437 

        String downloadUrl = onlineUtilService.getFileDownloadUrl(fileObj, null, null);

438 

        //获取当前用户信息

439 

        SimpleEmployee employee = plugApplyParam.getSimpleEmployee();

440 

441 

        //***** PlugSettingInfo参数使用 *****

442 

        //获取插件的服务地址

443 

        String plugUrl = plugSettingInfo.getPlugServiceUrl();

444 

        //获取插件的其他设置信息

445 

        Map<String, Object> otherSettings = plugSettingInfo.getOtherSettings();

446 

447 

        //***** 其他常用方法  *****

448 

        //获取OA服务地址（已兼容二级域名）

449 

        String oaUrl = onlineUtilService.getOaHostUrl();

450 

        //获取当前人员头像地址

451 

        String avatarUrl = onlineUtilService.getUserAvatar(employee);

452 

453 

        //***** 通过文件下载地址上传文件到OA(例如转pdf后的文件上传到oa)  *****

454 

        //插件服务的文件下载地址

455 

        String fileDownLoadUrl = "";

456 

        //文件的名称

457 

        String fileName = "";

458 

        //所在模块，根据业务需求设置， 一般为与文件的模块=fileObj.getModule() 当前操作模块

459 

        String module = "";

460 

        //附件是否生成文档

461 

        boolean createDoc = false;

462 

        //当前用户id

463 

        Long userId = employee.getEmployeeId();

464 

        //获取到一个新的文件对象

465 

        FileObj fromPlugFile = onlineUtilService.uploadFileToOA(fileDownLoadUrl, module, fileName, userId, createDoc);

466 

    }

467 

468 

}

## **2.4 集成中常见问题说明**

 

三、

# **调用插件能力**

接口调用无需考虑使用什么插件处理，系统会根据租户的插件设置自动选择优先级最高的插件，如需指定请联系张坤鹏  
---  
  
## **3.1 预览**

**调用方式** 直接引入前端组件到页面，[ _详细参考_](https://weapp.eteams.cn/ecode/playground/doc/share/view/974720966604931072#%E4%B8%80%E3%80%81%E7%BB%84%E4%BB%B6%E4%BD%BF%E7%94%A8%E7%A4%BA%E4%BE%8B)

**格式支持**[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

## **3.2 编辑**

**调用方式** 直接引入前端组件到页面，[ _详细参考_](https://weapp.eteams.cn/ecode/playground/doc/share/view/974720966604931072#%E4%B8%80%E3%80%81%E7%BB%84%E4%BB%B6%E4%BD%BF%E7%94%A8%E7%A4%BA%E4%BE%8B)

**格式支持**[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

## **3.3 格式转换（转pdf，ofd等）**

**功能说明**

1）其他格式的文件转pdf文件

2）其他格式的文件转ofd文件

3）其他格式的文件转html文件 _（使用wps转html默认编码gb2312，若要支持utf-8编码需升级wps版本〉= v7.1.2306.20230621）_

4）其他格式的文件转图片文件（支持 jpg，png，bmp）

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

### **3.3.1 RPC调用**

**需基线2308.01及以上版本**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

转图片每一页会转为一个图片，返回的是所有图片的压缩包文件

**调用示例**

469 

    @RpcReference

470 

    private OfficialFileConvertService officialFileConvertService;

471 

   

472 

    FileCapabilityParam fileCapabilityParam = new FileCapabilityParam();

473 

    // 操作类型 固定值【必填】

474 

    fileCapabilityParam.setOption("CONVERT");

475 

    // 要处理的文件id【必填】

476 

    fileCapabilityParam.setFileId(fileId);

477 

    // 用户id【必填】

478 

    fileCapabilityParam.setUserId(employee.getEmployeeId() + "");

479 

    // 文件转换参数【必填】

480 

    FileCovertParam fileCovertParam = new FileCovertParam();

481 

    // 目标文件格式 例如 pdf,ofd等

482 

    fileCovertParam.setTargetType(targetType);

483 

    fileCapabilityParam.setFileCovertParam(fileCovertParam);

484 

    // 其他参数选填 具体可看FileCapabilityParam参数描述

485 

    WeaResult<FileCapabilityResult> result = officialFileConvertService.capabilityFile(fileCapabilityParam);

返回结果：

486 

{

487 

    "code": 200,

488 

    "msg": "接口返回成功",

489 

    "status": true,

490 

    "data": {

491 

        "sourceFileId": "1037454650581663746",

492 

        "targetFileId": "1044131933120069632",

493 

        "targetUrl": "[https://weapp.yunteams.cn/papi/file/local/download/c60372cf-743d-40e7-8cb6-ab8040b7e701?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=9320cbb00d70444b81adc680b17d56e8/20240914/cn/s3/aws4_request&X-Amz-Signature=3254773ecd23a3eed1f59df00cfb189490e29aae543ea30fb7d6ed34cda43a1b&X-Amz-Date=20240914T092510Z&tenantKey=t4nb79v072&response-expires=U2F0IFNlcCAxNCAxODoyNToxMCBDU1QgMjAyNA==&metadata=eyJmaWxlU3RvcmFnZUluZm9NZXRhZGF0YSI6IntcImZpbGVQYXRoXCI6XCIvdDRuYjc5djA3Mi8yMDI0LzA5LzE0XCIsXCJmaWxlVXJsXCI6XCJjNjAzNzJjZi03NDNkLTQwZTctOGNiNi1hYjgwNDBiN2U3MDFcIixcInJ1bGVWZXJzaW9uSWRcIjpcIjEwMTQ3OTczMDY0NzA4NjY5NDRcIixcImRlbGV0ZVR5cGVcIjowfSIsInByZVNpZ25VcmxCYXNlRmlsZSI6dHJ1ZX0=&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTYlQjMlOUIlRTUlQkUlQUUlRTclQkIlQTklRTYlOTUlODglRTglODAlODMlRTYlQTAlQjgucGRm&download=MA==](https://weapp.yunteams.cn/papi/file/local/download/c60372cf-743d-40e7-8cb6-ab8040b7e701?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=9320cbb00d70444b81adc680b17d56e8/20240914/cn/s3/aws4_request&X-Amz-Signature=3254773ecd23a3eed1f59df00cfb189490e29aae543ea30fb7d6ed34cda43a1b&X-Amz-Date=20240914T092510Z&tenantKey=t4nb79v072&response-expires=U2F0IFNlcCAxNCAxODoyNToxMCBDU1QgMjAyNA==&metadata=eyJmaWxlU3RvcmFnZUluZm9NZXRhZGF0YSI6IntcImZpbGVQYXRoXCI6XCIvdDRuYjc5djA3Mi8yMDI0LzA5LzE0XCIsXCJmaWxlVXJsXCI6XCJjNjAzNzJjZi03NDNkLTQwZTctOGNiNi1hYjgwNDBiN2U3MDFcIixcInJ1bGVWZXJzaW9uSWRcIjpcIjEwMTQ3OTczMDY0NzA4NjY5NDRcIixcImRlbGV0ZVR5cGVcIjowfSIsInByZVNpZ25VcmxCYXNlRmlsZSI6dHJ1ZX0=&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTYlQjMlOUIlRTUlQkUlQUUlRTclQkIlQTklRTYlOTUlODglRTglODAlODMlRTYlQTAlQjgucGRm&download=MA==)",

494 

        "uniqueId": "c60372cf-743d-40e7-8cb6-ab8040b7e701",

495 

        "logId": 5242630587874129175

496 

    },

497 

    "fail": false

498 

}

### **3.3.2 ESB调用**

**需基线2508.01及以上版本**

执行动作选择 其他->代码->serverless/Action（自定义代码块），代码类型选择自定义Action，分组标识填写file（**版本号不要填写值** ）。详细参数配置如下：

**输入参数：**

 

参数名| 必填| 参数类型| 参数说明  
---|---|---|---  
function| 是| String| 此参数值为固定值：fileFormat  
params| 是| JSON| 转换参数  
    option| 是| String| 要执行方法，此参数值为固定值：CONVERT  
    fileId| 是| Long| 被转换的文件id  
    userId| 是| Long| 用户id，一般为当前用户id，可动态赋值系统字段  
    module| 否| String| 处理后的文件所属模块，不指定的话和原文件模块一致  
    fileCovertParam| 是| JSON| 转换参数  
        targetType| 是| String| 转换后的文件格式，可填写pdf/ofd等  
    temporaryFile| 否| boolean| 处理后文件是否为临时文件（临时文件24小时后自动删除），默认false  
    resultFileName| 否| String| 处理后的文件名称，不指定的话和原文件名称一致  
    createDoc| 否| boolean| 是否创建文档，默认为false  
    folderId| 否| Long| 设置创建文档的存放目录，不指定目录文档生成在系统知识库对应模块的目录下  
  
**输出参数：**

 

参数名| 必填| 参数类型| 参数说明  
---|---|---|---  
targetFileId| 是| Long| 转换后的文件id  
targetDocId| 否| long| 转换后的文件所属文档的文档id，只有当请求参数createDoc=true，此项才会有返回值  
  
## **3.4 文件合并**

**  功能说明**

1）多个同格式的文件合并成一个文件

2）多个不同格式的文件合并成一个pdf文件或ofd文件

3）多个同格式的文件合并成一个文件上传到指定目录生成一篇文档

4）多个不同格式的文件合并成一个pdf或ofd文件上传到指定目录生成一篇文档

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

### **3.4.1 RPC调用**

**需基线2308.01及以上版本**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

被合并文档数量最多不超过10个；合并前后文档格式一致的时候，被合并的文件后缀要一样

**调用示例**

499 

    @RpcReference

500 

    private OfficialFileConvertService officialFileConvertService;

501 

    

502 

    FileCapabilityParam fileCapabilityParam = new FileCapabilityParam();

503 

    // 操作类型 固定值 文件合并【必填】

504 

    fileCapabilityParam.setOption("MERGE");

505 

    // 用户id【必填】

506 

    fileCapabilityParam.setUserId(employee.getEmployeeId() + "");

507 

    // 文件合并参数【必填】

508 

    FileMergeParamVo fileMergeParam = new FileMergeParamVo();

509 

    // 被合并的文件【必填】

510 

    fileMergeParam.setMergeFile(mergeFiles);

511 

    // 合并后的文件格式，可选择pdf/ofd等

512 

    fileMergeParam.setTargetType(targetType);

513 

    fileCapabilityParam.setFileMergeParam(fileMergeParam);

514 

    // 合并后的文件名称【必填】

515 

    fileCapabilityParam.setResultFileName("合并.pdf");

516 

    // 其他参数选填 具体可看FileCapabilityParam参数描述

517 

    WeaResult<FileCapabilityResult> result = officialFileConvertService.capabilityFile(fileCapabilityParam);

返回结果：

518 

{

519 

    "code": 200,

520 

    "msg": "接口返回成功",

521 

    "status": true,

522 

    "data": {

523 

        "targetFileId": "1184753401515294721",

524 

        "targetFileObj": {

525 

            "id": "1184753401515294721",

526 

            "name": "合并.pdf",

527 

            ...

528 

        },

529 

        "targetUrl": "[https://weapp.yunteams.cn/papi/file/local/download/3bb96b09-7181-4930-aa20-0b725167b9e5?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=8daea362d4044928bec517a3c7e15b41/20250928/cn/s3/aws4_request&X-Amz-Signature=e0092838b85c83ed84278a89fd54229db2880f1c1de00730862f3b4c956c5466&X-Amz-Date=20250928T080817Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxNzowODoxNyBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTUlOTAlODglRTUlQjklQjYucGRm&response-auto-content-disposition=MA==&filename=5ZCI5bm2LnBkZg==](https://weapp.yunteams.cn/papi/file/local/download/3bb96b09-7181-4930-aa20-0b725167b9e5?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=8daea362d4044928bec517a3c7e15b41/20250928/cn/s3/aws4_request&X-Amz-Signature=e0092838b85c83ed84278a89fd54229db2880f1c1de00730862f3b4c956c5466&X-Amz-Date=20250928T080817Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxNzowODoxNyBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTUlOTAlODglRTUlQjklQjYucGRm&response-auto-content-disposition=MA==&filename=5ZCI5bm2LnBkZg==)",

530 

        "uniqueId": "3bb96b09-7181-4930-aa20-0b725167b9e5",

531 

        "logId": 1184753392875028481

532 

    },

533 

    "fail": false

534 

}

### **3.4.2 异步调用**

**需基线2508.01及以上版本**

**调用方式**

mq发消息调用（不限制文件数量），返回文档合并进度及合并结果

**调用示例**

第一步：批量合并文件

第二步：获取文件合并结果

535 

    /**

536 

     * 合并文档

537 

     *

538 

     * @param employee

539 

     * @return

540 

     */

541 

    private String fileMerge(SimpleEmployee employee) {

542 

        String taskId = UUID.randomUUID().toString().replace("-", "");

543 

        List<Long> fileIds = Arrays.asList(1097518273528520707L, 1136890290325512194L, 1103452363462754307L);

544 

545 

        FileMergeAsyncParam fileMergeAsyncParam = new FileMergeAsyncParam();

546 

        //【必填】任务id

547 

        fileMergeAsyncParam.setTaskId(taskId);

548 

        //【必填】要合并的文件id

549 

        fileMergeAsyncParam.setFileIds(fileIds);

550 

        //【必填】用户id

551 

        fileMergeAsyncParam.setUserId(employee.getEmployeeId() + "");

552 

        //【必填】模块标识

553 

        fileMergeAsyncParam.setModule([EntityType.document.name](http://EntityType.document.name)());

554 

        //【必填】合并后的文件格式

555 

        fileMergeAsyncParam.setTargetType("pdf");

556 

        //【必填】合并后的文件类型

557 

        fileMergeAsyncParam.setResultFileName("合并.pdf");

558 

        //【选填】合并后的文件是否为临时文件 设置为true 文件3小时候会自动删除

559 

        fileMergeAsyncParam.setTemporaryFile(true);

560 

        //【选填】合并后的文件是否创建文档（默认值为false）设置为true 生成的附件会在文档模块创建一篇文档

561 

        fileMergeAsyncParam.setCreateDoc(false);

562 

        //【选填】合并后的文件创建文档存在的目录（默认值为null）

563 

        fileMergeAsyncParam.setFolderId(null);

564 

        // 其他参数不支持

565 

566 

        //消息异步处理

567 

        AsyncBean<FileMergeAsyncParam> asyncBean = new AsyncBean();

568 

        asyncBean.setQueue(FileProcessingConstant.FILE_MERGE_ASYNC_QUEUE);

569 

        asyncBean.setMessage(fileMergeAsyncParam);

570 

        asyncClient.send(asyncBean);

571 

        return taskId;

572 

    }

573 

574 

    /**

575 

     * 获取合并进度（可直接前端调用/api/file/common/getProgressByCache?moduleKey=file&uuid=taskId 获取执行进度）

576 

     * 后端直接从缓存中获取进度 baseCache.get("file", taskId)

577 

     * @param moduleKey 模块标识 固定值 file

578 

     * @param uuid    任务id

579 

     * @return

580 

     */

581 

    public Object getProgressByCache(String moduleKey, String uuid) {

582 

        Object object = baseCache.get(moduleKey, uuid);

583 

        if (object == null) {

584 

            Map<String, Object> map = new HashMap<>();

585 

            map.put("status", "waiting");

586 

            map.put("msg", SystemEnv.getHtmlLabelName(317025L, "等待系统处理"));

587 

            return map;

588 

        }

589 

        // 返回值有4中情况

590 

        // 情况1：status = waiting，等待系统处理。前端页面可取msg的值提示

591 

        // 情况2：status = failed，程序处理失败。前端页面可取msg的值提示

592 

        // 情况3：status = pending，文件合并中。前端可取percent的值显示当前合并进度

593 

        // 情况4：status = success，合并成功。取data的值取合并结果 data合并结果后端可用FileCapabilityResult对象接收

594 

        return object;

595 

    }

### **3.4.3 ESB调用**

**需基线2508.01及以上版本**

执行动作选择 其他->代码->serverless/Action（自定义代码块），代码类型选择自定义Action，分组标识填写file（**版本号不要填写值** ）。详细参数配置如下：

**输入参数：**

 

参数名| 必填| 参数类型| 参数说明  
---|---|---|---  
function| 是| String| 此参数值为固定值：fileFormat  
params| 是| JSON| 合并参数  
    option| 是| String| 要执行方法，此参数值为固定值：MERGE  
    userId| 是| Long| 用户id，一般为当前用户id，可动态赋值系统字段  
    module| 否| String| 处理后的文件所属模块，不指定的话和原文件模块一致  
    temporaryFile| 否| boolean| 处理后文件是否为临时文件（临时文件24小时后自动删除），默认false  
    resultFileName| 是| String| 处理后的文件名称，带后缀（例如：合并后的文件.pdf）  
    fileMergeParam| 是| JSON| 被合并的文件  
        mergeFileIds| 是| String| 被合并的文件id，多个文件id英文逗号隔开  
        targetType| 否| String| 合并后的文件格式，可选pdf/ofd等  
    createDoc| 否| boolean| 是否创建文档，默认为false  
    folderId| 否| Long| 设置创建文档的存放目录，不指定目录文档生成在系统知识库对应模块的目录下  
  
**输出参数：**

 

参数名| 必填| 参数类型| 参数说明  
---|---|---|---  
targetFileId| 是| Long| 合并后的文件id  
targetDocId| 否| long| 合并后的文件所属文档的文档id，只有当请求参数createDoc=true，此项才会有返回值  
  
## **3.5 文件拆分**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**应用场景**

1）将一个文件按照页码范围拆分

2）将一个文件按照固定页数平均拆分

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

**调用示例**

596 

option: 操作类型。【必填】option=SPLIT

597 

fileId：【必填】被拆分的文件的文件id

598 

userId：当前用户id。rpc调用的时候【必填】

599 

module：【必填】来源模块

600 

fileSplitParam：【必填】拆分参数

601 

fileSplitParam.type：【必填】 拆分类型，枚举：AVERAGE：平均拆分 RANGE：范围拆分

602 

fileSplitParam.average：type=AVERAGE时【必填】，平均拆分，每几页拆分成一个文档

603 

fileSplitParam.ranges：type=RANGE时【必填】，范围拆分，多少范围拆分成一个文档

1）将一个文件按照页码范围拆分

604 

{

605 

    "module": "document",

606 

    "fileId": 894324045068328961,

607 

    "fileSplitParam": {

608 

        "type": "RANGE",

609 

        "ranges": [    //【必填】拆分范围

610 

            {

611 

                "start": 1,  //开始页码

612 

                "end": 1     //结束页码

613 

            },

614 

            {

615 

                "start": 2,

616 

                "end": 3

617 

            }

618 

        ]

619 

    }

620 

}

返回结果：

621 

{

622 

    "code": 200,

623 

    "msg": "接口返回成功",

624 

    "status": true,

625 

    "data": {

626 

        "sourceFileId": "903218076113174529",

627 

        "targetFileId": "904500196786520065",

628 

        "targetUrl": "[https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=83fdaad421a3404ca4a04b40871b5365](https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=83fdaad421a3404ca4a04b40871b5365)",

629 

        "uniqueId": "4c72e88647b98f7b3887612d4895c62a"

630 

    },

631 

    "fail": false

632 

}

2）将一个文件按照固定页数平均拆分

633 

{

634 

    "module": "document",

635 

    "fileId": 894324045068328961,

636 

    "fileSplitParam": {

637 

        "type": "AVERAGE",

638 

        "average": {

639 

            "size": 1,        //【必填】平均多少页拆分成一个文档

640 

            "split_range": {  //拆分范围，默认全文档

641 

                "start": 1,

642 

                "end": 3

643 

            }

644 

        }

645 

    }

646 

}

返回结果：

647 

{

648 

    "code": 200,

649 

    "msg": "接口返回成功",

650 

    "status": true,

651 

    "data": {

652 

        "sourceFileId": "894324045068328961",

653 

        "targetFileId": "904501004349423617",

654 

        "targetUrl": "[https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=48205611b6d1455e90b6e6069e7f7e64](https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=48205611b6d1455e90b6e6069e7f7e64)",

655 

        "uniqueId": "7a785875e3dbf2f59f5b1b77368d477d"

656 

    },

657 

    "fail": false

658 

}

## **3.6 加水印**

**功能说明**

1）文件加文字水印

2）文件加图片水印

3）文件加二维码水印

4）文件加页码水印

加水印支持的水印样式取决是系统中集成的第三方服务，详细见[ _E10文件加水印_](https://www.kdocs.cn/l/cjKB7YU4cuXk)

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

### **3.6.1 RPC调用**

**需基线2308.01及以上版本**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**调用示例**

659 

    @RpcReference

660 

    private OfficialFileConvertService officialFileConvertService;

661 

    

662 

    FileCapabilityParam fileCapabilityParam = new FileCapabilityParam();

663 

    // 操作类型 固定值【必填】

664 

    fileCapabilityParam.setOption("WATERMARK");

665 

    // 要处理的文件id【必填】

666 

    fileCapabilityParam.setFileId(fileId);

667 

    // 用户id【必填】

668 

    fileCapabilityParam.setUserId(employee.getEmployeeId() + "");

669 

    // 水印参数【必填】

670 

    FileWatermarkParamVo.TextWatermark textWatermark = new FileWatermarkParamVo.TextWatermark();

671 

    textWatermark.setContent("2025-09-28");

672 

    FileWatermarkParamVo fileWatermarkParam = new FileWatermarkParamVo();

673 

    fileWatermarkParam.setType("text");

674 

    fileWatermarkParam.setTextWatermark(textWatermark);

675 

    fileCapabilityParam.setFileWatermarkParam(fileWatermarkParam);

676 

    // 其他参数选填 具体可看FileCapabilityParam参数描述

677 

    WeaResult<FileCapabilityResult> result = officialFileConvertService.capabilityFile(fileCapabilityParam);

返回结果：

678 

{

679 

    "code": 200,

680 

    "msg": "接口返回成功",

681 

    "status": true,

682 

    "data": {

683 

        "sourceFileId": "1178072923504443393",

684 

        "targetFileId": "1184794573064273921",

685 

        "targetFileObj": {

686 

            "id": "1184794573064273921",

687 

            "name": "知识中台简易操作手册.docx",

688 

            ......

689 

        },

690 

        "targetUrl": "[https://weapp.yunteams.cn/papi/file/local/download/bbed3d37-ad8c-401c-997c-aad7faab0eb9?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=da0ff5f41f8047869725e7d42dbd138b/20250928/cn/s3/aws4_request&X-Amz-Signature=10136b4e255d1bccb50a5c55592fa4414ce582156275d84bc1337d52e3d81f6a&X-Amz-Date=20250928T104803Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxOTo0ODowMyBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTclOUYlQTUlRTglQUYlODYlRTQlQjglQUQlRTUlOEYlQjAlRTclQUUlODAlRTYlOTglOTMlRTYlOTMlOEQlRTQlQkQlOUMlRTYlODklOEIlRTUlODYlOEMuZG9jeA==&response-auto-content-disposition=MA==&filename=55-l6K-G5Lit5Y-w566A5piT5pON5L2c5omL5YaMLmRvY3g=](https://weapp.yunteams.cn/papi/file/local/download/bbed3d37-ad8c-401c-997c-aad7faab0eb9?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=da0ff5f41f8047869725e7d42dbd138b/20250928/cn/s3/aws4_request&X-Amz-Signature=10136b4e255d1bccb50a5c55592fa4414ce582156275d84bc1337d52e3d81f6a&X-Amz-Date=20250928T104803Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxOTo0ODowMyBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTclOUYlQTUlRTglQUYlODYlRTQlQjglQUQlRTUlOEYlQjAlRTclQUUlODAlRTYlOTglOTMlRTYlOTMlOEQlRTQlQkQlOUMlRTYlODklOEIlRTUlODYlOEMuZG9jeA==&response-auto-content-disposition=MA==&filename=55-l6K-G5Lit5Y-w566A5piT5pON5L2c5omL5YaMLmRvY3g=)",

691 

        "uniqueId": "bbed3d37-ad8c-401c-997c-aad7faab0eb9",

692 

        "logId": 1184794551639769088

693 

    },

694 

    "fail": false

695 

}

### **3.6.2 ESB调用**

**需基线2508.01及以上版本**

执行动作选择 其他->代码->serverless/Action（自定义代码块），代码类型选择自定义Action，分组标识填写file（**版本号不要填写值** ）。详细参数配置参考[ _E10文件加水印_](https://www.kdocs.cn/l/cjKB7YU4cuXk)

## **3.7 清稿**

**功能说明**

1)

word文件清稿

2)

文档清稿后上传到指定目录生成一篇文档

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

### **3.7.1 RPC调用**

**需基线2308.01及以上版本**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**调用示例**

696 

    @RpcReference

697 

    private OfficialFileConvertService officialFileConvertService;       

698 

699 

    FileCapabilityParam fileCapabilityParam = new FileCapabilityParam();

700 

    // 操作类型 固定值 清稿【必填】

701 

    fileCapabilityParam.setOption("CLEAN");

702 

    // 要处理的文件id【必填】

703 

    fileCapabilityParam.setFileId(fileId);

704 

    // 用户id【必填】

705 

    fileCapabilityParam.setUserId(employee.getEmployeeId() + "");

706 

    // 其他参数选填 具体可看FileCapabilityParam参数类描述

707 

    WeaResult<FileCapabilityResult> result = officialFileConvertService.capabilityFile(fileCapabilityParam);

返回结果：

708 

{

709 

    "code": 200,

710 

    "msg": "接口返回成功",

711 

    "status": true,

712 

    "data": {

713 

        "sourceFileId": "1134685644880674816",

714 

        "targetFileId": "1184702707850772483",

715 

        "targetFileObj": {

716 

            "id": "1184702707850772483",

717 

            "name": "带痕迹的.docx",

718 

            ......

719 

        },

720 

        "targetDocId": "0",

721 

        "targetUrl": "[https://weapp.yunteams.cn/papi/file/local/download/a87bf7b8-02dc-4e43-ad2a-682adf78cec9?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=eed9df6797074a4ab90ddc19c68e0c23/20250928/cn/s3/aws4_request&X-Amz-Signature=dd0149e54dbf50b2c69c1254035f1db1370bfdf1315ac22c0f8a2dc46282b608&X-Amz-Date=20250928T045134Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxMzo1MTozNCBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTUlQjglQTYlRTclOTclOTUlRTglQkYlQjklRTclOUElODQuZG9jeA==&response-auto-content-disposition=MA==&filename=5bim55eV6L-555qELmRvY3g=](https://weapp.yunteams.cn/papi/file/local/download/a87bf7b8-02dc-4e43-ad2a-682adf78cec9?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=eed9df6797074a4ab90ddc19c68e0c23/20250928/cn/s3/aws4_request&X-Amz-Signature=dd0149e54dbf50b2c69c1254035f1db1370bfdf1315ac22c0f8a2dc46282b608&X-Amz-Date=20250928T045134Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxMzo1MTozNCBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTUlQjglQTYlRTclOTclOTUlRTglQkYlQjklRTclOUElODQuZG9jeA==&response-auto-content-disposition=MA==&filename=5bim55eV6L-555qELmRvY3g=)",

722 

        "uniqueId": "a87bf7b8-02dc-4e43-ad2a-682adf78cec9",

723 

        "logId": 1184702703748743169

724 

    },

725 

    "fail": false

726 

}

### **3.7.2 ESB调用**

**需基线2508.01及以上版本**

执行动作选择 其他->代码->serverless/Action（自定义代码块），代码类型选择自定义Action，分组标识填写file（**版本号不要填写值** ）。详细参数配置如下：

**输入参数：**

 

参数名| 必填| 参数类型| 参数说明  
---|---|---|---  
function| 是| String| 此参数值为固定值：fileFormat  
params| 是| JSON| 清稿参数  
    option| 是| String| 要执行方法，此参数值为固定值：CLEAN  
    fileId| 是| Long| 被清稿文件的id  
    userId| 是| Long| 用户id，一般为当前用户id，可动态赋值系统字段  
    module| 否| String| 处理后的文件所属模块，不指定的话和原文件模块一致  
    temporaryFile| 否| boolean| 处理后文件是否为临时文件（临时文件24小时后自动删除），默认false  
    resultFileName| 否| String| 处理后的文件名称，不指定的话和原文件名称一致  
    createDoc| 否| boolean| 是否创建文档，默认为false  
    folderId| 否| Long| 设置创建文档的存放目录，不指定目录文档生成在系统知识库对应模块的目录下  
  
**输出参数：**

 

参数名| 必填| 参数类型| 参数说明  
---|---|---|---  
targetFileId| 是| Long| 清稿后的文件id  
targetDocId| 否| long| 清稿后的文件所属文档的文档id，只有当请求参数createDoc=true，此项才会有返回值  
  
## **3.8 书签替换（套红）**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**应用场景**

1）word文件普通书签替换

2）word模板插入正文

3）word同时插入正文和替换普通书签

wps文档限制编辑将无法进行书签套红；替换内容支持 文本，图片，word文档

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

**调用示例**

727 

option: 操作类型。【必填】option=REPLACE

728 

fileId：【必填】套红模版的文件id

729 

userId：当前用户id。rpc调用的时候【必填】

730 

module：【必填】来源模块

731 

fileReplaceParam：【必填】套红参数（正文id在这个里面）

1）同时插入正文和替换普通书签

732 

{

733 

    "module": "document",

734 

    "fileId": 856306570648420353,

735 

    "fileReplaceParam": {

736 

        "bookmarkReplaces": [

737 

            {

738 

                "type": "TEXT",

739 

                "bookmark": "日期",

740 

                "text": "2023-03-15"

741 

            },

742 

            {

743 

                "type": "DOCUMENT",

744 

                "bookmark": "正文",

745 

                "fileId": "1000616419605282830"

746 

            }

747 

        ]

748 

    }

749 

}

返回结果：

750 

{

751 

    "code": 200,

752 

    "msg": "接口返回成功",

753 

    "status": true,

754 

    "data": {

755 

        "sourceFileId": "903218076113174529",

756 

        "targetFileId": "904518420483751937",

757 

        "targetUrl": "[https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=06311b7712484833afb7a6e776f9bed4](https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=06311b7712484833afb7a6e776f9bed4)",

758 

        "uniqueId": "4c72e88647b98f7b3887612d4895c62a"

759 

    },

760 

    "fail": false

761 

}

## **~~3.9 智能公文~~**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**应用场景**

1）使用自定义模板文件操作

2）使用预设模板操作

 _此接口废弃_

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

**调用示例**

762 

option: 操作类型。【必填】option=SMART_OFFICIAL_DOC

763 

fileId：【必填】被处理的文件id

764 

userId：当前用户id。rpc调用的时候【必填】

765 

module：【必填】来源模块

766 

smartOfficialParam：【必填】智能公文参数

767 

smartOfficialParam.preInstallTemplate：预设模板标识

768 

smartOfficialParam.templateFileId：自定义的模板id

769 

smartOfficialParam.fieldConfig：用于控制生成的文件是否设置书签和是否设置公文域 默认field目标文档只设置公文域

1）使用自定义模板文件操作

770 

{

771 

    "module": "document",

772 

    "fileId": 835980169968934913,

773 

    "smartOfficialParam": {

774 

        "templateFileId": 894535361794957312    //【必填】自定义的文件模板附件id

775 

    }

776 

}

返回结果：

777 

{

778 

    "code": 200,

779 

    "msg": "接口返回成功",

780 

    "status": true,

781 

    "data": {

782 

        "sourceFileId": "835980169968934913",

783 

        "targetFileId": "904518652411985920",

784 

        "targetUrl": "[https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=c95945c0fcd84065ab1a8f88faaf171d](https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=c95945c0fcd84065ab1a8f88faaf171d)",

785 

        "uniqueId": "c64925719b43679e5d8a553d48aa218e"

786 

    },

787 

    "fail": false

788 

}

2）使用预设模板操作

789 

{

790 

    "module": "document",

791 

    "fileId": 835980169968934913,

792 

    "smartOfficialParam": {

793 

        "preInstallTemplate": "bulletin_ds_1seal"    //【必填】预设的模板标识

794 

    }

795 

}

返回结果：

796 

{

797 

    "code": 200,

798 

    "msg": "接口返回成功",

799 

    "status": true,

800 

    "data": {

801 

        "sourceFileId": "903218076113174529",

802 

        "targetFileId": "904518819966042113",

803 

        "targetUrl": "[https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=fec587785c204915b7c191c4a1a0eacc](https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=fec587785c204915b7c191c4a1a0eacc)",

804 

        "uniqueId": "4c72e88647b98f7b3887612d4895c62a"

805 

    },

806 

    "fail": false

807 

}

## **3.10  获取文件封面**

**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**应用场景**

1)

获取文件的封面

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX) （需要同时支持文件拆分和转图片）

**调用示例**

808 

option: 操作类型。【必填】option=FILE_COVER

809 

fileId：【必填】被处理的文件id

810 

userId：当前用户id。rpc调用的时候【必填】

811 

module：【必填】来源模块

1）获取文件的封面

812 

{

813 

    "module": "document",

814 

    "fileId": 7833937471091337764

815 

}

返回结果：

816 

{

817 

    "code": 200,

818 

    "msg": "接口返回成功",

819 

    "status": true,

820 

    "data": {

821 

        "sourceFileId": "7833937471091337764",

822 

        "targetFileId": "905291420127723521",

823 

        "targetUrl": "[https://test-1301503941.cos.ap-shanghai.myqcloud.com/all_teams/b6daf935-dada-48ef-9efc-ae2f79c509b5?sign=q-sign-algorithm%3Dsha1%26q-ak%3DAKIDqcLvPmX4XO8iMjIHoSG3CDXiiXkn8EJD%26q-sign-time%3D1693979584%3B1693983184%26q-key-time%3D1693979584%3B1693983184%26q-header-list%3Dhost%26q-url-param-list%3Dresponse-content-disposition%26q-signature%3Deef06a0d8c6af72362e5cbffd2a978d500273528&response-content-disposition=attachment%3Bfilename%3D%22%E6%B3%9B%E5%BE%AEDubbo%E5%AE%9E%E8%B7%B5%E6%80%BB%E7%BB%93.png%22](https://test-1301503941.cos.ap-shanghai.myqcloud.com/all_teams/b6daf935-dada-48ef-9efc-ae2f79c509b5?sign=q-sign-algorithm%3Dsha1%26q-ak%3DAKIDqcLvPmX4XO8iMjIHoSG3CDXiiXkn8EJD%26q-sign-time%3D1693979584%3B1693983184%26q-key-time%3D1693979584%3B1693983184%26q-header-list%3Dhost%26q-url-param-list%3Dresponse-content-disposition%26q-signature%3Deef06a0d8c6af72362e5cbffd2a978d500273528&response-content-disposition=attachment%3Bfilename%3D%22%E6%B3%9B%E5%BE%AEDubbo%E5%AE%9E%E8%B7%B5%E6%80%BB%E7%BB%93.png%22)",

824 

        "uniqueId": "f533e0d16ebef47d35597200fc4f56db"

825 

    },

826 

    "fail": false

827 

}

## **3.11  查询书签**

获取文档内书签建议优先使用插件前端sdk获取  
---  
  
**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**应用场景**

1)

获取office文件内的书签

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

**调用示例**

828 

option: 操作类型。【必填】option=BOOKMARK

829 

fileId：【必填】被处理的文件id

830 

userId：当前用户id。rpc调用的时候【必填】

831 

module：【必填】来源模块

1）获取office文件内的书签

832 

{

833 

    "fileId": 903224806310150144,

834 

    "module": "document"

835 

}

返回结果：

836 

{

837 

    "code": 200,

838 

    "msg": "接口返回成功",

839 

    "status": true,

840 

    "data": {

841 

        "sourceFileId": "903224806310150144",

842 

        "targetFileId": "907839297854611456",

843 

        "targetUrl": "[https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=da7483d1ed4446b499415d8c6c694490](https://weapp.yunteams.cn/papi/fileOnline/wps/download?id=da7483d1ed4446b499415d8c6c694490)",

844 

        "uniqueId": "6fb5abc9-ebbe-48c0-91d4-d152cc428f1a",

845 

        "data": [

846 

            {

847 

                "bookmark": "书签1",

848 

                "bookmark_type": "range",

849 

                "bookmark_content": "测试文件22222"

850 

            },

851 

            {

852 

                "bookmark": "书签2",

853 

                "bookmark_type": "range",

854 

                "bookmark_content": "测试文件"

855 

            }

856 

        ]

857 

    },

858 

    "fail": false

859 

}

## **3.12  开启/禁止文档编辑**

**功能说明**

1)

限制编辑的文档允许编辑

2)

允许编辑的文档限制编辑

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

### **3.12.1 RPC调用**

**需基线2602.01及以上版本**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**调用示例**

860 

    @RpcReference

861 

    private OfficialFileConvertService officialFileConvertService;        

862 

863 

    FileCapabilityParam fileCapabilityParam = new FileCapabilityParam();

864 

    // 操作类型 固定值 清稿【必填】

865 

    fileCapabilityParam.setOption("EDITING");

866 

    // 要处理的文件id【必填】

867 

    fileCapabilityParam.setFileId(fileId);

868 

    // 用户id【必填】

869 

    fileCapabilityParam.setUserId(employee.getEmployeeId() + "");

870 

    // 文件转换参数【必填】 eg：限制编辑的文档允许编辑

871 

    FileEditingParam fileEditingParam = new FileEditingParam();

872 

    fileEditingParam.setIsEditable("enable");

873 

    fileEditingParam.setPassword("2507");

874 

    fileCapabilityParam.setFileEditingParam(fileEditingParam);

875 

    // 其他参数选填 具体可看FileCapabilityParam参数描述

876 

    WeaResult<FileCapabilityResult> result = officialFileConvertService.capabilityFile(fileCapabilityParam);

返回结果：

877 

{

878 

    "code": 200,

879 

    "msg": "接口返回成功",

880 

    "status": true,

881 

    "data": {

882 

        "sourceFileId": "1134685644880674816",

883 

        "targetFileId": "1184702707850772483",

884 

        "targetFileObj": {

885 

            "id": "1184702707850772483",

886 

            "name": "带痕迹的.docx",

887 

            ......

888 

        },

889 

        "targetDocId": "0",

890 

        "targetUrl": "[https://weapp.yunteams.cn/papi/file/local/download/a87bf7b8-02dc-4e43-ad2a-682adf78cec9?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=eed9df6797074a4ab90ddc19c68e0c23/20250928/cn/s3/aws4_request&X-Amz-Signature=dd0149e54dbf50b2c69c1254035f1db1370bfdf1315ac22c0f8a2dc46282b608&X-Amz-Date=20250928T045134Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxMzo1MTozNCBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTUlQjglQTYlRTclOTclOTUlRTglQkYlQjklRTclOUElODQuZG9jeA==&response-auto-content-disposition=MA==&filename=5bim55eV6L-555qELmRvY3g=](https://weapp.yunteams.cn/papi/file/local/download/a87bf7b8-02dc-4e43-ad2a-682adf78cec9?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-SignedHeaders=fileKey&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Expires=604800&X-Amz-Credential=eed9df6797074a4ab90ddc19c68e0c23/20250928/cn/s3/aws4_request&X-Amz-Signature=dd0149e54dbf50b2c69c1254035f1db1370bfdf1315ac22c0f8a2dc46282b608&X-Amz-Date=20250928T045134Z&tenantKey=t4nb79v072&download=MA==&response-expires=U3VuIFNlcCAyOCAxMzo1MTozNCBDU1QgMjAyNQ==&metadata=bnVsbA==&response-content-disposition=YXR0YWNobWVudDtmaWxlbmFtZT0lRTUlQjglQTYlRTclOTclOTUlRTglQkYlQjklRTclOUElODQuZG9jeA==&response-auto-content-disposition=MA==&filename=5bim55eV6L-555qELmRvY3g=)",

891 

        "uniqueId": "a87bf7b8-02dc-4e43-ad2a-682adf78cec9",

892 

        "logId": 1184702703748743169

893 

    },

894 

    "fail": false

895 

}

### **3.12.2 ESB调用**

**需基线2602.01及以上版本**

执行动作选择 其他->代码->serverless/Action（自定义代码块），代码类型选择自定义Action，分组标识填写file（**版本号不要填写值** ）。详细参数配置如下：

**输入参数：**

 

## **3.13  复合接口**

目前仅支持清稿，套红，格式转换3个操作复合执行  
---  
  
**调用方式**

rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#capabilityFile

**应用场景**

1)

支持一次调用执行多个动作

**格式支持**

[ _E10插件功能支持_](https://kdocs.cn/l/cdc6s5k5QkuX)

**调用示例**

896 

option: 操作类型。【必填】option=COMPOSITE

897 

fileId：【必填】被处理的文件id

898 

userId：当前用户id。rpc调用的时候【必填】

899 

module：【必填】来源模块

900 

steps：【必填】要执行的操作 支持CONVERT,CLEAN,REPLACE

901 

{####}：复合业务的参数，参考单个调用传参

1）先套红，再清稿

902 

{

903 

    "module": "document",

904 

    "fileId": 903224806310150144,

905 

    "steps": [

906 

        "REPLACE",

907 

        "CLEAN"

908 

    ],

909 

    "fileReplaceParam": {

910 

        "bookmarkReplaces": [

911 

            {

912 

                "type": "TEXT",

913 

                "bookmark": "书签1",

914 

                "text": "2023-03-15"

915 

            },

916 

            {

917 

                "type": "DOCUMENT",

918 

                "bookmark": "书签2",

919 

                "fileId": 910867387172724737

920 

            }

921 

        ]

922 

    }

923 

}

返回结果：

924 

{

925 

    "code": 200,

926 

    "msg": "接口返回成功",

927 

    "status": true,

928 

    "data": {

929 

        "sourceFileId": "903224806310150144",

930 

        "targetFileId": "935826829384343552",

931 

        "targetUrl": "[https://test-1301503941.cos.ap-shanghai.myqcloud.com/tp2tn7kngu/2023/11/12c245ec-1398-4b5c-b14c-1f8b78a99f27?sign=q-sign-algorithm%3Dsha1%26q-ak%3DAKIDqcLvPmX4XO8iMjIHoSG3CDXiiXkn8EJD%26q-sign-time%3D1701089164%3B1701092763%26q-key-time%3D1701089164%3B1701092763%26q-header-list%3Dhost%26q-url-param-list%3Dresponse-content-disposition%26q-signature%3D719bcd72f2062c9b18ef32e3c62e570cadac1f93&response-content-disposition=attachment%3Bfilename%3D%22%E6%B5%8B%E8%AF%95%E6%96%87%E4%BB%B6%EF%BC%88%E4%BF%AE%E8%AE%A2%EF%BC%89.docx%22](https://test-1301503941.cos.ap-shanghai.myqcloud.com/tp2tn7kngu/2023/11/12c245ec-1398-4b5c-b14c-1f8b78a99f27?sign=q-sign-algorithm%3Dsha1%26q-ak%3DAKIDqcLvPmX4XO8iMjIHoSG3CDXiiXkn8EJD%26q-sign-time%3D1701089164%3B1701092763%26q-key-time%3D1701089164%3B1701092763%26q-header-list%3Dhost%26q-url-param-list%3Dresponse-content-disposition%26q-signature%3D719bcd72f2062c9b18ef32e3c62e570cadac1f93&response-content-disposition=attachment%3Bfilename%3D%22%E6%B5%8B%E8%AF%95%E6%96%87%E4%BB%B6%EF%BC%88%E4%BF%AE%E8%AE%A2%EF%BC%89.docx%22)",

932 

        "uniqueId": "12c245ec-1398-4b5c-b14c-1f8b78a99f27"

933 

    },

934 

    "fail": false

935 

}

2）先清稿，再转pdf

936 

{

937 

    "module": "document",

938 

    "fileId": 903224806310150144,

939 

    "steps": [

940 

        "CLEAN",

941 

        "CONVERT"

942 

    ],

943 

    "fileCovertParam": {

944 

        "targetType": "pdf"

945 

    }

946 

}

返回结果：

947 

{

948 

    "code": 200,

949 

    "msg": "接口返回成功",

950 

    "status": true,

951 

    "data": {

952 

        "sourceFileId": "903224806310150144",

953 

        "targetFileId": "935825914648584192",

954 

        "targetUrl": "[https://test-1301503941.cos.ap-shanghai.myqcloud.com/tp2tn7kngu/2023/11/6c45b1de-93ba-4611-8795-d5f23035e0f9?sign=q-sign-algorithm%3Dsha1%26q-ak%3DAKIDqcLvPmX4XO8iMjIHoSG3CDXiiXkn8EJD%26q-sign-time%3D1701088951%3B1701092550%26q-key-time%3D1701088951%3B1701092550%26q-header-list%3Dhost%26q-url-param-list%3Dresponse-content-disposition%26q-signature%3D5b5f6fb72dc0fd1851a90ec006d5b3e3c542d4c0&response-content-disposition=attachment%3Bfilename%3D%22%E6%B5%8B%E8%AF%95%E6%96%87%E4%BB%B6%EF%BC%88%E4%BF%AE%E8%AE%A2%EF%BC%89.pdf%22](https://test-1301503941.cos.ap-shanghai.myqcloud.com/tp2tn7kngu/2023/11/6c45b1de-93ba-4611-8795-d5f23035e0f9?sign=q-sign-algorithm%3Dsha1%26q-ak%3DAKIDqcLvPmX4XO8iMjIHoSG3CDXiiXkn8EJD%26q-sign-time%3D1701088951%3B1701092550%26q-key-time%3D1701088951%3B1701092550%26q-header-list%3Dhost%26q-url-param-list%3Dresponse-content-disposition%26q-signature%3D5b5f6fb72dc0fd1851a90ec006d5b3e3c542d4c0&response-content-disposition=attachment%3Bfilename%3D%22%E6%B5%8B%E8%AF%95%E6%96%87%E4%BB%B6%EF%BC%88%E4%BF%AE%E8%AE%A2%EF%BC%89.pdf%22)",

955 

        "uniqueId": "6c45b1de-93ba-4611-8795-d5f23035e0f9"

956 

    },

957 

    "fail": false

958 

}

## **3.99  获取某项操作支持的插件**

**调用方式**

1）rpc调用：com.weaver.eteams.file.client.remote.OfficialFileConvertService#getConvertServersByTenantKey

2）http调用：api/file/processing/getProcessingServers，post请求，content-type=application/json

**应用场景**

1)

获取某个操作的插件优先级信息

**调用示例**

959 

operationType: 操作类型。【必填】 可选值preview(预览),edit(编辑),convertToPdf(转pdf),convertToOfd(转ofd),convertToHtml(转HTML),convertToJpg(转JPG),convertToPng(转PNG),convertToBmp(转BMP),watermark(加水印),merge(文件合并),split(文件拆分),clean(清稿),replace(套红),bookmark(查询书签),smart_official_doc(智能公文)

960 

tenantKey：租户key

961 

employee：当前用户信息

962 

注:rpc调用如果是获取某个租户可用的插件tenantKey必传，不要传人员信息。如果是获取当前用户可用的插件employee必传

963 

    http调用如果是获取当前租户可用的插件tenantKey必传

**1）rpc调用获取当前用户可使用的转pdf插件**

964 

{

965 

    "operationType": "convertToPdf",

966 

    "employee": {employee}

967 

}

返回结果：

968 

{

969 

    "code": 200,

970 

    "msg": "接口返回成功",

971 

    "status": true,

972 

    "data": [

973 

        {

974 

            "collaborativeDocuments": true,

975 

            "convertServerType": "3009207966322931535",

976 

            "convertServerName": "wps v6",

977 

            "supportedTypes": "docx,doc,dot,wps,wpt,dotx,docm,dotm,rtf,uot,mht,mhtml,htm,html,xml,xls,xlt,et,ett,xlsx,xltx,csv,xlsm,xltm,xlsb,uos,pptx,ppt,pot,potx,pps,ppsx,dps,dpt,pptm,potm,ppsm,uop,ofd,uof,jpg,jpeg,png,gif,bmp,tif,tiff,psd,svg,vsd,vsdx,txt,log,c,cpp,java,lrc,h,asm,s,asp,bat,bas,prg,cmd,cdr,epub"

978 

        },

979 

        {

980 

            "collaborativeDocuments": true,

981 

            "convertServerType": "7779223638009254666",

982 

            "convertServerName": "wps v7",

983 

            "supportedTypes": "docx,doc,dot,wps,wpt,dotx,docm,dotm,rtf,uot,mht,mhtml,htm,html,xml,xls,xlt,et,ett,xlsx,xltx,csv,xlsm,xltm,xlsb,uos,pptx,ppt,pot,potx,pps,ppsx,dps,dpt,pptm,potm,ppsm,uop,ofd,uof,jpg,jpeg,png,gif,bmp,tif,tiff,psd,svg,vsd,vsdx,txt,log,c,cpp,java,lrc,h,asm,s,asp,bat,bas,prg,cmd,cdr,epub"

984 

        }

985 

    ],

986 

    "fail": false

987 

}

**2）rpc调用获取当前租户可使用的转pdf插件**

988 

{

989 

    "operationType": "convertToPdf",

990 

    "tenantKey": "tp2tn7kngu"

991 

}

返回结果：

992 

{

993 

    "code": 200,

994 

    "msg": "接口返回成功",

995 

    "status": true,

996 

    "data": [

997 

        {

998 

            "collaborativeDocuments": true,

999 

            "convertServerType": "3280918880049230065",

1000 

            "convertType": "wpsMiddleStationGeneric",

1001 

            "convertServerName": "WPS V7 225",

1002 

            "supportedTypes": "doc,dot,wps,wpt,docx,dotx,docm,dotm,rtf,txt,mht,mhtml,htm,html,xls,xlt,et,xlsx,xltx,csv,xlsm,xltm,ett,ppt,pptx,pptm,ppsx,ppsm,pps,potx,potm,dpt,dps,pot,pdf,ofd,jpeg,jpg,png,gif,bmp,tif,tiff,svg,psd,tar,zip,7z,jar,rar,gzip,md,c,cpp,java,js,css,lrc,h,asm,s,asp,bat,bas,prg,cmd,xml,log,ini,inf,cdr,vsd,vsdx"

1003 

        },

1004 

        {

1005 

            "collaborativeDocuments": true,

1006 

            "convertServerType": "3280919045056330079",

1007 

            "convertType": "foxitRead",

1008 

            "convertServerName": "福昕云阅读",

1009 

            "supportedTypes": "doc,docx,wps,xls,xlsx,et,ppt,pptx,pot,pdf,ofd,zip"

1010 

        },

1011 

        {

1012 

            "collaborativeDocuments": false,

1013 

            "convertServerType": "5809804869163930661",

1014 

            "convertType": "officeWeb365",

1015 

            "convertServerName": "OfficeWeb365",

1016 

            "supportedTypes": "doc,docx,xls,xlsx,ppt,pptx,pdf,txt,sql,wps,rtf,csv,ofd"

1017 

        },

1018 

        {

1019 

            "collaborativeDocuments": false,

1020 

            "convertServerType": "2071040749571331557",

1021 

            "convertType": "kinggrid2015",

1022 

            "convertServerName": "金格2015",

1023 

            "supportedTypes": "doc,docx,xls,xlsx,ppt,pptx,et,wps"

1024 

        },

1025 

        {

1026 

            "collaborativeDocuments": false,

1027 

            "convertServerType": "5811092706438233022",

1028 

            "convertType": "suwellRead",

1029 

            "convertServerName": "数科轻阅读",

1030 

            "supportedTypes": "ofd,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,wps,txt,png,jpe,bmp,tiff,tif"

1031 

        },

1032 

        {

1033 

            "collaborativeDocuments": false,

1034 

            "convertServerType": "5811437875124981035",

1035 

            "convertType": "LibreOffice",

1036 

            "convertServerName": "LibreOffice",

1037 

            "supportedTypes": "xlsx,xls,ppt,pptx,ofd,doc,docx"

1038 

        },

1039 

        {

1040 

            "collaborativeDocuments": false,

1041 

            "convertServerType": "5811747261374063339",

1042 

            "convertType": "yozoFcs",

1043 

            "convertServerName": "永中FCS",

1044 

            "supportedTypes": "doc,dot,wps,wpt,docx,dotx,docm,dotm,rtf,mht,pptx,ppt,pot,potx,pps,ppsx,dps,dpt,pptm,potm,ppsm,xls,xlt,et,ett,xlsx,xltx,csv,xlsm,xltm,xlsb,pdf,ofd"

1045 

        },

1046 

        {

1047 

            "collaborativeDocuments": false,

1048 

            "convertServerType": "-1",

1049 

            "convertType": "pdfJs",

1050 

            "convertServerName": "PDF.JS",

1051 

            "supportedTypes": "pdf"

1052 

        },

1053 

        {

1054 

            "collaborativeDocuments": false,

1055 

            "convertServerType": "2071715305276886545",

1056 

            "convertType": "wpsClient",

1057 

            "convertServerName": "WPS客户端",

1058 

            "supportedTypes": "doc,dot,wps,wpt,docx,dotx,docm,dotm,xls,xlt,et,xlsx,xltx,xlsm,xltm,ppt,pptx,pptm,ppsx,ppsm,pps,potx,potm,dpt,dps"

1059 

        },

1060 

        {

1061 

            "collaborativeDocuments": false,

1062 

            "convertServerType": "2071937208593887463",

1063 

            "convertType": "yozoOffice",

1064 

            "convertServerName": "永中OFFICE",

1065 

            "supportedTypes": ""

1066 

        }

1067 

    ],

1068 

    "fail": false

1069 

}

**3）http调用获取当前用户预览可使用的插件**

1070 

{

1071 

    "operationType": "PREVIEW"

1072 

}

返回结果：

1073 

{

1074 

    "code": 200,

1075 

    "msg": "接口返回成功",

1076 

    "status": true,

1077 

    "data": [

1078 

        {

1079 

            "collaborativeDocuments": true,

1080 

            "convertServerType": "3009207966322931535",

1081 

            "convertServerName": "wps v6",

1082 

            "supportedTypes": "doc,dot,wps,wpt,docx,dotx,docm,dotm,rtf,txt,mht,mhtml,htm,html,xls,xlt,et,xlsx,xltx,csv,xlsm,xltm,ett,ppt,pptx,pptm,ppsx,ppsm,pps,potx,potm,dpt,dps,pot,pdf,ofd,jpeg,jpg,png,gif,bmp,tif,tiff,svg,psd,tar,zip,7z,jar,rar,gzip,md,c,cpp,java,js,css,lrc,h,asm,s,asp,bat,bas,prg,cmd,xml,log,ini,inf,cdr,vsd,vsdx"

1083 

        },

1084 

        {

1085 

            "collaborativeDocuments": true,

1086 

            "convertServerType": "7779223638009254666",

1087 

            "convertServerName": "wps v7",

1088 

            "supportedTypes": "doc,dot,wps,wpt,docx,dotx,docm,dotm,rtf,txt,mht,mhtml,htm,html,xls,xlt,et,xlsx,xltx,csv,xlsm,xltm,ett,ppt,pptx,pptm,ppsx,ppsm,pps,potx,potm,dpt,dps,pot,pdf,ofd,jpeg,jpg,png,gif,bmp,tif,tiff,svg,psd,tar,zip,7z,jar,rar,gzip,md,c,cpp,java,js,css,lrc,h,asm,s,asp,bat,bas,prg,cmd,xml,log,ini,inf,cdr,vsd,vsdx"

1089 

        },

1090 

        {

1091 

            "convertServerType": "3279349794194972844",

1092 

            "convertServerName": "福昕云阅读",

1093 

            "supportedTypes": "doc,docx,wps,ppt,pptx,pot,ptm,xls,xlsx,csv,ods,pdf,ofd"

1094 

        },

1095 

        {

1096 

            "convertServerType": "7779224381786496703",

1097 

            "convertServerName": "数科轻阅读",

1098 

            "supportedTypes": "ofd,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,wps,txt,png,jpe,bmp,tiff,tif"

1099 

        },

1100 

        {

1101 

            "convertServerType": "-1",

1102 

            "convertServerName": "PDF.JS",

1103 

            "supportedTypes": "pdf"

1104 

        },

1105 

        {

1106 

            "convertServerType": "7779223609545654432",

1107 

            "convertServerName": "OfficeWeb365",

1108 

            "supportedTypes": "doc,wps,docx,rtf,xls,xlsx,ppt,pptx,pdf,txt,sql,csv"

1109 

        },

1110 

        {

1111 

            "convertServerType": "7779209191526086681",

1112 

            "convertServerName": "金格2015",

1113 

            "supportedTypes": "doc,docx,xls,xlsx,et,wps"

1114 

        }

1115 

    ],

1116 

    "fail": false

1117 

}
