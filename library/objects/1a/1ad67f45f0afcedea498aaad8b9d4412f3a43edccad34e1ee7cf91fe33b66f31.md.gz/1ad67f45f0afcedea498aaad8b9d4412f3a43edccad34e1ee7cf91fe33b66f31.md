**非标准文档，仅做参考使用**

EB调用下载时，接口调用方式如下：

```javascript
// 自行获取替换
const ebInfo = {
  fieldId: '1089021595462852625', // 字段id
  dataId: '1161748358289850370', // 数据id，dataId
  objId: '1089021574122233857', // 表单objId
};
// 自行获取替换
const fileInfo = {
  fileId: '1162750378415947776', // 附件fileId
  folderId: '7777722137537008161', // 文件夹id
};

// 附件下载的参数
const option = {
  fileId: fileInfo.fileId, // 附件fileId
  loginFree: false,
  module: 'ebuilderform',
  params: {
    module: 'ebuilderform', // 模块名称
    authModule: 'ebuilderform', //授权模块
    source: 'form',
    fieldId: ebInfo.fieldId,
    customParam: JSON.stringify({
      // 附件自定义参数
      objId: ebInfo.objId,
      dataId: ebInfo.dataId,
    }),
    refId: ebInfo.dataId,
    folderId: fileInfo.folderId, // 文件夹id
  },
};
//调用公共组件的下载方法
window.weappUi.Upload.download(option);
```
