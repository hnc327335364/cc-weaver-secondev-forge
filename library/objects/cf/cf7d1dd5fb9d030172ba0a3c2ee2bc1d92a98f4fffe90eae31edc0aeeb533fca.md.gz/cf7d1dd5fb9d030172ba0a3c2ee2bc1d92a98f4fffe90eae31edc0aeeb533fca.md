# 邮箱集成套件：Richmail企业邮箱配置示例

来源快照：`result_data_new_260518.json`

- 来源 ID：`1201364891749998611`
- 模块：集成中心
- 目录：邮箱集成 - 配置示例
- space ID：`1158011075224911873`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、需求背景

E10邮箱集成对接Richamil企业邮箱，实现OA组织和人员初始化、实时同步至邮箱系统；门户元素展示未读邮件；门户导航栏入口展示未读邮件数据及单点登录。

**注意：此功能不涉及收发邮件功能**

# 二、操作步骤

## 1.集成中心-邮箱集成-Richmail邮箱

点击Richmail邮箱新建，

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674067869697&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

页可以在ESB中心连接器中新建配置，ESB连接器中只是提供一个入口，功能都需要在【集成中心】-【邮箱集成】查看

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413669782118402&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413669764513798&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

配置项| 说明  
---|---  
启用| 默认开启，控制整个功能是否可用的开关  
名称| 任意  
产品类型| RichMail企业邮箱  
所属机构| 开启分权时显示  
绑定邮箱字段| 以此字段的值作为邮箱系统的账号  
启用同步| 默认开启，开启后可将OA组织和人员同步至邮箱系统  
关联单点登录标识| 关联后可邮箱门户元素查看未读邮件、门户导航栏可点击登录邮箱系统  
接口地址| Rich邮箱系统地址，例如：http://192.0.2.10  
应用ID| 见文档1.应用ID、应用秘钥  
应用密钥| 见文档1.应用ID、应用秘钥  
企业ID| 【系统管理】-【企业管理】-【企业列表】  
  
F12打开，查看接口请求参数，5316即为企业ID

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413669762686980&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

 

邮箱域名| 【应用管理】-【我的机构】-【基本信息】-【域名】，复制即可  
---|---  
  
![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674067869696&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

套餐ID| 默认1即可  
---|---  
  
 

## 2.维护个人信息卡片邮箱

配置示例“绑定邮箱字段”设置为“邮箱”

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674128957441&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

人力卡片邮箱字段维护正确的Richmail邮箱值

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413669782118400&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 3.手动同步

按照实际需要选择是否配置此步骤。

【集成中心】-【邮箱集成】打开新建的配置可点击同步，点击后将所选范围下的组织和人员同步至Richmail邮箱。

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674067869701&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 4.门户邮箱集成元素

涉及权限项：【门户】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413678278950916&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

按照实际需要选择是否配置此步骤

【后端管理中心】-【门户】-【设计】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674128957443&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

搜索“邮箱”添加

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413678365204482&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

内容来源选择集成中心-邮箱集成新建的配置，此处也可按需配置邮件列表、提示信息等门户元素样式

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413678321721356&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

效果：

若配置绑定了集成登录标识，点击右键则可登录Rich邮箱

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413678402953228&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

## 5.门户导航栏

涉及权限项：【界面配置中心】

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413678365204487&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

按照实际需要选择是否配置此步骤

【后台管理中心】-【界面配置中心】-【导航设置】-【PC网页版导航或PC客户端导航】，启用“RichMail企业邮箱”

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674067869700&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

效果：

点击可单点登录至邮箱，并可查看未读邮件的数量

![](https://weapp.eteams.cn/papi/file/preview?fileId=1201413674067869698&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

 

## 6.初始化密码查询

通过OA新增邮箱账号，初始化密码查询（前端-个人设置-集成设置-邮箱初始密码查询）

![](https://weapp.eteams.cn/papi/file/preview?fileId=1183645317071052804&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

注意：

邮箱初始化密码查询须知：

OA同步人员到邮箱，同步类型为新增，才会生产初始化密码，可在当前页做查询

人员同步开启实时同步OA密码，且修改了OA密码，初始化密码变无效，请使用修改后的密码登录邮箱

用户在邮箱修改密码，请勿查询此页面密码做登录
