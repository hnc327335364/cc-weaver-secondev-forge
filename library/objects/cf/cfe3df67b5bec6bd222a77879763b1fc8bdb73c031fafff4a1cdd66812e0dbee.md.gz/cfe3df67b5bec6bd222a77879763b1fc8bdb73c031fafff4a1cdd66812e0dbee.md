1、保存后的动作流偶发未执行的问题

这种的原因：一般是因为保存成功后，后面的动作流存在多个，且动作流执行时间长，而用户在保存动作完成时就关闭了标签页，导致前端代码执行中断。

解决办法，可以加个持续存在的提示

比如保存前加js动作，内容为

```javascript
window.save_dlg_tips = weappUi.Dialog.message({ type: 'info', content: '保存中，请勿关闭页面', delay: 0 });//不会主动关闭
```

整个按钮动作链条逻辑执行完毕后，将提示移除

```javascript
window.save_dlg_tips.destroy();//移除提示
delete window.save_dlg_tips;//移除属性
```
