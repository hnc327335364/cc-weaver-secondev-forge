---
table_name: ie_devops_deploy_stage
cn_name: devops自动化发布阶段明细信息
module: 迁出迁入
database: ebuilder-packing
type: 普通表
owner: 汤海军
creator: 王涛（上海）
public_config: 0
data_id: 1036982457478078485
has_fields: true
tags: [E10, 数据字典]
---

# ie_devops_deploy_stage

> devops自动化发布阶段明细信息

> [!info] 基本信息
> - 数据库表名：`ie_devops_deploy_stage`
> - 中文名称：devops自动化发布阶段明细信息
> - 所属模块：迁出迁入
> - 所属数据库：`ebuilder-packing`
> - 表类型：普通表
> - 负责人：汤海军
> - 创建者：王涛（上海）
> - 是否公共配置：0
> - 描述：devops自动化发布阶段明细信息
> - 数据ID：`1036982457478078485`
> - 最后更新：2024-08-26 11:01:33

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | deploy_id | 部署id | 长整型 |  |  |  |  |  |  |  |  |
| 8 | deploy_stage | 部署阶段 | 字符 | 20 |  |  |  |  |  |  |  |
| 9 | stage_step | 阶段步骤 | 字符 | 20 |  |  |  |  |  |  |  |
| 10 | step_status | 步骤结果 | 字符 | 10 |  |  |  |  |  |  |  |
| 11 | step_config | 步骤配置 | 大字段3 |  |  |  |  |  |  |  |  |
| 12 | step_param | 步骤入参 | 大字段3 |  |  |  |  |  |  |  |  |
| 13 | param_class | 入参类型 | 字符 | 1000 |  |  |  |  |  |  |  |
| 14 | class_path | 类路径 | 字符 | 255 |  |  |  |  |  |  |  |
| 15 | step_result | 步骤响应值 | 大字段3 |  |  |  |  |  |  |  |  |
| 16 | method_name | 方法名 | 字符 | 100 |  |  |  |  |  |  |  |
| 17 | deploy_time | 部署耗时 | 字符 | 20 |  |  |  |  |  |  |  |
| 18 | step_process | 进度比 | 字符 | 20 |  |  |  |  |  |  |  |
| 19 | error_msg | 错误信息 | 大字段3 |  |  |  |  |  |  |  |  |
| 20 | error_stack | 错误堆栈 | 大字段3 |  |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/迁出迁入]]
- 数据库索引：[[数据库索引/ebuilder-packing]]
