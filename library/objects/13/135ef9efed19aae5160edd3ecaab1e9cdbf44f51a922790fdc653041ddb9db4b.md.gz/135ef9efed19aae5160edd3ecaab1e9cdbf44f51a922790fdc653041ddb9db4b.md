---
table_name: publishkit_transfer_task
cn_name: 应用迁移任务表
module: e-Builder应用建模
database: techdoc
type: 普通表
owner: 程东勇
creator: 梁威（上海）
public_config: 0
data_id: 886318376271609859
has_fields: true
tags: [E10, 数据字典]
---

# publishkit_transfer_task

> 应用迁移任务表

> [!info] 基本信息
> - 数据库表名：`publishkit_transfer_task`
> - 中文名称：应用迁移任务表
> - 所属模块：e-Builder应用建模
> - 所属数据库：`techdoc`
> - 表类型：普通表
> - 负责人：程东勇
> - 创建者：梁威（上海）
> - 是否公共配置：0
> - 描述：应用迁移任务表
> - 数据ID：`886318376271609859`
> - 最后更新：2023-07-17 10:47:58

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | app_id | 应用ID | 长整型 |  |  |  |  |  |  |  |  |
| 8 | group_key | 分组 | 整型 |  |  |  |  |  |  |  |  |
| 9 | group_module | 分组 | 字符 | 100 |  |  |  |  |  |  |  |
| 10 | file_id | 缓存文件ID | 长整型 |  |  |  |  |  |  |  |  |
| 11 | prev_task_id | 迁移前的任务ID | 长整型 |  |  |  |  |  |  |  |  |
| 12 | task_status | 任务状态 | 整型 |  |  |  |  |  |  |  |  |
| 13 | transfer_mode | 迁移模式 | 整型 |  |  |  |  |  |  |  |  |
| 14 | message | 错误消息 | 字符 | 1000 |  |  |  |  |  |  |  |
| 15 | app_name | 应用名称 | 字符 | 512 |  |  |  |  |  |  |  |
| 16 | app_version | 应用版本 | 字符 | 128 |  |  |  |  |  |  |  |
| 17 | installer_task_id | 迁入任务ID | 长整型 |  |  |  |  |  |  |  |  |
| 18 | operate_type | 操作类型 | 字符 | 100 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/e-Builder应用建模]]
- 数据库索引：[[数据库索引/techdoc]]
