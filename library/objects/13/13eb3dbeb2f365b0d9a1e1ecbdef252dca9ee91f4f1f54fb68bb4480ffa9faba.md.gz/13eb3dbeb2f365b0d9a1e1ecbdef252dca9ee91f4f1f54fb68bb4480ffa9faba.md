---
table_name: ie_global_id_link_relation
cn_name: 全局id替换应用外部关联关系表
module: 迁出迁入
database: ebuilder-packing
type: 普通表
owner: 汤海军
creator: 尹俊皓
public_config: 0
data_id: 972893131658829848
has_fields: true
tags: [E10, 数据字典]
---

# ie_global_id_link_relation

> 全局id替换应用外部关联关系表

> [!info] 基本信息
> - 数据库表名：`ie_global_id_link_relation`
> - 中文名称：全局id替换应用外部关联关系表
> - 所属模块：迁出迁入
> - 所属数据库：`ebuilder-packing`
> - 表类型：普通表
> - 负责人：汤海军
> - 创建者：尹俊皓
> - 是否公共配置：0
> - 描述：迁出迁出全局id替换，用以记录用户在当前环境迁入应用的外部关联关系选择信息
> - 数据ID：`972893131658829848`
> - 最后更新：2024-03-06 18:02:14

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | old_export_id | 关联应用迁出id | 字符 | 50 |  |  |  |  |  |  |  |
| 8 | new_export_id | 关联应用迁入id | 字符 | 50 |  |  |  |  |  |  |  |
| 9 | top_table_id | 关联顶层表主键id | 字符 | 50 |  |  |  |  |  |  |  |
| 10 | link_export_type | 关联数据类型 | 整型 |  |  |  |  |  |  |  |  |
| 11 | ori_table_id | 关联顶层表原始id | 字符 | 50 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/迁出迁入]]
- 数据库索引：[[数据库索引/ebuilder-packing]]
