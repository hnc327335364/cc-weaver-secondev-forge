# 节点附加操作支持同步功能

来源快照：`result_data_new_260518.json`

- 来源 ID：`1972740733910462674`
- 模块：工作流程
- 目录：功能更新说明 - 2024-09
- space ID：`1157949872166969347`
- 原文链接：未提供
- 产品基线：未提供

## 正文

1、节点/出口附加操作支持同步到其余节点或出口，针对类似的附加操作无需一个个手动设置，功能入口如下图所示

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157204605141942454&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

  


2、支持单个同步和勾选多个进行批量同步；

3、同步时，可选择同步方式是追加还是覆盖，以及需要同步的节点或出口，界面如下图所示；

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157204609211195415&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

1）同步方式：可选择追加到已有的附加操作中，直接覆盖已有的附加操作

2）同步节点：支持选择多个节点，可选择是保留已选附加操作的执行时间，也支持自定义

3）同步出口：支持选择多个出口

  


4、同步后的附加操作效果如下图所示，名称后面会带上同步时间戳：

![](https://weapp.eteams.cn/papi/file/preview?fileId=1157204609209090121&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
