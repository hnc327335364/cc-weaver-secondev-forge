# 数据加工支持DB2类型的数据源

来源快照：`result_data_new_260518.json`

- 来源 ID：`1250728346963001383`
- 模块：数据加工
- 目录：数据加工 - 更新功能 - 260301基线
- space ID：`1162138465821556754`
- 原文链接：未提供
- 产品基线：未提供

## 正文

# 一、功能背景

  当前E10平台数据加工不支持DB2的数据连接，导致无法连接对应的数据源提供服务。现需对现有数仓进行扩展，增加对该数据库类型的支持，确保视图、SQL组件、离线计算作业能正常使用。

 

# 二、功能概述及使用说明

1.

数据连接新增db2数据库类型

![](https://weapp.eteams.cn/papi/file/preview?fileId=1250728505861218306&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

2.

可以在数据开发中创建离线计算作业

![](https://weapp.eteams.cn/papi/file/preview?fileId=1250728501549473798&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

3.

可以在数据准备中创建SQL视图

![](https://weapp.eteams.cn/papi/file/preview?fileId=1250728501326872578&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

4.

可以在eb页面中使用该数据源，也可以在动作流-dml、表单联动-sql联动中使用该数据连接

![](https://weapp.eteams.cn/papi/file/preview?fileId=1250728510063910912&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)![](https://weapp.eteams.cn/papi/file/preview?fileId=1250728510063910921&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)

![](https://weapp.eteams.cn/papi/file/preview?fileId=1250728505669271564&type=redirect&customParam=%7B%22isExtDist%22%3Atrue%2C%22distributeId%22%3A%22%22%2C%22externalId%22%3A%22%22%2C%22appId%22%3A%22%22%7D)
