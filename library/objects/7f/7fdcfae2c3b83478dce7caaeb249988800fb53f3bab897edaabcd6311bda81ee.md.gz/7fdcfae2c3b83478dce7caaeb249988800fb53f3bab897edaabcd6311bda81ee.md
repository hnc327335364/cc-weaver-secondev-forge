# e10-hr-docs 业务 API 资料

本文件作为结构化 API record 的原始来源索引。详细契约以 `references/api-records/*.json` 为准。

- hr-dubbo-actionentry-063: 组织管理 / dubbo / actionEntry / status=active
- hr-dubbo-finduserbyidno-068: 人事档案 / dubbo / findUserByIdNo / status=active
- hr-dubbo-getbyid-032: 组织管理 / dubbo / getById / status=active
- hr-dubbo-getcode-171: 组织管理 / dubbo / getCode / status=active
- hr-dubbo-getempform-150: 组织管理 / dubbo / getEmpForm / status=active
- hr-dubbo-getestcfginfo-028: 人事档案 / dubbo / getEstCfgInfo / status=active
- hr-dubbo-getoffspacepage-070: 组织管理 / dubbo / getOffspacePage / status=active
- hr-dubbo-queryhrsynclogdetail-071: HR同步 / dubbo / queryHrSyncLogDetail / status=active
- hr-dubbo-realonlinecount-038: 人员在线服务 / dubbo / realOnlineCount / status=active
- hr-dubbo-selectdata-001: 组织管理 / dubbo / selectData / status=active
- hr-http-api-bs-hrm-contact-main-table-268: 组织管理 / http / /api/bs/hrm/contact/main/table / status=active
- hr-http-api-recruit-candidate-getcandidatecardinterviewinfo-250: 招聘管理 / http / /api/recruit/candidate/getCandidateCardInterviewInfo / status=active
- hr-http-sapi-hrm-restful-syncdepartment-245: 组织管理 / http / /sapi/hrm/restful/syncDepartment / status=active
- hr-http-sapi-hrm-restful-syncemployee-247: 组织管理 / http / /sapi/hrm/restful/syncEmployee / status=active
- hr-http-sapi-hrm-restful-syncposition-213: 组织管理 / http / /sapi/hrm/restful/syncPosition / status=active
- hr-http-sapi-hrm-restful-syncsubcompany-221: 组织管理 / http / /sapi/hrm/restful/syncSubcompany / status=active
