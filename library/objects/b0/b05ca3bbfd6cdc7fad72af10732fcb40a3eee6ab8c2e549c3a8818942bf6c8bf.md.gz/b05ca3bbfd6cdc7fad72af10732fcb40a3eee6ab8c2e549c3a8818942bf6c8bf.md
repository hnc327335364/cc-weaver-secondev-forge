# 数据库：`passport`

> 共 **18** 张表

---

| 数据库表名 | 中文名称 | 所属模块 | 表类型 | 字段明细 |
|-----------|---------|---------|--------|---------|
| [[数据表/登录注册/detach_manager_user_info|detach_manager_user_info]] | 分权管理员账号表 | 登录注册 | 普通表 | ✅ |
| [[数据表/未命名/mobile_areacode|mobile_areacode]] |  |  | 普通表 | ✅ |
| [[数据表/登录注册/mobile_login_config|mobile_login_config]] | 手机号一键登录配置表 | 登录注册 | 普通表 | ✅ |
| [[数据表/整体基础/passport_secret_config|passport_secret_config]] | 秘密表 | 整体基础 | 普通表 | ✅ |
| [[数据表/登录注册/password_change_history|password_change_history]] | 密码变更历史记录表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/password_change_remind|password_change_remind]] | 密码变更提醒表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/sys_config|sys_config]] | passport白名单配置表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/third_app_login_config|third_app_login_config]] | 第三方app单点配置表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/third_login_log|third_login_log]] | 第三方单点登录日志表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/user_auto_lock_config|user_auto_lock_config]] | 账号自动锁定相关配置表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/user_info_backup|user_info_backup]] | 用户信息表 | 登录注册 |  | ✅ |
| [[数据表/登录注册/user_info_extension|user_info_extension]] | 用户信息扩展表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/user_info_login_param|user_info_login_param]] | 账号登录字段表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/user_info_operate_log|user_info_operate_log]] | 用户操作记录表 | 登录注册 | 普通表 | ✅ |
| [[数据表/整体基础/user_info_password|user_info_password]] | 用户密码表 | 整体基础 | 普通表 | ✅ |
| [[数据表/登录注册/user_info_third_bind|user_info_third_bind]] | 账号第三方绑定表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/user_lock_info|user_lock_info]] | 用户锁定信息表 | 登录注册 | 普通表 | ✅ |
| [[数据表/登录注册/user_password_link|user_password_link]] | 账号密码关联表 | 登录注册 | 普通表 | ✅ |

