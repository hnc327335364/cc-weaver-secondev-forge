**简要描述：** 

- 保存忽略子模块配置

**请求URL：** 
- `{host}/api/bs/mc/handle/mcSubModuleIgnoreConfig/deleteByModuleId`
  
**请求方式：**
- POST   http payload

**参数：** 
``` 
{"moduleId":114}
```
|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|moduleId|必填|int|模块id|

 **返回示例**

``` 
{
    "code": 200,
    "msg": "接口返回成功",
    "status": true,
    "data":true
    "fail": false
}
```

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|code |int   |200成功  |



 **备注** 

- 更多返回错误代码请看首页的错误代码描述
