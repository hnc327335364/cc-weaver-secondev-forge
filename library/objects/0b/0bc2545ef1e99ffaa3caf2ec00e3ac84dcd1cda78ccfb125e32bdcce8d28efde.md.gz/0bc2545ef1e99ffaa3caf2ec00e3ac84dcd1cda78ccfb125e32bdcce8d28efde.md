---
table_name: recruit_enterlogs_detail
cn_name: 招聘入职日志明细表
module: 招聘管理
database: recruit
type: 普通表
owner: 李伟（上海）
creator: 李富晨
public_config: 0
data_id: 972461294016766048
has_fields: true
tags: [E10, 数据字典]
---

# recruit_enterlogs_detail

> 招聘入职日志明细表

> [!info] 基本信息
> - 数据库表名：`recruit_enterlogs_detail`
> - 中文名称：招聘入职日志明细表
> - 所属模块：招聘管理
> - 所属数据库：`recruit`
> - 表类型：普通表
> - 负责人：李伟（上海）
> - 创建者：李富晨
> - 是否公共配置：0
> - 描述：招聘入职明细日志表
> - 数据ID：`972461294016766048`
> - 最后更新：2024-03-05 14:06:29

## 字段明细

| 序号 | 数据库列名 | 中文名称 | 数据类型 | 长度 | 允许空值 | 外键 | 自增长 | 默认值 | 主键 | 外键信息 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | id | ID | 长整型 |  |  |  |  |  |  |  |  |
| 2 | create_time | 创建时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 3 | update_time | 修改时间 | 日期时间 |  |  |  |  |  |  |  |  |
| 4 | creator | 创建人id | 长整型 |  |  |  |  |  |  |  |  |
| 5 | delete_type | 是否删除 | 整型 |  |  |  |  | 0 |  |  |  |
| 6 | tenant_key | 租户KEY | 字符 | 10 |  |  |  |  |  |  |  |
| 7 | uuid | 日志UUID | 字符 | 36 |  |  |  |  |  |  |  |
| 8 | mainid | 主表id | 字符 | 36 |  |  |  |  |  |  |  |
| 9 | dataid | 数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 10 | belongdataid | 主表数据id | 字符 | 50 |  |  |  |  |  |  |  |
| 11 | tablename | 表名 | 字符 | 200 |  |  |  |  |  |  |  |
| 12 | tablenamelabelid | 表名labelid | 字符 | 50 |  |  |  | -1 |  |  |  |
| 13 | tablenamedesc | 对应数据库的表 | 字符 | 50 |  |  |  |  |  |  |  |
| 14 | fieldname | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 15 | fieldnamelabelid | 字段名labelid | 字符 | 50 |  |  |  | -1 |  |  |  |
| 16 | newvalue | 更新后的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 17 | oldvalue | 更新前的值 | 大字段3 |  |  |  |  |  |  |  |  |
| 18 | newrealvalue | 更新后的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 19 | oldrealvalue | 更新前的显示值 | 大字段3 |  |  |  |  |  |  |  |  |
| 20 | fielddesc | 字段名 | 字符 | 200 |  |  |  |  |  |  |  |
| 21 | showorder | 显示顺序 | 整型 | 11 |  |  |  |  |  |  |  |
| 22 | isdetail | 是否明细字段 | 整型 | 11 |  |  |  | 0 |  |  |  |
| 23 | log_level | 日志级别 | 字符 | 36 |  |  |  |  |  |  |  |
| 24 | log_time | 日志记录时间 | 字符 | 36 |  |  |  |  |  |  |  |

## 关联

- 返回首页：[[首页]]
- 模块索引：[[模块索引/招聘管理]]
- 数据库索引：[[数据库索引/recruit]]
